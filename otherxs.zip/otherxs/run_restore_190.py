﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

script = '''
import json
import psycopg2
import httpx
import asyncio
import time
import uuid

with open("/app/recovered_urls.json", "r") as f:
    urls = json.load(f)

print(f"Testing {len(urls)} recovered URLs from logs...")

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()

async def probe_url(client, url, sem):
    base = url.rstrip("/")
    cb = int(time.time() * 1000)
    if "?" in base:
        base_clean, query = base.split("?", 1)
        clients_url = f"{base_clean}/clients.json?{query}&_cb={cb}"
    else:
        clients_url = f"{base}/clients.json?_cb={cb}"
        
    async with sem:
        for attempt in range(2):
            try:
                r = await client.get(clients_url, timeout=httpx.Timeout(6.0, connect=4.0))
                if r.status_code == 200:
                    data = r.json()
                    if isinstance(data, dict) and len(data) > 0:
                        online = 0
                        now_ms = time.time() * 1000
                        for cid, cdata in data.items():
                            if isinstance(cdata, dict):
                                raw_status = cdata.get("status")
                                raw_seen = (cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("timestamp"))
                                ts = None
                                if raw_seen:
                                    try:
                                        ts = float(raw_seen)
                                        if ts < 1e12: ts = ts * 1000
                                    except Exception:
                                        pass
                                if bool(raw_status) and (ts is None or (now_ms - ts < 86400000)):
                                    online += 1
                        return {"url": url, "devices": len(data), "online": online, "valid": True}
            except Exception:
                pass
        return {"url": url, "devices": 0, "online": 0, "valid": False}

async def main():
    sem = asyncio.Semaphore(40)
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as client:
        tasks = [probe_url(client, u, sem) for u in urls]
        results = await asyncio.gather(*tasks)

    valid = [r for r in results if r["valid"]]
    print(f"Total valid working panels with device registries: {len(valid)}")
    print(f"  - Panels with >0 online devices: {len([r for r in valid if r['online'] > 0])}")
    print(f"  - Panels with registered devices (0 online right now): {len([r for r in valid if r['online'] == 0])}")
    print(f"Total registered devices across all panels: {sum(r['devices'] for r in valid)}")
    print(f"Total online devices right now: {sum(r['online'] for r in valid)}")
    
    # Insert / update all valid panels into PostgreSQL
    for item in valid:
        u = item["url"]
        name = u.split("//")[1].split(".")[0]
        did = str(uuid.uuid4())
        cur.execute(
            "INSERT INTO databases (id, url, name, added, status, sms_sent, devices_online) VALUES (%s, %s, %s, %s, 'active', 0, %s) ON CONFLICT (url) DO UPDATE SET status = 'active', devices_online = %s",
            (did, u, name, "2026-09-17", item["online"], item["online"])
        )
    conn.commit()

    cur.execute("SELECT count(*) FROM databases WHERE status = 'active'")
    total_in_db = cur.fetchone()[0]
    print(f"Total active panels now in PostgreSQL databases table: {total_in_db}")

    cur.close()
    conn.close()

asyncio.run(main())
'''

s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'restore_all_190.py', 'content': script})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp recovered_urls.json cowbox-khaat-968826:/app/recovered_urls.json'})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp restore_all_190.py cowbox-khaat-968826:/app/restore_all_190.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/restore_all_190.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
