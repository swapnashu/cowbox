﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines[1125:1155]):
    print(f"{1125+i}: {line.encode('ascii', 'backslashreplace').decode()}")
