﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Patch async deduct_balance
old_async_deduct = '''async def deduct_balance(uid: int, amount: float) -> bool:

    uid_str = str(uid)

    async with pool.acquire() as conn:

        result = await conn.execute(

            "UPDATE users SET balance = balance -  WHERE user_id =  AND balance >= ",

            amount,

            uid_str,

        )

    await redis_client.delete(f"user:{uid_str}")

    return result == "UPDATE 1"'''

new_async_deduct = '''async def deduct_balance(uid: int, amount: float) -> bool:

    uid_str = str(uid)

    amt = round(float(amount), 4)

    async with pool.acquire() as conn:

        row = await conn.fetchrow("SELECT balance FROM users WHERE user_id = ", uid_str)

        if not row:

            return False

        current_bal = float(row["balance"] or 0)

        if round(current_bal, 2) < round(amt, 2):

            return False

        new_bal = max(0.0, current_bal - amt)

        await conn.execute(

            "UPDATE users SET balance =  WHERE user_id = ",

            new_bal,

            uid_str,

        )

    if redis_client:

        try:

            await redis_client.delete(f"user:{uid_str}")

        except Exception:

            pass

    return True'''

if old_async_deduct in content:
    content = content.replace(old_async_deduct, new_async_deduct)
    print("PATCH ASYNC DEDUCT SUCCESS")
else:
    print("PATCH ASYNC DEDUCT NOT FOUND")

# 2. Patch sync usr_deduct_balance
old_sync_deduct = '''def usr_deduct_balance(uid, amount):

    uid_str = str(uid).strip()

    amt = float(amount)

    user = pg.execute_one("SELECT balance FROM users WHERE user_id = %s", (uid_str,), dict_cursor=True)

    if not user or float(user.get("balance") or 0) < amt:

        return False

    pg.execute_write(

        "UPDATE users SET balance = balance - %s WHERE user_id = %s AND balance >= %s",

        (amt, uid_str, amt),

    )

    if rds:

        try:

            rds.delete(f"user:{uid_str}")

        except Exception:

            pass

    return True'''

new_sync_deduct = '''def usr_deduct_balance(uid, amount):

    uid_str = str(uid).strip()

    amt = round(float(amount), 4)

    user = pg.execute_one("SELECT balance FROM users WHERE user_id = %s", (uid_str,), dict_cursor=True)

    if not user:

        return False

    current_bal = float(user.get("balance") or 0)

    if round(current_bal, 2) < round(amt, 2):

        return False

    new_bal = max(0.0, current_bal - amt)

    pg.execute_write(

        "UPDATE users SET balance = %s WHERE user_id = %s",

        (new_bal, uid_str),

    )

    if rds:

        try:

            rds.delete(f"user:{uid_str}")

        except Exception:

            pass

    return True'''

if old_sync_deduct in content:
    content = content.replace(old_sync_deduct, new_sync_deduct)
    print("PATCH SYNC DEDUCT SUCCESS")
else:
    print("PATCH SYNC DEDUCT NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
