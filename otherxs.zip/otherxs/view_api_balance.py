﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if '@app.route("/api/deduct-balance"' in line or '@app.route("/api/add-balance"' in line:
        for j in range(i, i+30):
            print(f"{j}: {lines[j].encode('ascii', 'backslashreplace').decode()}")
        break
