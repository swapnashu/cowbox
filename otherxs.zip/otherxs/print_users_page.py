﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines[4860:5080]):
    print(f"{4860+i}: {line.encode('ascii', 'backslashreplace').decode()}")
