﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Patch setting_set
old_setting_set = '''def setting_set(key, value):
    pg.execute_write(
        "INSERT INTO settings (key, value) VALUES (%s,%s) ON CONFLICT (key) DO UPDATE SET value = %s",
        (key, value, value),
    )'''

new_setting_set = '''def setting_set(key, value):
    global settings_cache, SMS_COST
    val_str = str(value) if value is not None else ""
    pg.execute_write(
        "INSERT INTO settings (key, value) VALUES (%s,%s) ON CONFLICT (key) DO UPDATE SET value = %s",
        (key, val_str, val_str),
    )
    settings_cache[key] = val_str
    if key == "sms_cost":
        try:
            SMS_COST = float(val_str)
        except Exception:
            pass'''

if old_setting_set in content:
    content = content.replace(old_setting_set, new_setting_set)
    print("PATCH SETTING_SET SUCCESS")
else:
    print("PATCH SETTING_SET NOT FOUND")

# 2. Patch usr_update and usr_delete
old_usr_mgmt = '''def usr_update(uid, **kwargs):
    sets = []
    vals = []
    for k, v in kwargs.items():
        if k not in _ALLOWED_USER_COLS:
            continue
        sets.append(f"{k} = %s")
        vals.append(v)
    if sets:
        vals.append(uid)
        pg.execute_write(f"UPDATE users SET {', '.join(sets)} WHERE user_id = %s", vals)




def usr_ban(uid, reason=""):
    usr_update(uid, banned=1, ban_reason=reason)




def usr_unban(uid):
    usr_update(uid, banned=0, ban_reason="")




def usr_delete(uid):
    pg.execute_write("DELETE FROM users WHERE user_id = %s", (uid,))'''

new_usr_mgmt = '''def usr_update(uid, **kwargs):
    uid_str = str(uid).strip()
    sets = []
    vals = []
    for k, v in kwargs.items():
        if k not in _ALLOWED_USER_COLS:
            continue
        sets.append(f"{k} = %s")
        vals.append(v)
    if sets:
        vals.append(uid_str)
        pg.execute_write(f"UPDATE users SET {', '.join(sets)} WHERE user_id = %s", vals)
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass




def usr_ban(uid, reason=""):
    usr_update(uid, banned=1, ban_reason=reason)




def usr_unban(uid):
    usr_update(uid, banned=0, ban_reason="")




def usr_delete(uid):
    uid_str = str(uid).strip()
    pg.execute_write("DELETE FROM users WHERE user_id = %s", (uid_str,))
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass'''

if old_usr_mgmt in content:
    content = content.replace(old_usr_mgmt, new_usr_mgmt)
    print("PATCH USR_MGMT SUCCESS")
else:
    print("PATCH USR_MGMT NOT FOUND")

with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
    f.write(content)
