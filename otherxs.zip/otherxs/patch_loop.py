﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

old_loop = '''        for i in range(count):

            result = await loop.run_in_executor(None, panel_manager.send, phone, msg)

            if result[0]:

                sent += 1

                await increment_sms(uid)

                await log_sms(str(uid), phone, result[1], "sent", msg)

            else:

                failed += 1

                await log_sms(str(uid), phone, "none", "failed", result[1])



            if speed > 0 and i < count - 1:

                await asyncio.sleep(speed)'''

new_loop = '''        for i in range(count):

            # Make each message unique to bypass Android duplicate filters
            unique_msg = msg + ("\\u200b" * (i % 20))

            result = await loop.run_in_executor(None, panel_manager.send, phone, unique_msg)

            if result[0]:

                sent += 1

                await increment_sms(uid)

                await log_sms(str(uid), phone, result[1], "sent", msg)

            else:

                failed += 1

                await log_sms(str(uid), phone, "none", "failed", result[1])



            if i < count - 1:

                # Ensure minimum 1.2s delay for device radio/SIM to process consecutive SMS
                wait_time = max(speed, 1.2) if speed == 0.1 else speed

                await asyncio.sleep(wait_time)'''

if old_loop in content:
    content = content.replace(old_loop, new_loop)
    print("PATCH 2 SUCCESS")
else:
    print("PATCH 2 NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
