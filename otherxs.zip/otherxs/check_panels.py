﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

# Read logs or databases from khaat
r = s.get('http://13.207.147.149:5050/api/panels')
print("Panels API:", r.status_code, r.text[:500] if r.status_code == 200 else "")
