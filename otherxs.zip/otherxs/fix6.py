﻿import re
with open('khaat_bot.py', 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(
    r'"No payment found with this UTR\.\\nCheck and try again:"',
    r'"Automatic UTR verification failed.\\nPlease contact Admin with your payment screenshot."',
    content
)

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("Done")
