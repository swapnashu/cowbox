﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    text = f.read()

rupee_count = text.count('\u20b9')
print(f"Total rupee symbols (₹): {rupee_count}")
