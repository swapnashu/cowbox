﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = 'docker exec cowbox-khaat-968826 python -c "import json; ids = json.load(open(\'/app/to_delete_ids.json\')); print(f\'Total IDs in to_delete_ids.json: {len(ids)}\')"'
r = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r.json().get('stdout'))
