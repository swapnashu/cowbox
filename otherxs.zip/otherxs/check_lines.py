﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

# Search for line 890
print("--- Lines 870-910 ---")
for i in range(max(0, 870), min(len(lines), 915)):
    print(f"{i}: {lines[i].encode('ascii', 'backslashreplace').decode()}")

# Search for line 5386
print("--- Lines 5370-5400 ---")
for i in range(max(0, 5370), min(len(lines), 5410)):
    print(f"{i}: {lines[i].encode('ascii', 'backslashreplace').decode()}")
