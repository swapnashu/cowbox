﻿with open('decoded.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if 'def _probe_all_async' in line or 'def background_probe_loop' in line:
        print(f"Line {i}: {line}")
