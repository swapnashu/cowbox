﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i in range(900, min(len(lines), 960)):
    print(f"{i}: {lines[i].encode('ascii', 'backslashreplace').decode()}")
