﻿import requests

# We can test logging in or querying the API
s = requests.Session()
# Check health of the app
r = s.get('http://13.207.147.149:5050/login')
print("Login page status:", r.status_code)
