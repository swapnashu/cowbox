﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = 'docker logs --tail 40 cowbox-khaat-968826'
r_run = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print("--- STDOUT ---")
print(r_run.json().get('stdout'))
print("--- STDERR ---")
print(r_run.json().get('stderr'))
