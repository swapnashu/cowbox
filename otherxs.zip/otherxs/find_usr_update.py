﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if 'def usr_update' in line or 'def usr_ban' in line:
        print(f"Line {i}: {line}")
