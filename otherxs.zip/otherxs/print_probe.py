﻿with open('decoded.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for line in lines[2880:2960]:
    # safe print without unicode error
    print(line.encode('ascii', 'backslashreplace').decode())
