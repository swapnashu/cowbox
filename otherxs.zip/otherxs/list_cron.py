﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})
r = s.get('http://13.207.147.149:9999/api/cron')
print(r.status_code, r.text)
