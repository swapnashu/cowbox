﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = '''docker exec cowbox-db-khaat-pg psql -U postgres -d aat -c "
CREATE TABLE IF NOT EXISTS sms_received (
    id SERIAL PRIMARY KEY,
    number TEXT,
    from_number TEXT,
    to_number TEXT,
    message TEXT,
    panel TEXT,
    received_at TEXT
);
ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS from_number TEXT;
ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS to_number TEXT;
\d sms_received
"'''
r_run = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r_run.json()['stdout'])
