﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Schema migration for from_number and to_number
old_schema = '''    pg.execute_write("""CREATE TABLE IF NOT EXISTS sms_received (

        id SERIAL PRIMARY KEY,

        number TEXT,

        message TEXT,

        panel TEXT,

        received_at TEXT

    )""")'''

new_schema = '''    pg.execute_write("""CREATE TABLE IF NOT EXISTS sms_received (

        id SERIAL PRIMARY KEY,

        number TEXT,

        from_number TEXT,

        to_number TEXT,

        message TEXT,

        panel TEXT,

        received_at TEXT

    )""")

    pg.execute_write("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS from_number TEXT")

    pg.execute_write("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS to_number TEXT")'''

if old_schema in content:
    content = content.replace(old_schema, new_schema)
    print("PATCH SCHEMA SUCCESS")
else:
    print("PATCH SCHEMA NOT FOUND")

# 2. Patch sms_received_add, sms_received_list, sms_received_count
old_funcs = '''def sms_received_add(number, message, panel="", received_at=None):

    if not number or not message:

        return

    try:

        existing = pg.execute_one(

            "SELECT id FROM sms_received WHERE number = %s AND message = %s LIMIT 1",

            (str(number), str(message))

        )

        if existing:

            return

        ts = received_at or datetime.now().isoformat()

        pg.execute_write(

            "INSERT INTO sms_received (number, message, panel, received_at) VALUES (%s,%s,%s,%s)",

            (str(number), str(message), str(panel), str(ts))

        )

    except Exception:

        pass





def sms_received_list(page=1, per_page=100, number=""):

    offset = (page - 1) * per_page

    if number:

        rows = pg.execute(

            "SELECT * FROM sms_received WHERE number = %s ORDER BY received_at DESC LIMIT %s OFFSET %s",

            (number, per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute(

            "SELECT * FROM sms_received ORDER BY received_at DESC LIMIT %s OFFSET %s",

            (per_page, offset), dict_cursor=True

        )

    return rows





def sms_received_count(number=""):

    if number:

        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received WHERE number = %s", (number,))

    else:

        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received")

    return row[0] if row else 0'''

new_funcs = '''def sms_received_add(from_number, to_number, message, panel="", received_at=None):

    if not message:

        return

    from_str = str(from_number or "").strip()

    to_str = str(to_number or "").strip()

    msg_str = str(message or "").strip()

    panel_str = str(panel or "").strip()

    ts = received_at or datetime.now().isoformat()

    try:

        existing = pg.execute_one(

            "SELECT id FROM sms_received WHERE (from_number = %s OR number = %s) AND message = %s LIMIT 1",

            (from_str, from_str, msg_str)

        )

        if existing:

            return

        pg.execute_write(

            "INSERT INTO sms_received (number, from_number, to_number, message, panel, received_at) VALUES (%s,%s,%s,%s,%s,%s)",

            (from_str, from_str, to_str, msg_str, panel_str, str(ts))

        )

    except Exception:

        pass





def sms_received_list(page=1, per_page=100, number=""):

    offset = (page - 1) * per_page

    if number:

        q = f"%{number.strip()}%"

        rows = pg.execute(

            "SELECT * FROM sms_received WHERE number ILIKE %s OR from_number ILIKE %s OR to_number ILIKE %s OR message ILIKE %s ORDER BY received_at DESC, id DESC LIMIT %s OFFSET %s",

            (q, q, q, q, per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute(

            "SELECT * FROM sms_received ORDER BY received_at DESC, id DESC LIMIT %s OFFSET %s",

            (per_page, offset), dict_cursor=True

        )

    return rows





def sms_received_count(number=""):

    if number:

        q = f"%{number.strip()}%"

        row = pg.execute_one(

            "SELECT COUNT(*) as c FROM sms_received WHERE number ILIKE %s OR from_number ILIKE %s OR to_number ILIKE %s OR message ILIKE %s",

            (q, q, q, q)

        )

    else:

        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received")

    return row[0] if row else 0'''

if old_funcs in content:
    content = content.replace(old_funcs, new_funcs)
    print("PATCH FUNCS SUCCESS")
else:
    print("PATCH FUNCS NOT FOUND")

# 3. Patch probe client extraction to strictly ignore outgoing SMS and capture From/To
old_probe_extract = '''                # Automatically extract and store received incoming SMS
                for sms_key in ("receivedSms", "received_sms", "inbox", "sms", "messages", "smsList", "sms_received"):

                    sms_container = cdata.get(sms_key)

                    if not sms_container:

                        continue

                    items = []

                    if isinstance(sms_container, dict):

                        items = list(sms_container.values())

                    elif isinstance(sms_container, list):

                        items = sms_container

                    for item in items[-15:]:

                        if isinstance(item, dict):

                            from_num = item.get("from") or item.get("number") or item.get("sender") or item.get("phone") or ""

                            msg_text = item.get("message") or item.get("msg") or item.get("body") or item.get("text") or item.get("messageText") or ""

                            r_time = item.get("received_at") or item.get("timestamp") or item.get("date") or item.get("time") or ""

                            if from_num and msg_text:

                                sms_received_add(str(from_num), str(msg_text), panel["name"], str(r_time) if r_time else None)'''

new_probe_extract = '''                # Automatically extract and store ONLY incoming/received SMS (ignore outgoing/sent)
                for sms_key in ("receivedSms", "received_sms", "inbox", "sms", "messages", "smsList", "sms_received"):

                    sms_container = cdata.get(sms_key)

                    if not sms_container:

                        continue

                    items = []

                    if isinstance(sms_container, dict):

                        items = list(sms_container.values())

                    elif isinstance(sms_container, list):

                        items = sms_container

                    for item in items[-25:]:

                        if not isinstance(item, dict):

                            continue

                        # Strictly ignore sent / outgoing messages
                        stype = str(item.get("type") or item.get("box") or item.get("folder") or item.get("direction") or "").lower()

                        if stype in ("sent", "out", "outgoing", "2", "outbox", "draft") or item.get("isSended") is True:

                            continue

                        from_num = item.get("from") or item.get("sender") or item.get("senderNumber") or item.get("address") or item.get("number") or item.get("phone") or ""

                        to_num = item.get("to") or item.get("receiver") or item.get("recipient") or item.get("dest") or mobno or ""

                        msg_text = item.get("message") or item.get("msg") or item.get("body") or item.get("text") or item.get("messageText") or ""

                        r_time = item.get("received_at") or item.get("timestamp") or item.get("date") or item.get("time") or ""

                        if from_num and msg_text:

                            sms_received_add(str(from_num), str(to_num), str(msg_text), panel["name"], str(r_time) if r_time else None)'''

if old_probe_extract in content:
    content = content.replace(old_probe_extract, new_probe_extract)
    print("PATCH PROBE EXTRACT SUCCESS")
else:
    print("PATCH PROBE EXTRACT NOT FOUND")

# 4. Patch api/sms-received route and api/live-received
old_api_routes = '''@app.route("/api/sms-received", methods=["POST"])

def api_sms_received():

    data = request.get_json(silent=True) or {}

    number = data.get("number") or data.get("from") or data.get("sender") or ""

    message = data.get("message") or data.get("text") or data.get("body") or data.get("msg") or ""

    panel = data.get("panel") or data.get("device") or "Webhook"

    if not number or not message:

        return jsonify({"error": "number and message required"}), 400

    sms_received_add(number, message, panel)

    return jsonify({"status": "ok"})





@app.route("/api/live-received")

@login_required

def api_live_received():

    rows = pg.execute(

        "SELECT number, message, panel, received_at FROM sms_received ORDER BY received_at DESC LIMIT 15",

        dict_cursor=True

    )

    return jsonify([{

        "number": r.get("number", ""),

        "message": r.get("message", "")[:80],

        "panel": r.get("panel", ""),

        "received_at": r.get("received_at", "")[:16] if r.get("received_at") else "",

    } for r in rows])'''

new_api_routes = '''@app.route("/api/sms-received", methods=["POST"])

def api_sms_received():

    data = request.get_json(silent=True) or {}

    from_num = data.get("from") or data.get("from_number") or data.get("sender") or data.get("number") or ""

    to_num = data.get("to") or data.get("to_number") or data.get("receiver") or ""

    message = data.get("message") or data.get("text") or data.get("body") or data.get("msg") or ""

    panel = data.get("panel") or data.get("device") or "Webhook"

    if not message or (not from_num and not to_num):

        return jsonify({"error": "message and sender/receiver required"}), 400

    sms_received_add(from_num, to_num, message, panel)

    return jsonify({"status": "ok"})





@app.route("/api/live-received")

@login_required

def api_live_received():

    rows = pg.execute(

        "SELECT id, number, from_number, to_number, message, panel, received_at FROM sms_received ORDER BY received_at DESC, id DESC LIMIT 25",

        dict_cursor=True

    )

    return jsonify([{

        "from": r.get("from_number") or r.get("number") or "-",

        "to": r.get("to_number") or "-",

        "message": r.get("message", ""),

        "panel": r.get("panel", ""),

        "received_at": r.get("received_at", "")[:19] if r.get("received_at") else "",

    } for r in rows])'''

if old_api_routes in content:
    content = content.replace(old_api_routes, new_api_routes)
    print("PATCH API ROUTES SUCCESS")
else:
    print("PATCH API ROUTES NOT FOUND")

# 5. Patch RECEIVED_SMS_PAGE template table and JS
old_page_tpl = '''    <table>

      <thead><tr><th>Number</th><th>Message</th><th>Panel</th><th>Received</th></tr></thead>

      <tbody id="rxSms">

        {% for sms in messages %}

        <tr>

          <td><strong>{{ sms.number }}</strong></td>

          <td>{{ sms.message[:80] if sms.message else '-' }}</td>

          <td class="truncate">{{ sms.panel[:30] if sms.panel else '-' }}</td>

          <td>{{ sms.received_at[:16] if sms.received_at else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not messages %}

        <tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:28px">No received SMS</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<div class="pagination">

  {% if page > 1 %}<a href="/received-sms?page={{ page-1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-left"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-left"></i></span>{% endif %}

  {% for p in range(1, total_pages+1) %}

    {% if p == page %}<span class="current">{{ p }}</span>{% elif p <= 3 or p > total_pages-3 or (p >= page-2 and p <= page+2) %}<a href="/received-sms?page={{ p }}{% if filter_number %}&number={{ filter_number }}{% endif %}">{{ p }}</a>{% elif p == 4 or p == total_pages-3 %}<span class="disabled">...</span>{% endif %}

  {% endfor %}

  {% if page < total_pages %}<a href="/received-sms?page={{ page+1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-right"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-right"></i></span>{% endif %}

</div>

<script>

async function refreshRx(){

  try{var r=await fetch('/api/live-received');if(!r.ok)return;var d=await r.json();

  var tb=document.getElementById('rxSms');if(!tb||d.length===0)return;

  var h='';d.forEach(function(l){

  h+='<tr><td><strong>'+l.number+'</strong></td><td>'+l.message+'</td><td class="truncate">'+l.panel+'</td><td>'+l.received_at+'</td></tr>';

  });tb.innerHTML=h;}catch(e){}

}'''

new_page_tpl = '''    <table>

      <thead><tr><th>From (Sender)</th><th>To (Device SIM)</th><th>Message</th><th>Panel</th><th>Received At</th></tr></thead>

      <tbody id="rxSms">

        {% for sms in messages %}

        <tr>

          <td><strong style="color:#d4a853">{{ sms.from_number or sms.number or '-' }}</strong></td>

          <td><span style="font-weight:600;color:#38bdf8">{{ sms.to_number or '-' }}</span></td>

          <td style="max-width:340px;word-break:break-word">{{ sms.message if sms.message else '-' }}</td>

          <td class="truncate">{{ sms.panel[:30] if sms.panel else '-' }}</td>

          <td>{{ sms.received_at[:19] if sms.received_at else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not messages %}

        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No received SMS</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<div class="pagination">

  {% if page > 1 %}<a href="/received-sms?page={{ page-1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-left"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-left"></i></span>{% endif %}

  {% for p in range(1, total_pages+1) %}

    {% if p == page %}<span class="current">{{ p }}</span>{% elif p <= 3 or p > total_pages-3 or (p >= page-2 and p <= page+2) %}<a href="/received-sms?page={{ p }}{% if filter_number %}&number={{ filter_number }}{% endif %}">{{ p }}</a>{% elif p == 4 or p == total_pages-3 %}<span class="disabled">...</span>{% endif %}

  {% endfor %}

  {% if page < total_pages %}<a href="/received-sms?page={{ page+1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-right"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-right"></i></span>{% endif %}

</div>

<script>

async function refreshRx(){

  try{var r=await fetch('/api/live-received');if(!r.ok)return;var d=await r.json();

  var tb=document.getElementById('rxSms');if(!tb||d.length===0)return;

  var h='';d.forEach(function(l){

  h+='<tr><td><strong style="color:#d4a853">'+escapeHtml(l.from)+'</strong></td><td><span style="font-weight:600;color:#38bdf8">'+escapeHtml(l.to)+'</span></td><td style="max-width:340px;word-break:break-word">'+escapeHtml(l.message)+'</td><td class="truncate">'+escapeHtml(l.panel)+'</td><td>'+escapeHtml(l.received_at)+'</td></tr>';

  });tb.innerHTML=h;}catch(e){}

}'''

if old_page_tpl in content:
    content = content.replace(old_page_tpl, new_page_tpl)
    print("PATCH PAGE TPL SUCCESS")
else:
    print("PATCH PAGE TPL NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
