#!/usr/bin/env python3
"""
Paytm Payment Verification by UTR / RRN
========================================
This module verifies customer payments made to a Paytm UPI QR code
by matching the 12-digit bank reference number (RRN / UTR).
"""

import json
import urllib.request
import urllib.error
import gzip
import paytm_token_refresh
from datetime import datetime, timedelta

# Configuration (from merchant session)
CONFIG = {
    "merchant_id": "uSherH20708687937743",
    "user_token": "09c3fru5p6fu1airnk0w394gz3tlg8za0151",
    "device_id": "OnePlus-GM1901-d7ab42578ca00369",
    "app_version": "9.44.2",
    "auth_ump": "umpapp-3754-36d-aqr-cn7",
}

def _get_headers():
    return {
        "Accept": "*/*",
        "Accept-Encoding": "gzip",
        "Content-Type": "application/json",
        "User-Agent": f"Paytm Release/{CONFIG['app_version']}/904402 (com.paytm.business; Android/12 OnePlus/GM1901)",
        "appversion": CONFIG["app_version"],
        "app-channel": "p4b",
        "client": "androidapp",
        "deviceidentifier": CONFIG["device_id"],
        "osversion": "12",
        "x-id": "d7ab42578ca00369",
        "x-mfg": "OnePlus",
        "x-model": "GM1901",
        "x-auth-ump": CONFIG["auth_ump"],
        "x-user-token": CONFIG["user_token"],
        "x-user-mid": CONFIG["merchant_id"]
    }

def _make_post_request(url, payload, retry=True):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=_get_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=12) as res:
            raw = res.read()
            if res.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        err_msg = raw.decode("utf-8", errors="ignore")
        
        if retry and (e.code in (401, 403, 410) or "token" in err_msg.lower() or "unauthorized" in err_msg.lower()):
            print("[*] Access token seems invalid/expired in verification. Attempting to refresh...")
            refresh_res = paytm_token_refresh.refresh_token()
            if refresh_res.get("success"):
                print("[*] Token refreshed successfully! Updating config and retrying...")
                CONFIG["user_token"] = refresh_res["new_access_token"]
                return _make_post_request(url, payload, retry=False)
            else:
                print("[!] Failed to refresh token:", refresh_res)
                
        raise RuntimeError(f"Paytm API Error ({e.code}): {err_msg}")
    except Exception as ex:
        raise RuntimeError(f"Network error connecting to Paytm: {ex}")

def fetch_recent_orders(days=2):
    """
    Fetch all successful acquiring orders for the past N days.
    """
    url = "https://dashboard.paytm.com/api/v2/order/summary/list"
    now = datetime.now()
    start = (now - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00+05:30")
    end = now.strftime("%Y-%m-%dT23:59:59+05:30")

    payload = {
        "payMethod": "UPI",
        "startDate": start,
        "endDate": end,
        "pageEntryNumber": 1,
        "isDealMid": False,
        "isStoreCashMid": False,
        "bizTypeList": ["ACQUIRING"],
        "orderStatusList": ["SUCCESS"]
    }
    
    resp = _make_post_request(url, payload)
    orders = []
    for day in resp.get("daywiseOrderList", []):
        orders.extend(day.get("orderList", []))
    return orders

def get_order_details(biz_order_id):
    """
    Fetch exact transaction metadata, including 12-digit RRN / UTR.
    """
    url = "https://dashboard.paytm.com/api/v4/order/detail?channel=p4b"
    payload = {
        "bizOrderId": str(biz_order_id),
        "isSettlementInfo": True,
        "version": CONFIG["app_version"],
        "client": "android"
    }
    return _make_post_request(url, payload)

def verify_payment_by_rrn(target_rrn, expected_amount=None):
    """
    Verify if a given 12-digit UTR/RRN exists and is successful.
    
    Parameters:
      target_rrn (str): 12-digit UPI reference number from the customer.
      expected_amount (float or int, optional): Expected payment amount in INR.

    Returns:
      dict: Verification result containing status, match boolean, and receipt details.
    """
    target_rrn = str(target_rrn).strip()
    print(f"[*] Scanning recent transactions for UTR / RRN: {target_rrn}...")
    
    orders = fetch_recent_orders(days=2)
    print(f"[*] Found {len(orders)} recent successful orders. Checking RRN details...")

    for order in orders:
        biz_order_id = order.get("bizOrderId")
        order_amt = float(order.get("payMoneyAmount", {}).get("value", 0)) / 100.0

        # Optimization: if expected_amount is specified, skip non-matching amounts
        if expected_amount is not None and abs(order_amt - float(expected_amount)) > 0.01:
            continue

        detail = get_order_details(biz_order_id)
        add_info = detail.get("additionalInfo", {})
        rrn = add_info.get("rrn")

        if rrn == target_rrn:
            order_status = detail.get("orderStatus")
            bank_status = add_info.get("bankResponseCodeDesc")
            
            if order_status == "SUCCESS":
                return {
                    "verified": True,
                    "message": "Payment verified successfully",
                    "rrn": rrn,
                    "bizOrderId": biz_order_id,
                    "merchantTransId": detail.get("merchantTransId"),
                    "amount": order_amt,
                    "customerName": add_info.get("customerName"),
                    "virtualPaymentAddr": add_info.get("virtualPaymentAddr"),
                    "payerPSP": add_info.get("payerPSP"),
                    "orderCreatedTime": detail.get("orderCreatedTime"),
                    "orderCompletedTime": detail.get("orderCompletedTime"),
                    "status": order_status,
                    "bankStatus": bank_status
                }

    return {
        "verified": False,
        "message": f"No successful transaction found matching RRN '{target_rrn}'" + (f" with amount INR {expected_amount}" if expected_amount else "")
    }

if __name__ == "__main__":
    import sys

    # Test with the latest transaction (RRN: 462995091460, Amount: 1000)
    test_rrn = sys.argv[1] if len(sys.argv) > 1 else "462995091460"
    test_amt = sys.argv[2] if len(sys.argv) > 2 else "1000"

    print("=" * 60)
    print("PAYTM UPI PAYMENT VERIFIER")
    print(f"Testing UTR/RRN: {test_rrn} | Expected Amount: INR {test_amt}")
    print("=" * 60)

    result = verify_payment_by_rrn(test_rrn, expected_amount=test_amt)
    print("\n--- VERIFICATION RESULT ---")
    print(json.dumps(result, indent=2))
