﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

script = '''
import zipfile
import re
import psycopg2
import httpx
import asyncio
import time

# Extract all panels from original files
panels = []
try:
    with open("/app/data/builds/53653872-d508-4d9c-b8c9-c7bed17a3224/khaat_bot.py.bak", "r", encoding="utf-8") as f:
        content = f.read()
    # Find all firebase URLs in content
    urls = set(re.findall(r'https://[a-zA-Z0-9_.-]+(?:firebaseio\.com|firebasedatabase\.app)[^\s"\'\)]*', content))
    print(f"Found {len(urls)} distinct Firebase URLs in backup file.")
except Exception as e:
    print("Error reading backup:", e)
    urls = set()

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT url FROM databases")
existing_urls = set(r[0] for r in cur.fetchall())
print(f"Currently in DB: {len(existing_urls)} URLs.")

urls_to_test = list(urls - existing_urls)
print(f"URLs to test for device data to restore: {len(urls_to_test)}")

async def probe_url(client, url, sem):
    base = url.rstrip("/")
    cb = int(time.time() * 1000)
    if "?" in base:
        base_clean, query = base.split("?", 1)
        clients_url = f"{base_clean}/clients.json?{query}&_cb={cb}"
    else:
        clients_url = f"{base}/clients.json?_cb={cb}"
        
    async with sem:
        try:
            r = await client.get(clients_url, timeout=httpx.Timeout(6.0, connect=4.0))
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and len(data) > 0:
                    return {"url": url, "devices": len(data), "keep": True}
        except Exception:
            pass
        return {"url": url, "devices": 0, "keep": False}

async def main():
    sem = asyncio.Semaphore(40)
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as client:
        tasks = [probe_url(client, u, sem) for u in urls_to_test]
        results = await asyncio.gather(*tasks)

    restore_list = [r for r in results if r["keep"]]
    print(f"Found {len(restore_list)} working panels with registered devices to restore!")
    
    import uuid
    inserted = 0
    for item in restore_list:
        u = item["url"]
        name = u.split("//")[1].split(".")[0]
        did = str(uuid.uuid4())
        try:
            cur.execute(
                "INSERT INTO databases (id, url, name, added, status, sms_sent, devices_online) VALUES (%s, %s, %s, %s, 'active', 0, 0) ON CONFLICT (url) DO UPDATE SET status = 'active'",
                (did, u, name, "2026-09-17")
            )
            inserted += 1
        except Exception:
            pass
    conn.commit()
    print(f"Restored {inserted} panels into PostgreSQL.")
    
    cur.execute("SELECT count(*) FROM databases")
    total = cur.fetchone()[0]
    print(f"Total panels now in PostgreSQL: {total}")
    
    cur.close()
    conn.close()

asyncio.run(main())
'''

s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'restore_working.py', 'content': script})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp restore_working.py cowbox-khaat-968826:/app/restore_working.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/restore_working.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
