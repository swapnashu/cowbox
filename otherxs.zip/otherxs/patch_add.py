﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

old_add = '''def usr_add_balance(uid, amount):

    existing = usr_get(uid)

    if not existing:

        usr_add(uid, amount)

        return

    pg.execute_write(

        "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",

        (amount, uid),

    )'''

new_add = '''def usr_add_balance(uid, amount):

    uid_str = str(uid).strip()

    amt = float(amount)

    existing = usr_get(uid_str)

    if not existing:

        usr_add(uid_str, amt)

    else:

        pg.execute_write(

            "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",

            (amt, uid_str),

        )

    if rds:

        try:

            rds.delete(f"user:{uid_str}")

        except Exception:

            pass'''

if old_add in content:
    content = content.replace(old_add, new_add)
    print("PATCH USR_ADD SUCCESS")
else:
    print("PATCH USR_ADD NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
