﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

# 1. Clean the old outgoing messages from sms_received table
clean_cmd = '''docker exec cowbox-db-khaat-pg psql -U postgres -d aat -c "
DELETE FROM sms_received WHERE from_number IS NULL OR from_number = '' OR to_number IS NULL OR to_number = '';
SELECT count(*) as remaining_real_incoming FROM sms_received;
"'''
r_clean = s.post('http://13.207.147.149:9999/api/files/run', json={'command': clean_cmd})
print("Clean old outgoing records:", r_clean.json().get('stdout'))
