﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    text = f.read()

import re
corrupted = re.findall(r'\?{2,}', text)
print(f"Found {len(corrupted)} occurrences of multiple '??'")
if corrupted:
    print("Samples:", corrupted[:10])
