﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines[1640:1700]):
    print(f"{1640+i}: {line.encode('ascii', 'backslashreplace').decode()}")
