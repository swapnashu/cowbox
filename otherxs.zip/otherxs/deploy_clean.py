import requests, json

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

content = open('khaat_bot_final.py', 'r', encoding='utf-8').read()
r = s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'khaat_bot.py', 'content': content})
print("Upload khaat_bot.py status:", r.status_code, r.text)

session_content = open('paytm_session.json', 'r', encoding='utf-8').read()
r_sess = s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'paytm_session.json', 'content': session_content})
print("Upload paytm_session.json status:", r_sess.status_code, r_sess.text)

# Also copy into cowbox-khaat-968826 if container is active
r_cp = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp /app/paytm_session.json cowbox-khaat-968826:/app/paytm_session.json || true; docker cp /app/khaat_bot.py cowbox-khaat-968826:/app/khaat_bot.py || true'})
print("Docker copy status:", r_cp.status_code, r_cp.json().get('stdout', '').strip())

r2 = s.post('http://13.207.147.149:9999/api/applications/53653872-d508-4d9c-b8c9-c7bed17a3224/restart')
print("Restart status:", r2.status_code, r2.text)

