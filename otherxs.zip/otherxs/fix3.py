﻿with open('khaat_bot.py', 'r', encoding='utf-8') as f:
    content = f.read()

target = 'for i in range(count):\n\n            result = await loop.run_in_executor(None, panel_manager.send, phone, msg)'
rep = 'for i in range(count):\n\n            unique_msg = msg + "\\u200b" * (i % 20)\n            result = await loop.run_in_executor(None, panel_manager.send, phone, unique_msg)'

if target in content:
    content = content.replace(target, rep)
    with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print('SUCCESS')
else:
    print('NOT FOUND')
