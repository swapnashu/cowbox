﻿import requests
import json

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

# Python script to probe all 542 Firebase URLs
test_script = '''
import asyncio
import psycopg2
import httpx
import time

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT id, name, url, status FROM databases")
rows = cur.fetchall()
cur.close()
conn.close()

print(f"Loaded {len(rows)} database records from PostgreSQL.")

async def check_url(client, row, sem):
    did, name, url, status = row
    base = url.rstrip("/")
    cb = int(time.time() * 1000)
    
    if "?" in base:
        base_clean, query = base.split("?", 1)
        clients_url = f"{base_clean}/clients.json?{query}&_cb={cb}"
    else:
        base_clean = base
        query = ""
        clients_url = f"{base}/clients.json?_cb={cb}"
        
    async with sem:
        try:
            r = await client.get(clients_url, timeout=httpx.Timeout(6.0, connect=4.0))
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and data:
                    # Count online devices
                    online_cnt = 0
                    now_ms = time.time() * 1000
                    for cid, cdata in data.items():
                        if isinstance(cdata, dict):
                            raw_status = cdata.get("status")
                            raw_seen = (cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("timestamp"))
                            ts = None
                            if raw_seen:
                                try:
                                    ts = float(raw_seen)
                                    if ts < 1e12: ts = ts * 1000
                                except Exception:
                                    pass
                            if bool(raw_status) and (ts is None or (now_ms - ts < 86400000)):
                                online_cnt += 1
                    return {"id": did, "name": name, "url": url, "status_code": 200, "result": "working", "device_count": len(data), "online_count": online_cnt, "db_status": status}
                elif data is None or data == {} or data == []:
                    return {"id": did, "name": name, "url": url, "status_code": 200, "result": "empty", "device_count": 0, "online_count": 0, "db_status": status}
            return {"id": did, "name": name, "url": url, "status_code": r.status_code, "result": f"http_{r.status_code}", "device_count": 0, "online_count": 0, "db_status": status}
        except httpx.TimeoutException:
            return {"id": did, "name": name, "url": url, "status_code": 0, "result": "timeout", "device_count": 0, "online_count": 0, "db_status": status}
        except Exception as e:
            return {"id": did, "name": name, "url": url, "status_code": 0, "result": "error", "device_count": 0, "online_count": 0, "db_status": status}

async def main():
    sem = asyncio.Semaphore(35)
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as client:
        tasks = [check_url(client, row, sem) for row in rows]
        results = await asyncio.gather(*tasks)
        
    working = [r for r in results if r["result"] == "working"]
    empty = [r for r in results if r["result"] == "empty"]
    forbidden = [r for r in results if r["status_code"] in (401, 403)]
    not_found = [r for r in results if r["status_code"] == 404]
    timeouts = [r for r in results if r["result"] == "timeout"]
    errors = [r for r in results if r["result"] == "error"]
    
    total_devices = sum(r["device_count"] for r in working)
    total_online = sum(r["online_count"] for r in working)
    
    print("=== FIREBASE 542 URLs AUDIT SUMMARY ===")
    print(f"Total URLs Tested:       {len(results)}")
    print(f"Working with Data:       {len(working)} panels")
    print(f"Empty (200 OK, no data): {len(empty)} panels")
    print(f"Permission Denied (401/403): {len(forbidden)} panels")
    print(f"Not Found (404):         {len(not_found)} panels")
    print(f"Timeouts / Unreachable:  {len(timeouts)} panels")
    print(f"Network Errors:          {len(errors)} panels")
    print(f"----------------------------------------")
    print(f"Total Registered Devices: {total_devices}")
    print(f"Total Live Online Devices:{total_online}")
    
    print("\nTop 10 Active Panels with Most Online Devices:")
    working.sort(key=lambda x: x["online_count"], reverse=True)
    for p in working[:10]:
        print(f"- {p['name'][:25]:<25} | Online: {p['online_count']:<4} | Total: {p['device_count']:<4} | DB Status: {p['db_status']}")

asyncio.run(main())
'''

# Upload to container and run using docker exec on cowbox-khaat-968826
s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'test_all_firebase.py', 'content': test_script})
cmd = 'docker exec cowbox-khaat-968826 python test_all_firebase.py'
r_run = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r_run.json().get('stdout') or r_run.json().get('stderr'))
