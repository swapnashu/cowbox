import json
import urllib.request
import urllib.error

SESSION_FILE = "paytm_session.json"

DEFAULT_SESSION = {
    "merchant_id": "uSherH20708687937743",
    "refresh_token": "0e8upwnmg85x75x9ilrt895drptlg8za0121",
    "access_token": "09wrobxczoadyqg8k91w1zmyietlggw00111",
    "device_id": "OnePlus-GM1901-d7ab42578ca00369",
    "expires_in": "1821095424000"
}

def load_session() -> dict:
    try:
        with open(SESSION_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return DEFAULT_SESSION.copy()

def save_session(session_data: dict):
    with open(SESSION_FILE, "w") as f:
        json.dump(session_data, f, indent=2)

def refresh_token() -> dict:
    session = load_session()
    url = "https://accounts.paytm.com/oauth2/v3/token/sv1?client=androidapp"
    headers = {
        "Content-Type": "application/json",
        "Accept": "*/*",
        "Authorization": "Basic UGF5dG0tU2VjdXJlLUJ1c2luZXNzLWFwcDo4Yjg1ZDJmMS1lZDk1LTRlNTAtOWJlNy02YTdhNDlhOGM5ZGY=",
        "x-device-identifier": session["device_id"],
        "x-device-name": "GM1901",
        "x-mfg": "OnePlus",
        "x-model": "GM1901",
        "x-id": "d7ab42578ca00369",
        "x-app-version": "9.44.2"
    }

    payload = {
        "grantType": "refresh_token",
        "deviceId": session["device_id"],
        "refreshToken": session["refresh_token"]
    }

    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=12) as res:
            data = json.loads(res.read().decode("utf-8"))
            tokens = data.get("tokens", [])
            for t in tokens:
                if t.get("scope") == "paytm" or t.get("tokenType") == "BEARER":
                    session["access_token"] = t.get("accessToken")
                    session["expires_in"] = t.get("expiresIn")
                    save_session(session)
                    return {
                        "success": True,
                        "new_access_token": session["access_token"],
                        "expires_in": session["expires_in"]
                    }
            return {"success": False, "raw": data}
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="ignore")
        return {"success": False, "error_code": e.code, "message": err}
    except Exception as ex:
        return {"success": False, "error": str(ex)}

if __name__ == "__main__":
    print(json.dumps(refresh_token(), indent=2))
