﻿with open('decoded.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for line in lines[2800:2890]:
    print(line.encode('ascii', 'backslashreplace').decode())
