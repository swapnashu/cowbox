﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

content = open('probe542_clean.py', 'r', encoding='utf-8').read()
s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'probe542_clean.py', 'content': content})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp probe542_clean.py cowbox-khaat-968826:/app/probe542_clean.py'})

r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/probe542_clean.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
