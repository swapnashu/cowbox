﻿import requests
import json

s = requests.Session()
login_url = 'http://13.207.147.149:9999/api/auth/login'
data = {'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'}
r = s.post(login_url, json=data)
print('Login Status:', r.status_code)

try:
    r_proj = s.get('http://13.207.147.149:9999/api/projects')
    print('Projects:', r_proj.status_code, r_proj.text)
except Exception as e:
    print(e)
