﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})
r = s.get('http://13.207.147.149:9999/api/files/read?path=khaat_b64.txt')
data = r.json()
with open('khaat_b64.txt', 'w', encoding='utf-8') as f:
    f.write(data['content'])
