﻿import re

urls = set()
for fname in ['decoded.py', 'khaat_b64.txt', 'khaat_bot.py', 'khaat_bot_fixed.py', 'khaat_bot_final.py']:
    try:
        with open(fname, 'r', encoding='utf-8', errors='ignore') as f:
            c = f.read()
        found = re.findall(r'https://[a-zA-Z0-9_\.\-]+(?:firebaseio\.com|firebasedatabase\.app)[^\s"\'\)\,\}\\]*', c)
        for u in found:
            urls.add(u.strip())
    except Exception as e:
        print("Error reading:", fname, e)

print(f"Total distinct Firebase URLs discovered in local workspace: {len(urls)}")

# Also let's check if there are URLs in the cowbox server
with open('all_discovered_urls.json', 'w', encoding='utf-8') as f:
    import json
    json.dump(list(urls), f)
