﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

# Patch setting_set
for i, line in enumerate(lines):
    if 'def setting_set(key, value):' in line:
        for j in range(i, i+15):
            if 'def setting_all():' in lines[j]:
                replacement = '''def setting_set(key, value):
    global settings_cache, SMS_COST
    val_str = str(value) if value is not None else ""
    pg.execute_write(
        "INSERT INTO settings (key, value) VALUES (%s,%s) ON CONFLICT (key) DO UPDATE SET value = %s",
        (key, val_str, val_str),
    )
    settings_cache[key] = val_str
    if key == "sms_cost":
        try:
            SMS_COST = float(val_str)
        except Exception:
            pass'''.splitlines()
                lines = lines[:i] + replacement + lines[j:]
                print("PATCH SETTING_SET OK")
                break
        break

# Patch usr_update
for i, line in enumerate(lines):
    if 'def usr_update(uid, **kwargs):' in line:
        for j in range(i, i+40):
            if 'def usr_list_page(' in lines[j]:
                replacement = '''def usr_update(uid, **kwargs):
    uid_str = str(uid).strip()
    sets = []
    vals = []
    for k, v in kwargs.items():
        if k not in _ALLOWED_USER_COLS:
            continue
        sets.append(f"{k} = %s")
        vals.append(v)
    if sets:
        vals.append(uid_str)
        pg.execute_write(f"UPDATE users SET {', '.join(sets)} WHERE user_id = %s", vals)
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass


def usr_ban(uid, reason=""):
    usr_update(uid, banned=1, ban_reason=reason)


def usr_unban(uid):
    usr_update(uid, banned=0, ban_reason="")


def usr_delete(uid):
    uid_str = str(uid).strip()
    pg.execute_write("DELETE FROM users WHERE user_id = %s", (uid_str,))
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass'''.splitlines()
                lines = lines[:i] + replacement + lines[j:]
                print("PATCH USR_MGMT OK")
                break
        break

with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
