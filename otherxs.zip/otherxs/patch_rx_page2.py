﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

new_rx_page = '''RECEIVED_SMS_PAGE = """
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">
  <h1 style="margin:0"><i class="fas fa-inbox accent"></i> <span class="accent">Received</span> <span class="gold">SMS</span></h1>
  <div style="display:flex;gap:12px;align-items:center">
    <span style="font-size:12px;color:#22c55e;font-weight:600"><i class="fas fa-circle" style="animation:pulse 1.5s infinite"></i> Live Feed</span>
    <span style="font-size:13px;color:#64748b;font-weight:500">{{ total }} incoming messages</span>
  </div>
</div>
<style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}</style>

<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-inbox"></i> Incoming SMS Feed</h2>
    <form method="GET" action="/received-sms" style="display:flex;gap:8px;align-items:center">
      <div class="search-box" style="margin:0;width:280px">
        <i class="fas fa-search"></i>
        <input type="text" name="number" class="input" value="{{ filter_number }}" placeholder="Search Sender or Receiver...">
      </div>
      <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-filter"></i></button>
      {% if filter_number %}<a href="/received-sms" class="btn btn-outline btn-sm"><i class="fas fa-times"></i> Clear</a>{% endif %}
    </form>
  </div>
  <div class="card-body" style="overflow-x:auto;padding:0">
    <table>
      <thead>
        <tr>
          <th style="width:18%"><i class="fas fa-user"></i> From (Sender)</th>
          <th style="width:18%"><i class="fas fa-sim-card"></i> To (Receiver SIM)</th>
          <th><i class="fas fa-comment-dots"></i> Message</th>
          <th style="width:16%"><i class="fas fa-server"></i> Panel</th>
          <th style="width:16%"><i class="fas fa-clock"></i> Received At</th>
        </tr>
      </thead>
      <tbody id="rxSms">
        {% for sms in messages %}
        <tr>
          <td><strong style="color:#d4a853">{{ sms.from_number or sms.number or '-' }}</strong></td>
          <td><span style="font-weight:600;color:#38bdf8">{{ sms.to_number or '-' }}</span></td>
          <td style="max-width:340px;word-break:break-word">{{ sms.message if sms.message else '-' }}</td>
          <td class="truncate">{{ sms.panel[:30] if sms.panel else '-' }}</td>
          <td>{{ sms.received_at[:19] if sms.received_at else '-' }}</td>
        </tr>
        {% endfor %}
        {% if not messages %}
        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:32px"><i class="fas fa-inbox" style="font-size:24px;margin-bottom:8px;display:block;opacity:0.4"></i>No incoming SMS yet. Real incoming messages from devices or webhook will appear here live.</td></tr>
        {% endif %}
      </tbody>
    </table>
  </div>
</div>

<div class="pagination">
  {% if page > 1 %}<a href="/received-sms?page={{ page-1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-left"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-left"></i></span>{% endif %}
  {% for p in range(1, total_pages+1) %}
    {% if p == page %}<span class="current">{{ p }}</span>{% elif p <= 3 or p > total_pages-3 or (p >= page-2 and p <= page+2) %}<a href="/received-sms?page={{ p }}{% if filter_number %}&number={{ filter_number }}{% endif %}">{{ p }}</a>{% elif p == 4 or p == total_pages-3 %}<span class="disabled">...</span>{% endif %}
  {% endfor %}
  {% if page < total_pages %}<a href="/received-sms?page={{ page+1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-right"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-right"></i></span>{% endif %}
</div>

<script>
function escapeHtml(t){if(!t)return'';return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
async function refreshRx(){
  try{
    var r = await fetch('/api/live-received');
    if(!r.ok) return;
    var d = await r.json();
    var tb = document.getElementById('rxSms');
    if(!tb || d.length === 0) return;
    var h = '';
    d.forEach(function(l){
      h += '<tr>' +
           '<td><strong style="color:#d4a853">' + escapeHtml(l.from) + '</strong></td>' +
           '<td><span style="font-weight:600;color:#38bdf8">' + escapeHtml(l.to) + '</span></td>' +
           '<td style="max-width:340px;word-break:break-word">' + escapeHtml(l.message) + '</td>' +
           '<td class="truncate">' + escapeHtml(l.panel) + '</td>' +
           '<td>' + escapeHtml(l.received_at) + '</td>' +
           '</tr>';
    });
    tb.innerHTML = h;
  }catch(e){}
}
setInterval(refreshRx, 3500);
</script>
"""'''.splitlines()

start = None
end = None
for i, line in enumerate(lines):
    if 'RECEIVED_SMS_PAGE = ' in line:
        start = i
    if start is not None and 'LAYOUT = ' in line:
        end = i
        break

if start is not None and end is not None:
    lines = lines[:start] + new_rx_page + lines[end:]
    print("SUCCESS")
    with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
else:
    print("FAILED", start, end)
