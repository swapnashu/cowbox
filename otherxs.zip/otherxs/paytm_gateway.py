import json
import urllib.request
import urllib.parse
import urllib.error
import gzip
import paytm_token_refresh
from datetime import datetime, timedelta

SESSION_FILE = "paytm_session.json"

def get_session():
    try:
        with open(SESSION_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {
            "merchant_id": "uSherH20708687937743",
            "access_token": "03qvjzmy4ehddlugomh0md58pdtlgl000101"
        }

CONFIG = {
    "auth_ump": "umpapp-3754-36d-aqr-cn7",
    "vpa": "paytm.s2fqznb@pty",
    "merchant_name": "Durgesh Sharma",
    "app_version": "9.44.2"
}

def get_headers():
    session = get_session()
    return {
        "Content-Type": "application/json",
        "x-user-token": session["access_token"],
        "x-user-mid": session["merchant_id"],
        "x-auth-ump": CONFIG["auth_ump"]
    }

def create_payment_request(amount: float, order_id: str, note: str = "Payment") -> dict:
    session = get_session()
    params = {
        "pa": CONFIG["vpa"],
        "pn": CONFIG["merchant_name"],
        "am": f"{float(amount):.2f}",
        "cu": "INR",
        "tn": f"{order_id} - {note}"
    }
    upi_url = f"upi://pay?{urllib.parse.urlencode(params)}"
    qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={urllib.parse.quote(upi_url)}"
    
    return {
        "order_id": order_id,
        "amount": float(amount),
        "vpa": CONFIG["vpa"],
        "upi_url": upi_url,
        "qr_code_url": qr_url
    }

def _api_post(url: str, payload: dict, retry=True) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=get_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read()
            if response.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        err_msg = raw.decode("utf-8", errors="ignore")
        
        # Check for invalid token (401, 403, or specific error message)
        if retry and (e.code in (401, 403, 410) or "token" in err_msg.lower() or "unauthorized" in err_msg.lower()):
            print("[*] Access token seems invalid/expired. Attempting to refresh...")
            refresh_res = paytm_token_refresh.refresh_token()
            if refresh_res.get("success"):
                print("[*] Token refreshed successfully! Retrying request...")
                return _api_post(url, payload, retry=False)
            else:
                print("[!] Failed to refresh token:", refresh_res)
                
        raise RuntimeError(f"API error {e.code}: {err_msg}")

def verify_payment(utr: str, expected_amount: float = None, lookback_days: int = 1) -> dict:
    clean_utr = str(utr).strip()
    now = datetime.now()
    start_date = (now - timedelta(days=lookback_days)).strftime("%Y-%m-%dT00:00:00+05:30")
    end_date = now.strftime("%Y-%m-%dT23:59:59+05:30")

    list_url = "https://dashboard.paytm.com/api/v2/order/summary/list"
    list_payload = {
        "payMethod": "UPI",
        "startDate": start_date,
        "endDate": end_date,
        "pageEntryNumber": 1,
        "isDealMid": False,
        "isStoreCashMid": False,
        "bizTypeList": ["ACQUIRING"],
        "orderStatusList": ["SUCCESS"]
    }

    list_response = _api_post(list_url, list_payload)
    orders = []
    for day in list_response.get("daywiseOrderList", []):
        orders.extend(day.get("orderList", []))

    candidates = []
    for order in orders:
        amt = float(order.get("payMoneyAmount", {}).get("value", 0)) / 100.0
        if expected_amount is None or abs(amt - float(expected_amount)) < 0.01:
            candidates.append((order.get("bizOrderId"), amt))

    detail_url = "https://dashboard.paytm.com/api/v4/order/detail?channel=p4b"
    for biz_order_id, amt in candidates:
        detail = _api_post(detail_url, {
            "bizOrderId": str(biz_order_id),
            "isSettlementInfo": True,
            "version": CONFIG["app_version"],
            "client": "android"
        })

        add_info = detail.get("additionalInfo", {})
        order_rrn = add_info.get("rrn")
        order_status = detail.get("orderStatus")

        if order_rrn == clean_utr and order_status == "SUCCESS":
            return {
                "verified": True,
                "message": "Payment verified successfully",
                "utr": clean_utr,
                "amount": amt,
                "customer_name": add_info.get("customerName"),
                "customer_vpa": add_info.get("virtualPaymentAddr"),
                "payer_app": add_info.get("payerPSP"),
                "biz_order_id": biz_order_id,
                "merchant_trans_id": detail.get("merchantTransId"),
                "completed_time": detail.get("orderCompletedTime"),
                "status": order_status
            }

    return {
        "verified": False,
        "message": f"No successful payment found matching UTR '{clean_utr}'"
    }

if __name__ == "__main__":
    import sys
    test_utr = sys.argv[1] if len(sys.argv) > 1 else "589434957936"
    test_amount = float(sys.argv[2]) if len(sys.argv) > 2 else 1000.0
    print(json.dumps(verify_payment(utr=test_utr, expected_amount=test_amount), indent=2))
