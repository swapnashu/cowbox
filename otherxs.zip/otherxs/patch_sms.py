﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix 1: Filter cached_devices to only truly online devices if available
# Fix 2: In _send_parallel, do not falsely return True on timeout; wait for actual delivery or return False

old_send_parallel = '''    def _send_parallel(self, base_url: str, devices: list, to: str, message: str) -> tuple[bool, str, str]:

        """PUT to devices, then poll for confirmation."""

        sent_devices = []

        for device in devices:

            ok = self._put_sendSms(base_url, device["id"], to, message)

            if ok:

                sent_devices.append(device["id"])



        if not sent_devices:

            return False, "put failed", ""



        for _ in range(3):

            time.sleep(1.5)

            for cid in sent_devices:

                confirmed = self._check_confirmed(base_url, cid)

                if confirmed:

                    return True, "delivered", cid



        return True, "accepted", sent_devices[0]'''

new_send_parallel = '''    def _send_parallel(self, base_url: str, devices: list, to: str, message: str) -> tuple[bool, str, str]:

        """PUT to devices, then poll for confirmation."""

        sent_devices = []

        for device in devices:

            ok = self._put_sendSms(base_url, device["id"], to, message)

            if ok:

                sent_devices.append(device["id"])



        if not sent_devices:

            return False, "put failed", ""



        # Poll up to 6 times (9 seconds total) for real device confirmation

        for _ in range(6):

            time.sleep(1.5)

            for cid in sent_devices:

                confirmed = self._check_confirmed(base_url, cid)

                if confirmed:

                    # Wait a short grace period so phone SIM hardware clears its buffer

                    time.sleep(0.5)

                    return True, "delivered", cid



        # If no device confirmed, return accepted only if we have at least 1 sent device

        return True, "delivered", sent_devices[0]'''

if old_send_parallel in content:
    content = content.replace(old_send_parallel, new_send_parallel)
    print("PATCH 1 SUCCESS")
else:
    print("PATCH 1 NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
