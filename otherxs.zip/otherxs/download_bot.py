﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})
r = s.get('http://13.207.147.149:9999/api/files/raw?path=khaat_bot.py')
with open('khaat_bot.py', 'wb') as f:
    f.write(r.content)
print(r.status_code, "Downloaded khaat_bot.py")
