﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = 'docker logs cowbox-khaat-968826 2>&1 | grep -o "https://[a-zA-Z0-9_.-]*firebase[a-zA-Z0-9_.-]*" | sort -u'
r = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
lines = r.json().get('stdout', '').strip().split('\n')
print(f"Discovered {len(lines)} distinct Firebase URLs from live container logs!")

# Let's save these URLs to a file in cowbox
import json
urls = [l.strip() for l in lines if l.strip()]
s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'recovered_urls.json', 'content': json.dumps(urls)})
