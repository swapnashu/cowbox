﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Patch sms_received_add with deduplication
old_add = '''def sms_received_add(number, message, panel=""):

    pg.execute_write(

        "INSERT INTO sms_received (number, message, panel, received_at) VALUES (%s,%s,%s,%s)",

        (number, message, panel, datetime.now().isoformat())

    )'''

new_add = '''def sms_received_add(number, message, panel="", received_at=None):

    if not number or not message:

        return

    try:

        existing = pg.execute_one(

            "SELECT id FROM sms_received WHERE number = %s AND message = %s LIMIT 1",

            (str(number), str(message))

        )

        if existing:

            return

        ts = received_at or datetime.now().isoformat()

        pg.execute_write(

            "INSERT INTO sms_received (number, message, panel, received_at) VALUES (%s,%s,%s,%s)",

            (str(number), str(message), str(panel), str(ts))

        )

    except Exception:

        pass'''

if old_add in content:
    content = content.replace(old_add, new_add)
    print("PATCH ADD SUCCESS")
else:
    print("PATCH ADD NOT FOUND")

# 2. Patch probe client loop to parse incoming SMS
old_probe_dev = '''                all_devices.append({

                    "id": cid,

                    "panel": panel["name"],

                    "panel_url": panel["url"].rstrip("/"),

                    "number": mobno,

                    "battery": battery,

                    "sim_info": sim_info.rstrip(" | ") if sim_info else "-",

                    "webhook_ready": bool(cdata.get("webhookEvent")),

                    "is_online": is_online,

                })'''

new_probe_dev = '''                all_devices.append({

                    "id": cid,

                    "panel": panel["name"],

                    "panel_url": panel["url"].rstrip("/"),

                    "number": mobno,

                    "battery": battery,

                    "sim_info": sim_info.rstrip(" | ") if sim_info else "-",

                    "webhook_ready": bool(cdata.get("webhookEvent")),

                    "is_online": is_online,

                })

                # Automatically extract and store received incoming SMS
                for sms_key in ("receivedSms", "received_sms", "inbox", "sms", "messages", "smsList", "sms_received"):

                    sms_container = cdata.get(sms_key)

                    if not sms_container:

                        continue

                    items = []

                    if isinstance(sms_container, dict):

                        items = list(sms_container.values())

                    elif isinstance(sms_container, list):

                        items = sms_container

                    for item in items[-15:]:

                        if isinstance(item, dict):

                            from_num = item.get("from") or item.get("number") or item.get("sender") or item.get("phone") or ""

                            msg_text = item.get("message") or item.get("msg") or item.get("body") or item.get("text") or item.get("messageText") or ""

                            r_time = item.get("received_at") or item.get("timestamp") or item.get("date") or item.get("time") or ""

                            if from_num and msg_text:

                                sms_received_add(str(from_num), str(msg_text), panel["name"], str(r_time) if r_time else None)'''

if old_probe_dev in content:
    content = content.replace(old_probe_dev, new_probe_dev)
    print("PATCH PROBE SUCCESS")
else:
    print("PATCH PROBE NOT FOUND")

# 3. Add api/sms-received route
old_routes = '''@app.route("/api/live-received")

@login_required

def api_live_received():'''

new_routes = '''@app.route("/api/sms-received", methods=["POST"])

def api_sms_received():

    data = request.get_json(silent=True) or {}

    number = data.get("number") or data.get("from") or data.get("sender") or ""

    message = data.get("message") or data.get("text") or data.get("body") or data.get("msg") or ""

    panel = data.get("panel") or data.get("device") or "Webhook"

    if not number or not message:

        return jsonify({"error": "number and message required"}), 400

    sms_received_add(number, message, panel)

    return jsonify({"status": "ok"})





@app.route("/api/live-received")

@login_required

def api_live_received():'''

if old_routes in content:
    content = content.replace(old_routes, new_routes)
    print("PATCH ROUTE SUCCESS")
else:
    print("PATCH ROUTE NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
