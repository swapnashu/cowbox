﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})
content = open('khaat_bot_fixed.py', 'r', encoding='utf-8').read()
r = s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'khaat_bot.py', 'content': content})
print(r.status_code, r.text)
