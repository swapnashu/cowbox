﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if 'async def post_init(' in line:
        for j in range(i, i+60):
            print(f"{j}: {lines[j].encode('ascii', 'backslashreplace').decode()}")
        break
