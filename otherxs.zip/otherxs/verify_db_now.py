﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = '''docker exec cowbox-db-khaat-pg psql -U postgres -d aat -c "
SELECT count(*) as total_panels_in_db,
       sum(case when status='active' then 1 else 0 end) as active_panels,
       sum(case when status!='active' then 1 else 0 end) as inactive_panels
FROM databases;
"'''
r = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r.json().get('stdout'))
