﻿with open('khaat_bot.py', 'r', encoding='utf-8') as f:
    content = f.read()
import re
new_content = re.sub(
    r'for i in range\(count\):\n\s*result = await loop\.run_in_executor\(None, panel_manager\.send, phone, msg\)',
    'for i in range(count):\n            unique_msg = msg + "\\u200b" * (i % 20)\n            result = await loop.run_in_executor(None, panel_manager.send, phone, unique_msg)',
    content, flags=re.MULTILINE
)
with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(new_content)
