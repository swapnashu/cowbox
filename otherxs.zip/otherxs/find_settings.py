﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if '@app.route("/settings"' in line or 'SETTINGS_PAGE = ' in line:
        print(f"Line {i}: {line.encode('ascii', 'backslashreplace').decode()}")
