﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i in range(1640, min(len(lines), 1680)):
    print(f"{i}: {lines[i]}")
