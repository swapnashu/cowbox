﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = '''docker exec cowbox-db-khaat-pg psql -U postgres -d aat -c "
SELECT count(*) as total_panels, 
       sum(case when status='active' then 1 else 0 end) as active_panels,
       sum(case when status!='active' then 1 else 0 end) as disabled_panels,
       sum(devices_online) as total_devices_reported,
       sum(sms_sent) as total_sms_sent
FROM databases;
"'''
r_run = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print("=== Database Panels Summary ===")
print(r_run.json().get('stdout'))

# Also get live probe stats from the running app
r_stats = requests.get('http://13.207.147.149:5050/api/dashboard-stats', timeout=10)
print("=== Live Dashboard Stats ===")
print(r_stats.text)
