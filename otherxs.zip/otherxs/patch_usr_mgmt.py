﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

start = None
end = None
for i, line in enumerate(lines):
    if 'def usr_update(uid, **kwargs):' in line:
        start = i
    if start is not None and 'def usr_list_page(' in line:
        end = i
        break

if start is not None and end is not None:
    replacement = '''def usr_update(uid, **kwargs):
    uid_str = str(uid).strip()
    sets = []
    vals = []
    for k, v in kwargs.items():
        if k not in _ALLOWED_USER_COLS:
            continue
        sets.append(f"{k} = %s")
        vals.append(v)
    if sets:
        vals.append(uid_str)
        pg.execute_write(f"UPDATE users SET {', '.join(sets)} WHERE user_id = %s", vals)
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass


def usr_ban(uid, reason=""):
    usr_update(uid, banned=1, ban_reason=reason)


def usr_unban(uid):
    usr_update(uid, banned=0, ban_reason="")


def usr_delete(uid):
    uid_str = str(uid).strip()
    pg.execute_write("DELETE FROM users WHERE user_id = %s", (uid_str,))
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass'''.splitlines()
    lines = lines[:start] + replacement + lines[end:]
    print("SUCCESS")
    with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
else:
    print("FAILED", start, end)
