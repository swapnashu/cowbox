﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

script = '''
import psycopg2
import httpx
import json

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT url, name FROM databases LIMIT 5")
panels = cur.fetchall()
cur.close()
conn.close()

with httpx.Client(verify=False, timeout=10) as client:
    for url, name in panels:
        base = url.rstrip("/")
        clients_url = base + "/clients.json"
        try:
            r = client.get(clients_url)
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and data:
                    print(f"\n================ Panel: {name} ================")
                    first_cid = list(data.keys())[0]
                    cdata = data[first_cid]
                    print("Client ID:", first_cid)
                    print("Top-level keys in client:", list(cdata.keys()) if isinstance(cdata, dict) else type(cdata))
                    
                    # Check SMS keys
                    for k in ("sms", "receivedSms", "received_sms", "inbox", "messages", "smsList", "webhookEvent", "action", "smsCommand"):
                        if k in cdata:
                            val = cdata[k]
                            print(f"Key [{k}]: type={type(val).__name__}")
                            if isinstance(val, dict):
                                print(f"  Subkeys: {list(val.keys())[:5]}")
                                first_sub = list(val.values())[0]
                                if isinstance(first_sub, dict):
                                    print(f"  Sample item: {first_sub}")
                            elif isinstance(val, list) and val:
                                print(f"  Sample list item: {val[0]}")
        except Exception as e:
            print(f"Error on {name}: {e}")
'''

s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'inspect_firebase_schema.py', 'content': script})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp inspect_firebase_schema.py cowbox-khaat-968826:/app/inspect_firebase_schema.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/inspect_firebase_schema.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
