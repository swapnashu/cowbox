﻿import requests
r = requests.get('https://13.207.147.149/login', headers={'Host': 'khaat.13.207.147.149.sslip.io'}, verify=False, timeout=5)
print("HTTPS Traefik Status:", r.status_code)
