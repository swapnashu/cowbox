﻿with open('decoded.py', 'r', encoding='utf-8') as f:
    text = f.read()

count_rupee = text.count('₹')
count_emojis = sum(1 for c in text if ord(c) > 10000)
print(f"Decoded.py has {count_rupee} ₹ symbols and {count_emojis} high unicode/emojis!")
