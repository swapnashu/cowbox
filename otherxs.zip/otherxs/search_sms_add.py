﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if 'sms_received_add' in line:
        print(f"Line {i}: {line.encode('ascii', 'backslashreplace').decode()}")
