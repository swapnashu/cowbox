﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

clean_script = '''
import json
import psycopg2

with open("/app/to_delete_ids.json", "r") as f:
    to_delete = json.load(f)

print(f"Loaded {len(to_delete)} IDs to remove.")

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()

# Delete non-working panels
cur.execute("DELETE FROM databases WHERE id = ANY(%s)", (to_delete,))
deleted_cnt = cur.rowcount
conn.commit()

cur.execute("SELECT count(*) FROM databases")
remaining = cur.fetchone()[0]

# Set all remaining working panels to status = 'active'
cur.execute("UPDATE databases SET status = 'active'")
conn.commit()

cur.close()
conn.close()

print(f"Successfully deleted {deleted_cnt} non-working / dead / empty / locked panels.")
print(f"Remaining active working panels in database: {remaining}")
'''

s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'cleanup_db.py', 'content': clean_script})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp cleanup_db.py cowbox-khaat-968826:/app/cleanup_db.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/cleanup_db.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
