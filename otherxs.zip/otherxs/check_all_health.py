﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

# 1. Check all exited / dead containers
cmd_dead = 'docker ps -a --filter "status=exited" --filter "status=dead" --filter "status=created" --format "table {{.ID}}\t{{.Names}}\t{{.Status}}"'
r_dead = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd_dead})
print("=== DEAD / EXITED CONTAINERS ===")
print(r_dead.json().get('stdout'))

# 2. Check all running containers and test their ports / health
cmd_all = 'docker ps --format "{{.Names}}||{{.Status}}||{{.Ports}}"'
r_all = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd_all})
print("=== RUNNING CONTAINERS ===")
lines = r_all.json().get('stdout', '').strip().split('\n')
for line in lines:
    if line:
        parts = line.split('||')
        name = parts[0]
        status = parts[1] if len(parts) > 1 else ''
        ports = parts[2] if len(parts) > 2 else ''
        print(f"Container: {name:<30} Status: {status:<15} Ports: {ports}")

# 3. Check logs of non-khaat containers to see if any are throwing fatal errors
for cname in ['cowbox-selling-bot-804990', 'cowbox-cc-bot-595578', 'cowbox-cc-bot-409773', 'magix-bot']:
    cmd_log = f'docker logs --tail 10 {cname}'
    r_log = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd_log})
    print(f"\n--- Logs for {cname} ---")
    out = r_log.json().get('stdout') or r_log.json().get('stderr') or 'No logs'
    print(out[-400:])
