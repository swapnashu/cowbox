﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd_cp = 'docker cp test_all_firebase.py cowbox-khaat-968826:/app/test_all_firebase.py'
r_cp = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd_cp})
print("CP status:", r_cp.json().get('exitCode'))

cmd_exec = 'docker exec cowbox-khaat-968826 python /app/test_all_firebase.py'
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd_exec})
print("=== Output ===")
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
