﻿with open('decoded.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for line in lines[2960:3080]:
    print(line.encode('ascii', 'backslashreplace').decode())
