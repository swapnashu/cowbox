﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

script = '''
import psycopg2
import redis

# 1. Update in Postgres
try:
    conn = psycopg2.connect(
        host="cowbox-db-khaat-pg",
        port=5432,
        dbname="aat",
        user="postgres",
        password="c2fc05f1e013adefcf7c627c"
    )
    cur = conn.cursor()
    cur.execute("UPDATE users SET balance = 10.0 WHERE user_id = %s", ('7049456080',))
    conn.commit()
    print("Postgres updated rows:", cur.rowcount)
    cur.execute("SELECT user_id, name, username, balance FROM users WHERE user_id = %s", ('7049456080',))
    user = cur.fetchone()
    print("Current user in DB:", user)
    cur.close()
    conn.close()
except Exception as e:
    print("PG Error:", e)

# 2. Invalidate in Redis
try:
    r = redis.Redis(host="cowbox-db-khaat-redis", port=6379, decode_responses=True)
    r.delete("user:7049456080")
    print("Redis cache cleared for user:7049456080")
except Exception as e:
    print("Redis Error:", e)
'''

r_upload = s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'set_balance.py', 'content': script})
print("Upload:", r_upload.status_code)

r_run = s.post('http://13.207.147.149:9999/api/files/run', json={'filePath': 'set_balance.py'})
print("Run result:", r_run.status_code, r_run.text)
