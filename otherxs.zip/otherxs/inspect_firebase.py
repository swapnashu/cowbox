﻿import psycopg2
import httpx
import json

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT url, name FROM databases LIMIT 5")
panels = cur.fetchall()
cur.close()
conn.close()

with httpx.Client(verify=False, timeout=10) as client:
    for url, name in panels:
        base = url.rstrip("/")
        clients_url = base + "/clients.json"
        try:
            r = client.get(clients_url)
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and data:
                    print("=== Panel:", name, "===")
                    first_cid = list(data.keys())[0]
                    cdata = data[first_cid]
                    print("Client ID:", first_cid)
                    print("Top-level keys in client:", list(cdata.keys()) if isinstance(cdata, dict) else type(cdata))
                    
                    for k in ("sms", "receivedSms", "received_sms", "inbox", "messages", "smsList", "webhookEvent", "action", "smsCommand"):
                        if isinstance(cdata, dict) and k in cdata:
                            val = cdata[k]
                            print("Key [" + k + "]: type=" + type(val).__name__)
                            if isinstance(val, dict):
                                print("  Subkeys:", list(val.keys())[:5])
                                first_sub = list(val.values())[0]
                                if isinstance(first_sub, dict):
                                    print("  Sample item:", json.dumps(first_sub, default=str)[:300])
                            elif isinstance(val, list) and val:
                                print("  Sample list item:", json.dumps(val[0], default=str)[:300])
        except Exception as e:
            print("Error on", name, ":", e)
