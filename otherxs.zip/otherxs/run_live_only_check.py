﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

script = '''
import asyncio
import psycopg2
import httpx
import time

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT id, name, url, status FROM databases")
rows = cur.fetchall()
cur.close()
conn.close()

print(f"Total current panels in DB: {len(rows)}")

async def check_panel(client, row, sem):
    did, name, url, status = row
    base = url.rstrip("/")
    cb = int(time.time() * 1000)
    if "?" in base:
        base_clean, query = base.split("?", 1)
        clients_url = f"{base_clean}/clients.json?{query}&_cb={cb}"
    else:
        clients_url = f"{base}/clients.json?_cb={cb}"
        
    async with sem:
        try:
            r = await client.get(clients_url, timeout=httpx.Timeout(6.0, connect=4.0))
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and data:
                    online = 0
                    now_ms = time.time() * 1000
                    for cid, cdata in data.items():
                        if isinstance(cdata, dict):
                            raw_status = cdata.get("status")
                            raw_seen = (cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("timestamp"))
                            ts = None
                            if raw_seen:
                                try:
                                    ts = float(raw_seen)
                                    if ts < 1e12: ts = ts * 1000
                                except Exception:
                                    pass
                            if bool(raw_status) and (ts is None or (now_ms - ts < 86400000)):
                                online += 1
                    return {"id": did, "name": name, "url": url, "online": online, "total": len(data), "status": "active" if online > 0 else "zero_online"}
            return {"id": did, "name": name, "url": url, "online": 0, "total": 0, "status": "failed"}
        except Exception:
            return {"id": did, "name": name, "url": url, "online": 0, "total": 0, "status": "failed"}

async def main():
    sem = asyncio.Semaphore(40)
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as client:
        tasks = [check_panel(client, row, sem) for row in rows]
        results = await asyncio.gather(*tasks)

    with_online = [r for r in results if r["online"] > 0]
    zero_online = [r for r in results if r["online"] == 0 and r["total"] > 0]
    failed = [r for r in results if r["status"] == "failed"]

    print("=== LIVE ONLINE STATUS ===")
    print(f"Panels with LIVE ONLINE devices (>0 online): {len(with_online)}")
    print(f"Panels with devices but 0 online right now: {len(zero_online)}")
    print(f"Failed panels: {len(failed)}")
    print(f"Total LIVE online devices across active panels: {sum(r['online'] for r in with_online)}")
    print(f"Total devices across active panels: {sum(r['total'] for r in with_online)}")

asyncio.run(main())
'''

s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'check_live_only.py', 'content': script})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp check_live_only.py cowbox-khaat-968826:/app/check_live_only.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/check_live_only.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
