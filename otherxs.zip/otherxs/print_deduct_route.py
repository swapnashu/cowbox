﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines[7580:7640]):
    print(f"{7580+i}: {line.encode('ascii', 'backslashreplace').decode()}")
