﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

# 1. Update RECEIVED_SMS_PAGE
page_start = None
page_end = None
for i, line in enumerate(lines):
    if 'RECEIVED_SMS_PAGE = ' in line:
        page_start = i
    if page_start is not None and 'SETTINGS_PAGE = ' in line:
        page_end = i
        break

new_rx_page = '''RECEIVED_SMS_PAGE = """
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:28px">
  <h1 style="margin:0"><i class="fas fa-inbox accent"></i> <span class="accent">Received</span> <span class="gold">SMS</span></h1>
  <div style="display:flex;gap:12px;align-items:center">
    <span style="font-size:12px;color:#22c55e;font-weight:600"><i class="fas fa-circle" style="animation:pulse 1.5s infinite"></i> Live Feed</span>
    <span style="font-size:13px;color:#64748b;font-weight:500">{{ total }} incoming messages</span>
  </div>
</div>
<style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}</style>

<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-inbox"></i> Incoming SMS Feed</h2>
    <form method="GET" action="/received-sms" style="display:flex;gap:8px;align-items:center">
      <div class="search-box" style="margin:0;width:280px">
        <i class="fas fa-search"></i>
        <input type="text" name="number" class="input" value="{{ filter_number }}" placeholder="Search Sender or Receiver...">
      </div>
      <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-filter"></i></button>
      {% if filter_number %}<a href="/received-sms" class="btn btn-outline btn-sm"><i class="fas fa-times"></i> Clear</a>{% endif %}
    </form>
  </div>
  <div class="card-body" style="overflow-x:auto;padding:0">
    <table>
      <thead>
        <tr>
          <th style="width:18%"><i class="fas fa-user"></i> From (Sender)</th>
          <th style="width:18%"><i class="fas fa-sim-card"></i> To (Receiver SIM)</th>
          <th><i class="fas fa-comment-dots"></i> Message</th>
          <th style="width:16%"><i class="fas fa-server"></i> Panel</th>
          <th style="width:16%"><i class="fas fa-clock"></i> Received At</th>
        </tr>
      </thead>
      <tbody id="rxSms">
        {% for sms in messages %}
        <tr>
          <td><strong style="color:#d4a853">{{ sms.from_number or sms.number or '-' }}</strong></td>
          <td><span style="font-weight:600;color:#38bdf8">{{ sms.to_number or '-' }}</span></td>
          <td style="max-width:340px;word-break:break-word">{{ sms.message if sms.message else '-' }}</td>
          <td class="truncate">{{ sms.panel[:30] if sms.panel else '-' }}</td>
          <td>{{ sms.received_at[:19] if sms.received_at else '-' }}</td>
        </tr>
        {% endfor %}
        {% if not messages %}
        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:32px"><i class="fas fa-inbox" style="font-size:24px;margin-bottom:8px;display:block;opacity:0.4"></i>No incoming SMS yet. Real incoming messages from devices or webhook will appear here live.</td></tr>
        {% endif %}
      </tbody>
    </table>
  </div>
</div>

<div class="pagination">
  {% if page > 1 %}<a href="/received-sms?page={{ page-1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-left"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-left"></i></span>{% endif %}
  {% for p in range(1, total_pages+1) %}
    {% if p == page %}<span class="current">{{ p }}</span>{% elif p <= 3 or p > total_pages-3 or (p >= page-2 and p <= page+2) %}<a href="/received-sms?page={{ p }}{% if filter_number %}&number={{ filter_number }}{% endif %}">{{ p }}</a>{% elif p == 4 or p == total_pages-3 %}<span class="disabled">...</span>{% endif %}
  {% endfor %}
  {% if page < total_pages %}<a href="/received-sms?page={{ page+1 }}{% if filter_number %}&number={{ filter_number }}{% endif %}"><i class="fas fa-chevron-right"></i></a>{% else %}<span class="disabled"><i class="fas fa-chevron-right"></i></span>{% endif %}
</div>

<script>
function escapeHtml(t){if(!t)return'';return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
async function refreshRx(){
  try{
    var r = await fetch('/api/live-received');
    if(!r.ok) return;
    var d = await r.json();
    var tb = document.getElementById('rxSms');
    if(!tb || d.length === 0) return;
    var h = '';
    d.forEach(function(l){
      h += '<tr>' +
           '<td><strong style="color:#d4a853">' + escapeHtml(l.from) + '</strong></td>' +
           '<td><span style="font-weight:600;color:#38bdf8">' + escapeHtml(l.to) + '</span></td>' +
           '<td style="max-width:340px;word-break:break-word">' + escapeHtml(l.message) + '</td>' +
           '<td class="truncate">' + escapeHtml(l.panel) + '</td>' +
           '<td>' + escapeHtml(l.received_at) + '</td>' +
           '</tr>';
    });
    tb.innerHTML = h;
  }catch(e){}
}
setInterval(refreshRx, 3500);
</script>
"""'''.splitlines()

if page_start is not None and page_end is not None:
    lines = lines[:page_start] + new_rx_page + lines[page_end:]
    print("PATCH RECEIVED_SMS_PAGE SUCCESS")
else:
    print("PATCH RECEIVED_SMS_PAGE FAILED", page_start, page_end)

# 2. Update api/live-received and api/sms-received
api_start = None
api_end = None
for i, line in enumerate(lines):
    if '@app.route("/api/live-received"' in line or '@app.route("/api/sms-received"' in line:
        if api_start is None:
            api_start = i
    if api_start is not None and '@app.route("/api/live-payments"' in line:
        api_end = i
        break

new_api = '''@app.route("/api/sms-received", methods=["POST"])
def api_sms_received():
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    from_num = data.get("from") or data.get("sender") or data.get("from_number") or data.get("number") or ""
    to_num = data.get("to") or data.get("receiver") or data.get("to_number") or data.get("sim") or ""
    message = data.get("message") or data.get("text") or data.get("body") or data.get("msg") or ""
    panel = data.get("panel") or data.get("device") or "Webhook"
    if not message:
        return jsonify({"error": "message required"}), 400
    sms_received_add(from_number=from_num, to_number=to_num, message=message, panel=panel)
    return jsonify({"status": "ok", "message": "Saved"})


@app.route("/api/live-received")
@login_required
def api_live_received():
    rows = pg.execute(
        "SELECT id, number, from_number, to_number, message, panel, received_at FROM sms_received ORDER BY received_at DESC, id DESC LIMIT 25",
        dict_cursor=True
    )
    return jsonify([{
        "from": r.get("from_number") or r.get("number") or "-",
        "to": r.get("to_number") or "-",
        "message": r.get("message", ""),
        "panel": r.get("panel", ""),
        "received_at": r.get("received_at", "")[:19] if r.get("received_at") else "",
    } for r in rows])'''.splitlines()

if api_start is not None and api_end is not None:
    lines = lines[:api_start] + new_api + lines[api_end:]
    print("PATCH API ROUTES SUCCESS")
else:
    print("PATCH API ROUTES FAILED", api_start, api_end)

with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
