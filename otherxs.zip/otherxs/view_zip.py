﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = 'unzip -l /app/data/builds/53653872-d508-4d9c-b8c9-c7bed17a3224/xcaliber_deploy.zip'
r = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r.json().get('stdout'))
