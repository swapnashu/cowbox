﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

script = '''
import asyncio
import psycopg2
import httpx
import time
from collections import Counter

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT id, name, url, status FROM databases")
rows = cur.fetchall()
cur.close()
conn.close()

print(f"Total rows fetched from PostgreSQL databases table: {len(rows)}")

async def check_url(client, row, sem):
    did, name, url, status = row
    base = url.rstrip("/")
    cb = int(time.time() * 1000)
    
    if "?" in base:
        base_clean, query = base.split("?", 1)
        clients_url = f"{base_clean}/clients.json?{query}&_cb={cb}"
    else:
        base_clean = base
        query = ""
        clients_url = f"{base}/clients.json?_cb={cb}"
        
    async with sem:
        # First attempt: clients.json
        for attempt in range(2):
            try:
                r = await client.get(clients_url, timeout=httpx.Timeout(8.0, connect=5.0))
                code = r.status_code
                if code == 200:
                    data = r.json()
                    if isinstance(data, dict) and len(data) > 0:
                        # Count online devices
                        online_cnt = 0
                        now_ms = time.time() * 1000
                        for cid, cdata in data.items():
                            if isinstance(cdata, dict):
                                raw_status = cdata.get("status")
                                raw_seen = (cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("timestamp"))
                                ts = None
                                if raw_seen:
                                    try:
                                        ts = float(raw_seen)
                                        if ts < 1e12: ts = ts * 1000
                                    except Exception:
                                        pass
                                if bool(raw_status) and (ts is None or (now_ms - ts < 86400000)):
                                    online_cnt += 1
                        return {"id": did, "name": name, "url": url, "category": "WORKING_WITH_DEVICES", "code": 200, "devices": len(data), "online": online_cnt}
                    elif data is None or data == {} or data == []:
                        pass # check alternate endpoints below
                elif code in (401, 403):
                    return {"id": did, "name": name, "url": url, "category": "PERMISSION_DENIED_401_403", "code": code, "devices": 0, "online": 0}
                elif code == 404:
                    return {"id": did, "name": name, "url": url, "category": "NOT_FOUND_404", "code": 404, "devices": 0, "online": 0}
                elif code == 423:
                    return {"id": did, "name": name, "url": url, "category": "FIREBASE_LOCKED_423", "code": 423, "devices": 0, "online": 0}
                else:
                    return {"id": did, "name": name, "url": url, "category": f"HTTP_OTHER_{code}", "code": code, "devices": 0, "online": 0}
            except httpx.TimeoutException:
                if attempt == 1:
                    return {"id": did, "name": name, "url": url, "category": "TIMEOUT", "code": 0, "devices": 0, "online": 0}
            except Exception as e:
                if attempt == 1:
                    return {"id": did, "name": name, "url": url, "category": "NETWORK_ERROR", "code": 0, "devices": 0, "online": 0}

        # Check alternate endpoints: devices, users, registeredDevices, All_Users
        for alt in ("devices", "registeredDevices", "users", "user_data", "All_Users"):
            if "?" in base:
                alt_url = f"{base_clean}/{alt}.json?{query}&_cb={cb}"
            else:
                alt_url = f"{base}/{alt}.json?_cb={cb}"
            try:
                r = await client.get(alt_url, timeout=httpx.Timeout(6.0, connect=4.0))
                if r.status_code == 200:
                    data = r.json()
                    if isinstance(data, dict) and len(data) > 0:
                        return {"id": did, "name": name, "url": url, "category": "WORKING_WITH_DEVICES", "code": 200, "devices": len(data), "online": 0}
            except Exception:
                pass

        return {"id": did, "name": name, "url": url, "category": "EMPTY_NO_DEVICES", "code": 200, "devices": 0, "online": 0}

async def main():
    sem = asyncio.Semaphore(40)
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as client:
        tasks = [check_url(client, row, sem) for row in rows]
        results = await asyncio.gather(*tasks)

    counts = Counter(r["category"] for r in results)
    print("\n=== EXACT BREAKDOWN OF ALL 542 URLS ===")
    total_sum = 0
    for cat, cnt in counts.most_common():
        print(f"  {cat:<30}: {cnt:>4} panels")
        total_sum += cnt
    print(f"  {'TOTAL':<30}: {total_sum:>4} panels")

    working = [r for r in results if r["category"] == "WORKING_WITH_DEVICES"]
    to_delete = [r for r in results if r["category"] != "WORKING_WITH_DEVICES"]
    
    print(f"\nPanels to KEEP (working with devices): {len(working)}")
    print(f"Panels to REMOVE (dead/empty/locked/401/404): {len(to_delete)}")
    print(f"Total devices across working panels: {sum(r['devices'] for r in working)}")
    print(f"Total online devices: {sum(r['online'] for r in working)}")

asyncio.run(main())
'''

# Write script to cowbox file
s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'probe542_full.py', 'content': script})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp probe542_full.py cowbox-khaat-968826:/app/probe542_full.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/probe542_full.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
