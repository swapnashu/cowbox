﻿with open('verify_paytm_payment.py', 'r', encoding='utf-8') as f:
    content = f.read()

if 'import paytm_token_refresh' not in content:
    content = content.replace('import gzip\n', 'import gzip\nimport paytm_token_refresh\n')

target = '''def _make_post_request(url, payload):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=_get_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=12) as res:
            raw = res.read()
            if res.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        err_msg = raw.decode("utf-8", errors="ignore")
        raise RuntimeError(f"Paytm API Error ({e.code}): {err_msg}")
    except Exception as ex:
        raise RuntimeError(f"Network error connecting to Paytm: {ex}")'''

rep = '''def _make_post_request(url, payload, retry=True):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=_get_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=12) as res:
            raw = res.read()
            if res.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        err_msg = raw.decode("utf-8", errors="ignore")
        
        if retry and (e.code in (401, 403, 410) or "token" in err_msg.lower() or "unauthorized" in err_msg.lower()):
            print("[*] Access token seems invalid/expired in verification. Attempting to refresh...")
            refresh_res = paytm_token_refresh.refresh_token()
            if refresh_res.get("success"):
                print("[*] Token refreshed successfully! Updating config and retrying...")
                CONFIG["user_token"] = refresh_res["new_access_token"]
                return _make_post_request(url, payload, retry=False)
            else:
                print("[!] Failed to refresh token:", refresh_res)
                
        raise RuntimeError(f"Paytm API Error ({e.code}): {err_msg}")
    except Exception as ex:
        raise RuntimeError(f"Network error connecting to Paytm: {ex}")'''

if target in content:
    content = content.replace(target, rep)
    with open('verify_paytm_payment.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print("SUCCESS")
else:
    print("NOT FOUND")
