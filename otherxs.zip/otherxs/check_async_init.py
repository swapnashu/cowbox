﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i in range(800, 870):
    print(f"{i}: {lines[i].encode('ascii', 'backslashreplace').decode()}")
