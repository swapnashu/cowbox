﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

old_async_deduct = '''async def deduct_balance(uid: int, amount: float) -> bool:

    uid_str = str(uid)

    async with pool.acquire() as conn:

        result = await conn.execute(

            "UPDATE users SET balance = balance -  WHERE user_id =  AND balance >= ",

            amount,

            uid_str,

        )

    await redis_client.delete(f"user:{uid_str}")

    return result == "UPDATE 1"'''

new_async_deduct = '''async def deduct_balance(uid: int, amount: float) -> bool:

    uid_str = str(uid)

    amt = round(float(amount), 4)

    async with pool.acquire() as conn:

        row = await conn.fetchrow("SELECT balance FROM users WHERE user_id = ", uid_str)

        if not row:

            return False

        current_bal = float(row["balance"] or 0)

        if round(current_bal, 2) < round(amt, 2):

            return False

        new_bal = max(0.0, current_bal - amt)

        await conn.execute(

            "UPDATE users SET balance =  WHERE user_id = ",

            new_bal,

            uid_str,

        )

    if redis_client:

        try:

            await redis_client.delete(f"user:{uid_str}")

        except Exception:

            pass

    return True'''

if old_async_deduct in content:
    content = content.replace(old_async_deduct, new_async_deduct)
    print("PATCH ASYNC DEDUCT SUCCESS")
else:
    print("PATCH ASYNC DEDUCT NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
