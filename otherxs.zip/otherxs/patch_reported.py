﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

# 1. Update create_tables (asyncpg) to include sms_received
async_tbl_start = None
async_tbl_end = None
for i, line in enumerate(lines):
    if 'async def create_tables():' in line:
        async_tbl_start = i
    if async_tbl_start is not None and 'async def load_settings():' in line:
        async_tbl_end = i
        break

new_create_tables = '''async def create_tables():
    async with pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                balance REAL DEFAULT 0,
                sms_sent INTEGER DEFAULT 0,
                joined TEXT,
                last_active TEXT,
                name TEXT DEFAULT '',
                username TEXT DEFAULT '',
                banned INTEGER DEFAULT 0,
                ban_reason TEXT DEFAULT '',
                referred_by TEXT DEFAULT ''
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS databases (
                id TEXT PRIMARY KEY,
                url TEXT UNIQUE,
                name TEXT,
                added TEXT,
                status TEXT DEFAULT 'active',
                sms_sent INTEGER DEFAULT 0,
                devices_online INTEGER DEFAULT 0
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                biz_order_id TEXT PRIMARY KEY,
                merchant_trans_id TEXT,
                amount REAL,
                currency TEXT DEFAULT 'INR',
                pay_time TEXT,
                payer_name TEXT,
                payer_vpa TEXT,
                payer_psp TEXT,
                created_at TEXT,
                claimed_by TEXT,
                claimed_at TEXT
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS sms_logs (
                id SERIAL PRIMARY KEY,
                user_id TEXT,
                target TEXT,
                panel TEXT,
                status TEXT,
                message TEXT,
                created_at TEXT
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS sms_received (
                id SERIAL PRIMARY KEY,
                number TEXT,
                from_number TEXT,
                to_number TEXT,
                message TEXT,
                panel TEXT,
                received_at TEXT
            )
        """)
        await conn.execute("ALTER TABLE payments ADD COLUMN IF NOT EXISTS claimed_by TEXT")
        await conn.execute("ALTER TABLE payments ADD COLUMN IF NOT EXISTS claimed_at TEXT")
        await conn.execute("ALTER TABLE databases ADD COLUMN IF NOT EXISTS devices_online INTEGER DEFAULT 0")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS name TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS username TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS banned INTEGER DEFAULT 0")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS ban_reason TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS from_number TEXT")
        await conn.execute("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS to_number TEXT")'''.splitlines()

if async_tbl_start is not None and async_tbl_end is not None:
    lines = lines[:async_tbl_start] + new_create_tables + lines[async_tbl_end:]
    print("PATCH 1: create_tables updated")
else:
    print("PATCH 1 FAILED", async_tbl_start, async_tbl_end)

# 2. Update sms_received_add with flexible **kwargs handling
add_start = None
add_end = None
for i, line in enumerate(lines):
    if 'def sms_received_add' in line:
        add_start = i
    if add_start is not None and 'def sms_received_list' in line:
        add_end = i
        break

new_add_func = '''def sms_received_add(from_number="", to_number="", message="", panel="", received_at=None, **kwargs):
    from_str = str(from_number or kwargs.get("from") or kwargs.get("number") or "").strip()
    to_str = str(to_number or kwargs.get("to") or "").strip()
    msg_str = str(message or kwargs.get("message") or kwargs.get("text") or "").strip()
    if not msg_str and from_number and not to_number and not kwargs:
        # fallback if called as sms_received_add(num, msg)
        from_str = str(from_number).strip()
        msg_str = str(to_number).strip()
    if not msg_str:
        return
    panel_str = str(panel or kwargs.get("panel") or "").strip()
    ts = received_at or kwargs.get("received_at") or datetime.now().isoformat()
    try:
        existing = pg.execute_one(
            "SELECT id FROM sms_received WHERE (from_number = %s OR number = %s) AND message = %s LIMIT 1",
            (from_str, from_str, msg_str)
        )
        if existing:
            return
        pg.execute_write(
            "INSERT INTO sms_received (number, from_number, to_number, message, panel, received_at) VALUES (%s,%s,%s,%s,%s,%s)",
            (from_str, from_str, to_str, msg_str, panel_str, str(ts))
        )
    except Exception as e:
        log.warning("sms_received_add error: %s", e)'''.splitlines()

if add_start is not None and add_end is not None:
    lines = lines[:add_start] + new_add_func + lines[add_end:]
    print("PATCH 2: sms_received_add updated")
else:
    print("PATCH 2 FAILED", add_start, add_end)

# 3. Update confirm_yes loop to use non-blocking send_async
bot_loop_start = None
bot_loop_end = None
for i, line in enumerate(lines):
    if 'if data == "confirm_yes":' in line:
        bot_loop_start = i
    if bot_loop_start is not None and 'final_user = await get_user(uid' in line:
        bot_loop_end = i
        break

new_bot_loop = '''    if data == "confirm_yes":
        st = states.get(uid, {})
        if st.get("step") != "confirm":
            return

        phone = st["phone"]
        msg = st["message"]
        count = st["count"]
        speed = st.get("speed", 0.1)
        total_cost = count * SMS_COST

        user = await get_user(uid, name=tg_name, username=tg_username)
        if user["balance"] < total_cost:
            await query.edit_message_text(
                "╔════════════════════╗\\n"
                "  ⚠️ Insufficient Balance\\n"
                "╚════════════════════╝\\n\\n"
                f"Need: ₹{total_cost:.2f}\\n"
                f"Available: ₹{user['balance']:.2f}\\n\\n"
                "Top up or refer friends to earn more!",
                reply_markup=back_markup(),
            )
            states.pop(uid, None)
            return

        ok = await deduct_balance(uid, total_cost)
        if not ok:
            await query.edit_message_text(
                "╔════════════════════╗\\n"
                "  ❌ Deduction Failed\\n"
                "╚════════════════════╝\\n\\n"
                "Could not deduct balance. Try again.",
                reply_markup=back_markup(),
            )
            states.pop(uid, None)
            return

        await query.edit_message_text(
            "╔════════════════════╗\\n"
            "  🚀 Sending SMS...\\n"
            "╚════════════════════╝\\n\\n"
            f"Target: {fmt_phone_display(phone)}\\n"
            f"Total: {count}\\n\\n"
            "Starting..."
        )

        sent = 0
        failed = 0

        for i in range(count):
            unique_msg = msg + ("\\u200b" * (i % 20))
            # Completely non-blocking async SMS dispatch
            ok_res, detail, dev_id = await panel_manager.send_async(phone, unique_msg)
            if ok_res:
                sent += 1
                await increment_sms(uid)
                await log_sms(str(uid), phone, detail, "sent", msg)
            else:
                failed += 1
                await log_sms(str(uid), phone, "none", "failed", detail)

            if i < count - 1:
                wait_time = max(speed, 1.2) if speed == 0.1 else speed
                await asyncio.sleep(wait_time)

            if (i + 1) % 5 == 0 or (i + 1) == count:
                pct = ((i + 1) / count) * 100
                bar_len = 20
                filled = int(bar_len * (i + 1) / count)
                bar = "█" * filled + "░" * (bar_len - filled)
                try:
                    await context.bot.edit_message_text(
                        "╔════════════════════╗\\n"
                        "  🚀 Sending SMS...\\n"
                        "╚════════════════════╝\\n\\n"
                        f"[{bar}] {pct:.0f}%\\n"
                        f"Progress: {i + 1}/{count}\\n"
                        f"📤 Sent: {sent}\\n"
                        f"❌ Failed: {failed}",
                        chat_id=chat_id,
                        message_id=query.message.message_id,
                    )
                except Exception:
                    pass

        bar = "█" * 20
        pct = 100'''.splitlines()

if bot_loop_start is not None and bot_loop_end is not None:
    lines = lines[:bot_loop_start] + new_bot_loop + lines[bot_loop_end:]
    print("PATCH 3: confirm_yes non-blocking async loop updated")
else:
    print("PATCH 3 FAILED", bot_loop_start, bot_loop_end)

with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
