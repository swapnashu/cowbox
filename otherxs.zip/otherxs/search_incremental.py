﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if 'Incremental probe' in line or 'incremental' in line.lower():
        print(f"Line {i}: {line}")
