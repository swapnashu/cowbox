﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

clean_script = '''
import asyncio
import psycopg2
import httpx
import time

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT id, name, url, status FROM databases")
rows = cur.fetchall()

async def check_panel(client, row, sem):
    did, name, url, status = row
    base = url.rstrip("/")
    cb = int(time.time() * 1000)
    if "?" in base:
        base_clean, query = base.split("?", 1)
        clients_url = f"{base_clean}/clients.json?{query}&_cb={cb}"
    else:
        clients_url = f"{base}/clients.json?_cb={cb}"
        
    async with sem:
        try:
            r = await client.get(clients_url, timeout=httpx.Timeout(6.0, connect=4.0))
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and data:
                    online = 0
                    now_ms = time.time() * 1000
                    for cid, cdata in data.items():
                        if isinstance(cdata, dict):
                            raw_status = cdata.get("status")
                            raw_seen = (cdata.get("lastSeen") or cdata.get("last_seen") or cdata.get("timestamp"))
                            ts = None
                            if raw_seen:
                                try:
                                    ts = float(raw_seen)
                                    if ts < 1e12: ts = ts * 1000
                                except Exception:
                                    pass
                            if bool(raw_status) and (ts is None or (now_ms - ts < 86400000)):
                                online += 1
                    if online > 0:
                        return {"id": did, "keep": True, "online": online, "total": len(data)}
            return {"id": did, "keep": False, "online": 0, "total": 0}
        except Exception:
            return {"id": did, "keep": False, "online": 0, "total": 0}

async def main():
    sem = asyncio.Semaphore(40)
    async with httpx.AsyncClient(verify=False, follow_redirects=True) as client:
        tasks = [check_panel(client, row, sem) for row in rows]
        results = await asyncio.gather(*tasks)

    keep_ids = [r["id"] for r in results if r["keep"]]
    delete_ids = [r["id"] for r in results if not r["keep"]]
    
    print(f"Total panels to KEEP (active with live online devices): {len(keep_ids)}")
    print(f"Total panels to DELETE (0 online devices / dead): {len(delete_ids)}")
    
    if delete_ids:
        cur.execute("DELETE FROM databases WHERE id = ANY(%s)", (delete_ids,))
        conn.commit()
        print(f"Successfully deleted {len(delete_ids)} zero-online panels.")
        
    cur.execute("SELECT count(*) FROM databases")
    remaining = cur.fetchone()[0]
    print(f"Exact total panels remaining in PostgreSQL: {remaining}")
    
    cur.close()
    conn.close()

asyncio.run(main())
'''

s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'keep_live_only.py', 'content': clean_script})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp keep_live_only.py cowbox-khaat-968826:/app/keep_live_only.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/keep_live_only.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
