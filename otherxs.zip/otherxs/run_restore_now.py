﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

content = open('restore_all_valid.py', 'r', encoding='utf-8').read()
s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'restore_all_valid.py', 'content': content})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp restore_all_valid.py cowbox-khaat-968826:/app/restore_all_valid.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/restore_all_valid.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
