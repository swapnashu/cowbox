﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = 'docker exec cowbox-khaat-968826 ls -la /app'
r = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r.json().get('stdout'))
