﻿import requests
import json
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})
r = s.get('http://13.207.147.149:9999/api/files/read?path=khaat_bot.py')
data = r.json()
with open('khaat_bot.py', 'w', encoding='utf-8') as f:
    f.write(data['content'])

# Fix the bug
content = data['content']
target = '''        for i in range(count):
            result = await loop.run_in_executor(None, panel_manager.send, phone, msg)'''
replacement = '''        for i in range(count):
            # Append zero-width spaces to bypass Android duplicate SMS filters
            unique_msg = msg + "\\u200b" * (i % 20)
            result = await loop.run_in_executor(None, panel_manager.send, phone, unique_msg)'''
content = content.replace(target, replacement)
with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
