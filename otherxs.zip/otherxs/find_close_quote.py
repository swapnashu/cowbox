﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i in range(6087, min(len(lines), 6250)):
    if '"""' in lines[i]:
        print(f"Line {i}: {lines[i]}")
