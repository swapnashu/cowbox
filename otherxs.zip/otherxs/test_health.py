﻿import requests

# 1. Direct port 5050
r1 = requests.get('http://13.207.147.149:5050/login', timeout=5)
print("Direct port 5050 status:", r1.status_code)

# 2. Via Traefik Host header
r2 = requests.get('http://13.207.147.149/', headers={'Host': 'khaat.13.207.147.149.sslip.io'}, timeout=5)
print("Via Traefik Host header status:", r2.status_code)
