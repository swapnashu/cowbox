﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if 'def setting_set(' in line or 'def setting_get(' in line:
        for j in range(i, i+30):
            print(f"{j}: {lines[j].encode('ascii', 'backslashreplace').decode()}")
        break
