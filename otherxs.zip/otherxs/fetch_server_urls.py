﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = 'grep -roh "https://[a-zA-Z0-9_.-]*firebase[a-zA-Z0-9_.-]*" /app/data | sort -u'
r = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
lines = r.json().get('stdout', '').strip().split('\n')
print(f"Found {len(lines)} distinct Firebase URLs in Cowbox server /app/data!")

# Save to a json file in cowbox workspace
import json
urls = [l.strip() for l in lines if l.strip()]
s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'all_542_urls.json', 'content': json.dumps(urls)})
