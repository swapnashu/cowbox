﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

start = None
end = None
for i, line in enumerate(lines):
    if 'async def deduct_balance(uid: int, amount: float)' in line:
        start = i
    if start is not None and 'return result == "UPDATE 1"' in line:
        end = i + 1
        break

if start is not None and end is not None:
    replacement = '''async def deduct_balance(uid: int, amount: float) -> bool:

    uid_str = str(uid)

    amt = round(float(amount), 4)

    async with pool.acquire() as conn:

        row = await conn.fetchrow("SELECT balance FROM users WHERE user_id = ", uid_str)

        if not row:

            return False

        current_bal = float(row["balance"] or 0)

        if round(current_bal, 2) < round(amt, 2):

            return False

        new_bal = max(0.0, current_bal - amt)

        await conn.execute(

            "UPDATE users SET balance =  WHERE user_id = ",

            new_bal,

            uid_str,

        )

    if redis_client:

        try:

            await redis_client.delete(f"user:{uid_str}")

        except Exception:

            pass

    return True'''.splitlines()

    new_lines = lines[:start] + replacement + lines[end:]
    with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
        f.write('\n'.join(new_lines))
    print("SUCCESS")
else:
    print("FAILED TO LOCATE")
