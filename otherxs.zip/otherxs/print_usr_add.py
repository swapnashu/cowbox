﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines[1625:1650]):
    print(f"{1625+i}: {line.encode('ascii', 'backslashreplace').decode()}")
