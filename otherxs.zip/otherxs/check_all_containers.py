﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

# 1. Get containers from Cowbox API
r_containers = s.get('http://13.207.147.149:9999/api/containers')
print("--- Cowbox Containers API ---", r_containers.status_code)
print(r_containers.text[:1500])

# 2. Get applications status
r_apps = s.get('http://13.207.147.149:9999/api/applications')
print("--- Cowbox Applications API ---", r_apps.status_code)
print(r_apps.text[:1500])

# 3. Docker ps -a via files/run
cmd = 'docker ps -a --format "table {{.ID}}\t{{.Names}}\t{{.Status}}\t{{.Ports}}"'
r_docker = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print("--- Docker PS -A ---")
print(r_docker.json().get('stdout'))
