﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

# Docker exec to run psql directly on Postgres container
cmd = 'docker exec cowbox-db-khaat-pg psql -U postgres -d aat -c "UPDATE users SET balance = 10.0 WHERE user_id = \'7049456080\'; SELECT user_id, name, username, balance FROM users WHERE user_id = \'7049456080\';"'
r_run = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print("Run result:", r_run.status_code, r_run.text)

# Also clear Redis key
cmd_redis = 'docker exec cowbox-db-khaat-redis redis-cli del user:7049456080'
r_redis = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd_redis})
print("Redis result:", r_redis.status_code, r_redis.text)
