﻿with open('khaat_bot.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()
content = '\n'.join(lines)

target1 = '''        if not payment:
            await update.message.reply_text(
                "??????????????????????\\n"
                "  ? UTR Not Found\\n"
                "??????????????????????\\n\\n"
                "No payment found with this UTR.\\nCheck and try again:",
                reply_markup=back_markup(),
            )'''

rep1 = '''        if not payment:
            await update.message.reply_text(
                "??????????????????????\\n"
                "  ? UTR Not Found\\n"
                "??????????????????????\\n\\n"
                "Automatic UTR failed.\\nPlease contact Admin with your payment screenshot.",
                reply_markup=back_markup(),
            )'''

if target1 in content:
    content = content.replace(target1, rep1)
    with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print('SUCCESS')
else:
    print('NOT FOUND 1')
