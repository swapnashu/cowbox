﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i in range(max(0, len(lines)-100), len(lines)):
    print(f"{i}: {lines[i].encode('ascii', 'backslashreplace').decode()}")
