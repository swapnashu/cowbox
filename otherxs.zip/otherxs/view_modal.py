﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines[5080:5180]):
    print(f"{5080+i}: {line.encode('ascii', 'backslashreplace').decode()}")
