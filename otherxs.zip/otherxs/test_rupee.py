﻿with open('decoded.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Verify decoded.py has valid emojis and rupee symbol
rupee_count = code.count('\u20b9')
print(f"Original decoded.py has {rupee_count} rupee symbols!")
