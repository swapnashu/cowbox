﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

for i, line in enumerate(lines):
    if 'USERS_PAGE = ' in line:
        print(f"USERS_PAGE at line {i}")
