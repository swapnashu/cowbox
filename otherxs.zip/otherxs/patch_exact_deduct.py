﻿with open('khaat_bot_final.py', 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()

# 1. Replace async deduct_balance (around line 1126)
async_start = None
async_end = None
for i, line in enumerate(lines):
    if 'async def deduct_balance(uid: int, amount: float)' in line:
        async_start = i
    if async_start is not None and 'return result == "UPDATE 1"' in line:
        async_end = i + 1
        break

new_async = '''async def deduct_balance(uid: int, amount: float) -> bool:
    uid_str = str(uid).strip()
    amt = round(float(amount), 4)
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT balance FROM users WHERE user_id = ", uid_str)
        if not row:
            return False
        current_bal = float(row["balance"] or 0)
        if round(current_bal, 2) < round(amt, 2):
            return False
        new_bal = max(0.0, current_bal - amt)
        await conn.execute("UPDATE users SET balance =  WHERE user_id = ", new_bal, uid_str)
    if redis_client:
        try:
            await redis_client.delete(f"user:{uid_str}")
        except Exception:
            pass
    return True'''.splitlines()

if async_start is not None and async_end is not None:
    lines = lines[:async_start] + new_async + lines[async_end:]
    print("REPLACED ASYNC DEDUCT")
else:
    print("FAILED ASYNC DEDUCT", async_start, async_end)

# 2. Replace sync usr_add_balance and usr_deduct_balance
sync_start = None
sync_end = None
for i, line in enumerate(lines):
    if 'def usr_add_balance(uid, amount):' in line:
        sync_start = i
    if sync_start is not None and 'return row is not None' in line:
        sync_end = i + 1
        break

new_sync = '''def usr_add_balance(uid, amount):
    uid_str = str(uid).strip()
    amt = round(float(amount), 4)
    existing = usr_get(uid_str)
    if not existing:
        usr_add(uid_str, amt)
    else:
        pg.execute_write(
            "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",
            (amt, uid_str),
        )
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass


def usr_deduct_balance(uid, amount):
    uid_str = str(uid).strip()
    amt = round(float(amount), 4)
    user = pg.execute_one("SELECT balance FROM users WHERE user_id = %s", (uid_str,), dict_cursor=True)
    if not user:
        return False
    current_bal = float(user.get("balance") or 0)
    if round(current_bal, 2) < round(amt, 2):
        return False
    new_bal = max(0.0, current_bal - amt)
    pg.execute_write(
        "UPDATE users SET balance = %s WHERE user_id = %s",
        (new_bal, uid_str),
    )
    if rds:
        try:
            rds.delete(f"user:{uid_str}")
        except Exception:
            pass
    return True'''.splitlines()

if sync_start is not None and sync_end is not None:
    lines = lines[:sync_start] + new_sync + lines[sync_end:]
    print("REPLACED SYNC DEDUCT & ADD")
else:
    print("FAILED SYNC DEDUCT", sync_start, sync_end)

with open('khaat_bot_final.py', 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
