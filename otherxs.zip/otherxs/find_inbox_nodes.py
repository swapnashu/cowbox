﻿import psycopg2
import httpx
import json

conn = psycopg2.connect(
    host="cowbox-db-khaat-pg",
    port=5432,
    dbname="aat",
    user="postgres",
    password="c2fc05f1e013adefcf7c627c"
)
cur = conn.cursor()
cur.execute("SELECT url, name FROM databases LIMIT 15")
panels = cur.fetchall()
cur.close()
conn.close()

with httpx.Client(verify=False, timeout=8) as client:
    for url, name in panels:
        base = url.rstrip("/")
        for node in ("receivedSms", "inbox", "incoming_sms", "all_sms", "messages", "smsList", "sms_list", "device_sms", "received_sms", "sms"):
            node_url = base + "/" + node + ".json"
            try:
                r = client.get(node_url)
                if r.status_code == 200:
                    d = r.json()
                    if d and isinstance(d, dict) and len(d) > 0:
                        print("Found node [" + node + "] on panel " + name + " with " + str(len(d)) + " items!")
                        first_k = list(d.keys())[0]
                        print("  Sample:", json.dumps(d[first_k], default=str)[:200])
                    elif d and isinstance(d, list) and len(d) > 0:
                        print("Found list node [" + node + "] on panel " + name + " with " + str(len(d)) + " items!")
                        print("  Sample list item:", json.dumps(d[0], default=str)[:200])
            except Exception:
                pass
