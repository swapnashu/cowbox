﻿with open('paytm_gateway.py', 'r', encoding='utf-8') as f:
    content = f.read()

import re
if 'import paytm_token_refresh' not in content:
    content = content.replace('import gzip\n', 'import gzip\nimport paytm_token_refresh\n')

target = '''def _api_post(url: str, payload: dict) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=get_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read()
            if response.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        raise RuntimeError(f"API error {e.code}: {raw.decode('utf-8', errors='ignore')}")'''

rep = '''def _api_post(url: str, payload: dict, retry=True) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=get_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read()
            if response.info().get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        if e.info().get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        err_msg = raw.decode("utf-8", errors="ignore")
        
        # Check for invalid token (401, 403, or specific error message)
        if retry and (e.code in (401, 403, 410) or "token" in err_msg.lower() or "unauthorized" in err_msg.lower()):
            print("[*] Access token seems invalid/expired. Attempting to refresh...")
            refresh_res = paytm_token_refresh.refresh_token()
            if refresh_res.get("success"):
                print("[*] Token refreshed successfully! Retrying request...")
                return _api_post(url, payload, retry=False)
            else:
                print("[!] Failed to refresh token:", refresh_res)
                
        raise RuntimeError(f"API error {e.code}: {err_msg}")'''

if target in content:
    content = content.replace(target, rep)
    with open('paytm_gateway.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print("SUCCESS")
else:
    print("NOT FOUND")
