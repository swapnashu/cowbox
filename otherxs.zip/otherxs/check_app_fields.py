﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

r = s.get('http://13.207.147.149:9999/api/applications/53653872-d508-4d9c-b8c9-c7bed17a3224')
app = r.json()
for k in ['id', 'name', 'status', 'containerId', 'exposedPort', 'containerPort', 'updatedAt']:
    print(f"{k}: {app.get(k)}")
