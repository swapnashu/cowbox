﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

content = open('find_inbox_nodes.py', 'r', encoding='utf-8').read()
s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'find_inbox_nodes.py', 'content': content})
s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker cp find_inbox_nodes.py cowbox-khaat-968826:/app/find_inbox_nodes.py'})
r_exec = s.post('http://13.207.147.149:9999/api/files/run', json={'command': 'docker exec cowbox-khaat-968826 python /app/find_inbox_nodes.py'})
print(r_exec.json().get('stdout') or r_exec.json().get('stderr'))
