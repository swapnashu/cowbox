﻿import requests

s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})

cmd = '''docker exec cowbox-db-khaat-pg psql -U postgres -d aat -c "
SELECT count(*) as total_received_records FROM sms_received;
SELECT * FROM sms_received ORDER BY id DESC LIMIT 10;
"'''
r = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r.json().get('stdout'))
