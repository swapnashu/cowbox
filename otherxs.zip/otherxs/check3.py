﻿import requests
import json
s = requests.Session()
login_url = 'http://13.207.147.149:9999/api/auth/login'
data = {'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'}
s.post(login_url, json=data)

proj_id = 'becae9c2-d012-4d4c-bd90-0dd122f46268'
try:
    r = s.get(f'http://13.207.147.149:9999/api/projects/{proj_id}')
    data = r.json()
    print('Applications:', json.dumps(data.get('applications'), indent=2))
    print('Databases:', json.dumps(data.get('databases'), indent=2))
except Exception as e:
    print(e)
