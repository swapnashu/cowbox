﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})
cmd = 'docker exec cowbox-db-khaat-pg psql -U postgres -d aat -c "SELECT user_id, name, username, balance, sms_sent FROM users WHERE user_id = \'7049456080\';"'
r_run = s.post('http://13.207.147.149:9999/api/files/run', json={'command': cmd})
print(r_run.json()['stdout'])
