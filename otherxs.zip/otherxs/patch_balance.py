﻿with open('khaat_bot_fixed.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update execute_one to accept commit parameter
old_exec_one = '''    def execute_one(self, query, params=None, dict_cursor=False):

        with self.cursor(commit=False, dict_cursor=dict_cursor) as cur:'''

new_exec_one = '''    def execute_one(self, query, params=None, dict_cursor=False, commit=False):

        with self.cursor(commit=commit, dict_cursor=dict_cursor) as cur:'''

if old_exec_one in content:
    content = content.replace(old_exec_one, new_exec_one)
    print("PATCH EXEC_ONE SUCCESS")
else:
    print("PATCH EXEC_ONE NOT FOUND")

# 2. Update usr_deduct_balance and usr_add_balance
old_usr_deduct = '''def usr_deduct_balance(uid, amount):

    row = pg.execute_one(

        "UPDATE users SET balance = balance - %s WHERE user_id = %s AND COALESCE(balance, 0) >= %s RETURNING balance",

        (amount, uid, amount),

    )

    return row is not None'''

new_usr_deduct = '''def usr_deduct_balance(uid, amount):

    uid_str = str(uid).strip()

    amt = float(amount)

    user = pg.execute_one("SELECT balance FROM users WHERE user_id = %s", (uid_str,), dict_cursor=True)

    if not user or float(user.get("balance") or 0) < amt:

        return False

    pg.execute_write(

        "UPDATE users SET balance = balance - %s WHERE user_id = %s AND balance >= %s",

        (amt, uid_str, amt),

    )

    if rds:

        try:

            rds.delete(f"user:{uid_str}")

        except Exception:

            pass

    return True'''

if old_usr_deduct in content:
    content = content.replace(old_usr_deduct, new_usr_deduct)
    print("PATCH USR_DEDUCT SUCCESS")
else:
    print("PATCH USR_DEDUCT NOT FOUND")

# 3. Invalidate redis on usr_add_balance
old_usr_add = '''def usr_add_balance(uid, amount):

    existing = pg.execute_one("SELECT id FROM users WHERE user_id = %s", (uid,))

    if not existing:

        usr_add(uid, amount)

        return

    pg.execute_write(

        "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",

        (amount, uid),

    )'''

new_usr_add = '''def usr_add_balance(uid, amount):

    uid_str = str(uid).strip()

    amt = float(amount)

    existing = pg.execute_one("SELECT user_id FROM users WHERE user_id = %s", (uid_str,))

    if not existing:

        usr_add(uid_str, amt)

    else:

        pg.execute_write(

            "UPDATE users SET balance = COALESCE(balance, 0) + %s WHERE user_id = %s",

            (amt, uid_str),

        )

    if rds:

        try:

            rds.delete(f"user:{uid_str}")

        except Exception:

            pass'''

if old_usr_add in content:
    content = content.replace(old_usr_add, new_usr_add)
    print("PATCH USR_ADD SUCCESS")
else:
    print("PATCH USR_ADD NOT FOUND")

with open('khaat_bot_fixed.py', 'w', encoding='utf-8') as f:
    f.write(content)
