﻿import re
data = open('paytm_payment_all_requests_and_responses.txt', encoding='utf-8').read()
matches = re.findall(r'"payMoneyAmount":\{.*?\}', data)
for m in matches[:5]:
    print(m)
