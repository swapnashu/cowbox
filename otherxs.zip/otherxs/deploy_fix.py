﻿import requests
s = requests.Session()
s.post('http://13.207.147.149:9999/api/auth/login', json={'email':'admin@cowbox.io', 'password':'n9a-6MKnGWP11NS8jPnqMg'})
content = open('khaat_bot_fixed.py', 'r', encoding='utf-8').read()
r = s.post('http://13.207.147.149:9999/api/files', json={'filePath': 'khaat_bot.py', 'content': content})
print("Upload status:", r.status_code, r.text)

r2 = s.post('http://13.207.147.149:9999/api/applications/53653872-d508-4d9c-b8c9-c7bed17a3224/restart')
print("Restart status:", r2.status_code, r2.text)
